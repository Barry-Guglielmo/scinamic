# simpleschema Database Example Files and ERDs

## SimpleSchema Database with Example A2A Data

`simpleschema_with_data.sql` has a SimpleSchema database with A2A and COX example data.
`simpleschema_with_data_and_replicates.sql` has a SimpleSchema database with A2A and COX example data and "pseudo 
replicates" with the same mean as the non-replicates file.

These files can be loaded with a command like:
```bash
psql -h localhost -p 3247 -U simpleschema -f simpleschema_with_data.sql
```

These files were originally created using the (deprecated) SDFUploader for SimpleSchema. These files should be updated 
with all of the appropriate migration scripts and then re-exported with. An example of how to do this with a 
Posgtgresql 10 Docker container: 

```bash
PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema -e POSTGRES_PASSWORD=simpleschema postgres:10)
sleep 2
# load old SQL file
PGPASSWORD=simpleschema psql -h localhost -p 3248 -U simpleschema -f simpleschema_with_data.sql
# activate simpleschema venv and run migrations
source venv/bin/activate
python3 migrations/02-replace_unique_indexes_with_partial.py --port 3248 --user simpleschema --password simpleschema simpleschema
python3 migrations/03-replace_unique_indexes_with_partial.py --port 3248 --user simpleschema --password simpleschema simpleschema
# then export the db
PGPASSWORD=simpleschema pg_dump -b -C -h localhost -p 3248 -U simpleschema -f simpleschema_with_data.sql -d simpleschema
```

## Empty SimpleSchema Database and ERD

`simpleschema.sql` is the database only (no data); created using `create_simpleschema_db_dump.py`. Note that using this 
script with the `--with-docker` argument requires executing user access to Docker engine; using it without `--with-docker` 
requires providing connection details for the database server (see script help text). 

To manually start a Postgresql 10 Docker container, create the database, create the tables, and do the dump:
```bash
# This must be run in a virtualenv with the simpleschema package installed and by a user who has docker privs
PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema -e POSTGRES_PASSWORD=simpleschema postgres:10)
sleep 2
docker exec $PGCONTAINER psql -U simpleschema -c "CREATE DATABASE example"
create_tables example --port 3248
PGPASSWORD=simpleschema pg_dump -s -C -h localhost -p 3248 -U simpleschema -f simpleschema.sql -d example
```
When you are done with the docker container you can stop/remove it with:
```bash
docker rm -f $PGCONTAINER
```

ERD SVG and/or PNG files can be created:
* using SQL Developer: File->Data Modeler->Import->Data Dictionary to create the ERD; generate images via File->Data 
Modeler->Print Diagram
* using DBeaver: in the lower left project browser right click on Diagrams and select "Create new ER diagram", give it 
a name, and select only the tables you want as initial objects (e.g. everything except Config, ETLRun, and Source); 
save the ERD and/or image files via File->Save As

Arrange the objects as best as possible to fit in the space and save the ERD and/or images.