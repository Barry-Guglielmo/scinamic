--
-- PostgreSQL database dump
--

-- Dumped from database version 10.20 (Debian 10.20-1.pgdg90+1)
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: example; Type: DATABASE; Schema: -; Owner: simpleschema
--

CREATE DATABASE example WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE example OWNER TO simpleschema;

\connect example

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: simpleschema
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO simpleschema;

SET default_tablespace = '';

--
-- Name: assay; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.assay (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    version character varying(255) DEFAULT '1'::character varying NOT NULL,
    source_id bigint
);


ALTER TABLE public.assay OWNER TO simpleschema;

--
-- Name: assay_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.assay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assay_id_seq OWNER TO simpleschema;

--
-- Name: assay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.assay_id_seq OWNED BY public.assay.id;


--
-- Name: compound; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.compound (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    mol_file text DEFAULT '
  MJ172100                      

  0  0  0  0  0  0  0  0  0  0999 V2000
M  END'::text NOT NULL,
    corporate_id character varying(255) NOT NULL,
    person character varying(255) DEFAULT 'LiveDesign'::character varying NOT NULL,
    molhash character varying(255),
    canonical_smiles text,
    source_id bigint
);


ALTER TABLE public.compound OWNER TO simpleschema;

--
-- Name: compound_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.compound_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compound_id_seq OWNER TO simpleschema;

--
-- Name: compound_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.compound_id_seq OWNED BY public.compound.id;


--
-- Name: compoundobservation; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.compoundobservation (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    endpoint character varying(255) NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    compound_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


ALTER TABLE public.compoundobservation OWNER TO simpleschema;

--
-- Name: compoundobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.compoundobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compoundobservation_id_seq OWNER TO simpleschema;

--
-- Name: compoundobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.compoundobservation_id_seq OWNED BY public.compoundobservation.id;


--
-- Name: compoundobservationproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.compoundobservationproject (
    id bigint NOT NULL,
    compound_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.compoundobservationproject OWNER TO simpleschema;

--
-- Name: compoundobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.compoundobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compoundobservationproject_id_seq OWNER TO simpleschema;

--
-- Name: compoundobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.compoundobservationproject_id_seq OWNED BY public.compoundobservationproject.id;


--
-- Name: compoundproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.compoundproject (
    id bigint NOT NULL,
    "primary" boolean DEFAULT false NOT NULL,
    compound_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.compoundproject OWNER TO simpleschema;

--
-- Name: compoundproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.compoundproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compoundproject_id_seq OWNER TO simpleschema;

--
-- Name: compoundproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.compoundproject_id_seq OWNED BY public.compoundproject.id;


--
-- Name: compoundproperty; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.compoundproperty (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    key character varying(255) NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    compound_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.compoundproperty OWNER TO simpleschema;

--
-- Name: compoundproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.compoundproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compoundproperty_id_seq OWNER TO simpleschema;

--
-- Name: compoundproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.compoundproperty_id_seq OWNED BY public.compoundproperty.id;


--
-- Name: config; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.config (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    person character varying(255),
    config json,
    project_id bigint
);


ALTER TABLE public.config OWNER TO simpleschema;

--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.config_id_seq OWNER TO simpleschema;

--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.document (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    source_id bigint
);


ALTER TABLE public.document OWNER TO simpleschema;

--
-- Name: document_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_id_seq OWNER TO simpleschema;

--
-- Name: document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.document_id_seq OWNED BY public.document.id;


--
-- Name: entityalias; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.entityalias (
    id bigint NOT NULL,
    alias character varying(255) NOT NULL,
    generic_entity_id bigint,
    compound_id bigint,
    source_id bigint,
    CONSTRAINT only_one_parent_set CHECK ((num_nonnulls(generic_entity_id, compound_id) = 1))
);


ALTER TABLE public.entityalias OWNER TO simpleschema;

--
-- Name: entityalias_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.entityalias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entityalias_id_seq OWNER TO simpleschema;

--
-- Name: entityalias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.entityalias_id_seq OWNED BY public.entityalias.id;


--
-- Name: etlrun; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.etlrun (
    id bigint NOT NULL,
    started timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    finished timestamp without time zone,
    status character varying(255) DEFAULT 'CREATED'::character varying,
    source_id bigint
);


ALTER TABLE public.etlrun OWNER TO simpleschema;

--
-- Name: etlrun_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.etlrun_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etlrun_id_seq OWNER TO simpleschema;

--
-- Name: etlrun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.etlrun_id_seq OWNED BY public.etlrun.id;


--
-- Name: experiment; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.experiment (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    assay_id bigint NOT NULL,
    key character varying(255),
    "timestamp" timestamp without time zone DEFAULT timezone('utc'::text, now()),
    source_id bigint
);


ALTER TABLE public.experiment OWNER TO simpleschema;

--
-- Name: experiment_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.experiment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.experiment_id_seq OWNER TO simpleschema;

--
-- Name: experiment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.experiment_id_seq OWNED BY public.experiment.id;


--
-- Name: file; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.file (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    extension character varying(255) NOT NULL,
    person character varying(255) DEFAULT 'LiveDesign'::character varying NOT NULL,
    project_id bigint NOT NULL,
    blob bytea NOT NULL,
    blobdigest character varying(255),
    source_id bigint
);


ALTER TABLE public.file OWNER TO simpleschema;

--
-- Name: file_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.file_id_seq OWNER TO simpleschema;

--
-- Name: file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.file_id_seq OWNED BY public.file.id;


--
-- Name: genericentity; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.genericentity (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    corporate_id character varying(255) NOT NULL,
    person character varying(255) DEFAULT 'LiveDesign'::character varying NOT NULL,
    file_id bigint,
    source_id bigint
);


ALTER TABLE public.genericentity OWNER TO simpleschema;

--
-- Name: genericentity_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.genericentity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericentity_id_seq OWNER TO simpleschema;

--
-- Name: genericentity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.genericentity_id_seq OWNED BY public.genericentity.id;


--
-- Name: genericentityobservation; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.genericentityobservation (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    endpoint character varying(255) NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    generic_entity_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


ALTER TABLE public.genericentityobservation OWNER TO simpleschema;

--
-- Name: genericentityobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.genericentityobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericentityobservation_id_seq OWNER TO simpleschema;

--
-- Name: genericentityobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.genericentityobservation_id_seq OWNED BY public.genericentityobservation.id;


--
-- Name: genericentityobservationproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.genericentityobservationproject (
    id bigint NOT NULL,
    generic_entity_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.genericentityobservationproject OWNER TO simpleschema;

--
-- Name: genericentityobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.genericentityobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericentityobservationproject_id_seq OWNER TO simpleschema;

--
-- Name: genericentityobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.genericentityobservationproject_id_seq OWNED BY public.genericentityobservationproject.id;


--
-- Name: genericentityproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.genericentityproject (
    id bigint NOT NULL,
    generic_entity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.genericentityproject OWNER TO simpleschema;

--
-- Name: genericentityproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.genericentityproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericentityproject_id_seq OWNER TO simpleschema;

--
-- Name: genericentityproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.genericentityproject_id_seq OWNED BY public.genericentityproject.id;


--
-- Name: genericentityproperty; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.genericentityproperty (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    key character varying(255) NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    generic_entity_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.genericentityproperty OWNER TO simpleschema;

--
-- Name: genericentityproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.genericentityproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericentityproperty_id_seq OWNER TO simpleschema;

--
-- Name: genericentityproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.genericentityproperty_id_seq OWNED BY public.genericentityproperty.id;


--
-- Name: lot; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.lot (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    compound_id bigint NOT NULL,
    salt character varying(255),
    person character varying(255) DEFAULT 'LiveDesign'::character varying NOT NULL,
    page_id bigint,
    lot_id_full character varying(255),
    source_id bigint
);


ALTER TABLE public.lot OWNER TO simpleschema;

--
-- Name: lot_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.lot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lot_id_seq OWNER TO simpleschema;

--
-- Name: lot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.lot_id_seq OWNED BY public.lot.id;


--
-- Name: lotobservation; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.lotobservation (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    endpoint character varying(255) NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    lot_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


ALTER TABLE public.lotobservation OWNER TO simpleschema;

--
-- Name: lotobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.lotobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lotobservation_id_seq OWNER TO simpleschema;

--
-- Name: lotobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.lotobservation_id_seq OWNED BY public.lotobservation.id;


--
-- Name: lotobservationproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.lotobservationproject (
    id bigint NOT NULL,
    lot_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.lotobservationproject OWNER TO simpleschema;

--
-- Name: lotobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.lotobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lotobservationproject_id_seq OWNER TO simpleschema;

--
-- Name: lotobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.lotobservationproject_id_seq OWNED BY public.lotobservationproject.id;


--
-- Name: lotproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.lotproject (
    id bigint NOT NULL,
    lot_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.lotproject OWNER TO simpleschema;

--
-- Name: lotproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.lotproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lotproject_id_seq OWNER TO simpleschema;

--
-- Name: lotproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.lotproject_id_seq OWNED BY public.lotproject.id;


--
-- Name: lotproperty; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.lotproperty (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    key character varying(255) NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    lot_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.lotproperty OWNER TO simpleschema;

--
-- Name: lotproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.lotproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lotproperty_id_seq OWNER TO simpleschema;

--
-- Name: lotproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.lotproperty_id_seq OWNED BY public.lotproperty.id;


--
-- Name: page; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.page (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    document_id bigint,
    source_id bigint
);


ALTER TABLE public.page OWNER TO simpleschema;

--
-- Name: page_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_id_seq OWNER TO simpleschema;

--
-- Name: page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.page_id_seq OWNED BY public.page.id;


--
-- Name: pose; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.pose (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    generic_entity_id bigint,
    compound_id bigint,
    project_id bigint,
    person character varying(255) DEFAULT 'LiveDesign'::character varying NOT NULL,
    key character varying(255) NOT NULL,
    pose_id_full character varying(255) NOT NULL,
    source_id bigint,
    CONSTRAINT only_one_parent_set CHECK ((num_nonnulls(generic_entity_id, compound_id) = 1))
);


ALTER TABLE public.pose OWNER TO simpleschema;

--
-- Name: pose_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.pose_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pose_id_seq OWNER TO simpleschema;

--
-- Name: pose_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.pose_id_seq OWNED BY public.pose.id;


--
-- Name: poseobservation; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.poseobservation (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    endpoint character varying(255) NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    pose_id bigint NOT NULL,
    structure_id bigint,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT only_one_pose_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value, structure_id) = 1))
);


ALTER TABLE public.poseobservation OWNER TO simpleschema;

--
-- Name: poseobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.poseobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poseobservation_id_seq OWNER TO simpleschema;

--
-- Name: poseobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.poseobservation_id_seq OWNED BY public.poseobservation.id;


--
-- Name: poseobservationproject; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.poseobservationproject (
    id bigint NOT NULL,
    pose_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


ALTER TABLE public.poseobservationproject OWNER TO simpleschema;

--
-- Name: poseobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.poseobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poseobservationproject_id_seq OWNER TO simpleschema;

--
-- Name: poseobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.poseobservationproject_id_seq OWNED BY public.poseobservationproject.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    key character varying(255) NOT NULL,
    description character varying(255),
    is_restricted smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.project OWNER TO simpleschema;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_seq OWNER TO simpleschema;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: source; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.source (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    config_id bigint,
    person character varying(255),
    uploaded timestamp without time zone,
    processed timestamp without time zone,
    purged timestamp without time zone,
    partial_purge smallint,
    project_id bigint
);


ALTER TABLE public.source OWNER TO simpleschema;

--
-- Name: source_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.source_id_seq OWNER TO simpleschema;

--
-- Name: source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.source_id_seq OWNED BY public.source.id;


--
-- Name: structure; Type: TABLE; Schema: public; Owner: simpleschema
--

CREATE TABLE public.structure (
    id bigint NOT NULL,
    customer_key character varying(255),
    archived smallint DEFAULT 0 NOT NULL,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    modified_at timestamp without time zone DEFAULT timezone('utc'::text, now()),
    key character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    format character varying(255) NOT NULL,
    blob bytea NOT NULL,
    blobdigest character varying(255),
    source_id bigint,
    CONSTRAINT structure_allowed_format CHECK (((format)::text = ANY ((ARRAY['PSE'::character varying, 'MAE'::character varying, 'MAEGZ'::character varying, 'VIB'::character varying])::text[]))),
    CONSTRAINT structure_allowed_type CHECK (((type)::text = ANY ((ARRAY['LIGAND'::character varying, 'PROTEIN'::character varying, 'OTHER'::character varying, 'ANIMATION'::character varying])::text[])))
);


ALTER TABLE public.structure OWNER TO simpleschema;

--
-- Name: structure_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleschema
--

CREATE SEQUENCE public.structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.structure_id_seq OWNER TO simpleschema;

--
-- Name: structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleschema
--

ALTER SEQUENCE public.structure_id_seq OWNED BY public.structure.id;


--
-- Name: assay id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.assay ALTER COLUMN id SET DEFAULT nextval('public.assay_id_seq'::regclass);


--
-- Name: compound id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compound ALTER COLUMN id SET DEFAULT nextval('public.compound_id_seq'::regclass);


--
-- Name: compoundobservation id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation ALTER COLUMN id SET DEFAULT nextval('public.compoundobservation_id_seq'::regclass);


--
-- Name: compoundobservationproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservationproject ALTER COLUMN id SET DEFAULT nextval('public.compoundobservationproject_id_seq'::regclass);


--
-- Name: compoundproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproject ALTER COLUMN id SET DEFAULT nextval('public.compoundproject_id_seq'::regclass);


--
-- Name: compoundproperty id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproperty ALTER COLUMN id SET DEFAULT nextval('public.compoundproperty_id_seq'::regclass);


--
-- Name: config id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.config ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Name: document id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.document ALTER COLUMN id SET DEFAULT nextval('public.document_id_seq'::regclass);


--
-- Name: entityalias id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.entityalias ALTER COLUMN id SET DEFAULT nextval('public.entityalias_id_seq'::regclass);


--
-- Name: etlrun id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.etlrun ALTER COLUMN id SET DEFAULT nextval('public.etlrun_id_seq'::regclass);


--
-- Name: experiment id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.experiment ALTER COLUMN id SET DEFAULT nextval('public.experiment_id_seq'::regclass);


--
-- Name: file id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.file ALTER COLUMN id SET DEFAULT nextval('public.file_id_seq'::regclass);


--
-- Name: genericentity id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentity ALTER COLUMN id SET DEFAULT nextval('public.genericentity_id_seq'::regclass);


--
-- Name: genericentityobservation id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation ALTER COLUMN id SET DEFAULT nextval('public.genericentityobservation_id_seq'::regclass);


--
-- Name: genericentityobservationproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservationproject ALTER COLUMN id SET DEFAULT nextval('public.genericentityobservationproject_id_seq'::regclass);


--
-- Name: genericentityproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproject ALTER COLUMN id SET DEFAULT nextval('public.genericentityproject_id_seq'::regclass);


--
-- Name: genericentityproperty id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproperty ALTER COLUMN id SET DEFAULT nextval('public.genericentityproperty_id_seq'::regclass);


--
-- Name: lot id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lot ALTER COLUMN id SET DEFAULT nextval('public.lot_id_seq'::regclass);


--
-- Name: lotobservation id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation ALTER COLUMN id SET DEFAULT nextval('public.lotobservation_id_seq'::regclass);


--
-- Name: lotobservationproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservationproject ALTER COLUMN id SET DEFAULT nextval('public.lotobservationproject_id_seq'::regclass);


--
-- Name: lotproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproject ALTER COLUMN id SET DEFAULT nextval('public.lotproject_id_seq'::regclass);


--
-- Name: lotproperty id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproperty ALTER COLUMN id SET DEFAULT nextval('public.lotproperty_id_seq'::regclass);


--
-- Name: page id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.page ALTER COLUMN id SET DEFAULT nextval('public.page_id_seq'::regclass);


--
-- Name: pose id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose ALTER COLUMN id SET DEFAULT nextval('public.pose_id_seq'::regclass);


--
-- Name: poseobservation id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation ALTER COLUMN id SET DEFAULT nextval('public.poseobservation_id_seq'::regclass);


--
-- Name: poseobservationproject id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservationproject ALTER COLUMN id SET DEFAULT nextval('public.poseobservationproject_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: source id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.source ALTER COLUMN id SET DEFAULT nextval('public.source_id_seq'::regclass);


--
-- Name: structure id; Type: DEFAULT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.structure ALTER COLUMN id SET DEFAULT nextval('public.structure_id_seq'::regclass);


--
-- Name: assay assay_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.assay
    ADD CONSTRAINT assay_pkey PRIMARY KEY (id);


--
-- Name: compound compound_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compound
    ADD CONSTRAINT compound_pkey PRIMARY KEY (id);


--
-- Name: compoundobservation compoundobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_pkey PRIMARY KEY (id);


--
-- Name: compoundobservationproject compoundobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_pkey PRIMARY KEY (id);


--
-- Name: compoundproject compoundproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_pkey PRIMARY KEY (id);


--
-- Name: compoundproperty compoundproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (id);


--
-- Name: entityalias entityalias_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_pkey PRIMARY KEY (id);


--
-- Name: etlrun etlrun_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.etlrun
    ADD CONSTRAINT etlrun_pkey PRIMARY KEY (id);


--
-- Name: experiment experiment_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: genericentity genericentity_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_pkey PRIMARY KEY (id);


--
-- Name: genericentityobservation genericentityobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_pkey PRIMARY KEY (id);


--
-- Name: genericentityobservationproject genericentityobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_pkey PRIMARY KEY (id);


--
-- Name: genericentityproject genericentityproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_pkey PRIMARY KEY (id);


--
-- Name: genericentityproperty genericentityproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_pkey PRIMARY KEY (id);


--
-- Name: lot lot_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_pkey PRIMARY KEY (id);


--
-- Name: lotobservation lotobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_pkey PRIMARY KEY (id);


--
-- Name: lotobservationproject lotobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_pkey PRIMARY KEY (id);


--
-- Name: lotproject lotproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_pkey PRIMARY KEY (id);


--
-- Name: lotproperty lotproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_pkey PRIMARY KEY (id);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: pose pose_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_pkey PRIMARY KEY (id);


--
-- Name: poseobservation poseobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_pkey PRIMARY KEY (id);


--
-- Name: poseobservationproject poseobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: structure structure_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT structure_pkey PRIMARY KEY (id);


--
-- Name: assay_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX assay_customer_key ON public.assay USING btree (customer_key);


--
-- Name: assay_key_version; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX assay_key_version ON public.assay USING btree (key, version) WHERE (archived = 0);


--
-- Name: assay_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX assay_rowhash ON public.assay USING btree (rowhash);


--
-- Name: assay_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX assay_source_id ON public.assay USING btree (source_id);


--
-- Name: compound_corporate_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compound_corporate_id ON public.compound USING btree (corporate_id) WHERE (archived = 0);


--
-- Name: compound_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compound_customer_key ON public.compound USING btree (customer_key);


--
-- Name: compound_molhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compound_molhash ON public.compound USING btree (molhash);


--
-- Name: compound_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compound_rowhash ON public.compound USING btree (rowhash);


--
-- Name: compound_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compound_source_id ON public.compound USING btree (source_id);


--
-- Name: compoundobservation_assay_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_assay_id ON public.compoundobservation USING btree (assay_id);


--
-- Name: compoundobservation_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_compound_id ON public.compoundobservation USING btree (compound_id);


--
-- Name: compoundobservation_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compoundobservation_customer_key ON public.compoundobservation USING btree (customer_key);


--
-- Name: compoundobservation_document_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_document_id ON public.compoundobservation USING btree (document_id);


--
-- Name: compoundobservation_experiment_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_experiment_id ON public.compoundobservation USING btree (experiment_id);


--
-- Name: compoundobservation_page_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_page_id ON public.compoundobservation USING btree (page_id);


--
-- Name: compoundobservation_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_rowhash ON public.compoundobservation USING btree (rowhash);


--
-- Name: compoundobservation_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservation_source_id ON public.compoundobservation USING btree (source_id);


--
-- Name: compoundobservationproject_compound_observation_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservationproject_compound_observation_id ON public.compoundobservationproject USING btree (compound_observation_id);


--
-- Name: compoundobservationproject_compound_observation_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compoundobservationproject_compound_observation_id_project_id ON public.compoundobservationproject USING btree (compound_observation_id, project_id);


--
-- Name: compoundobservationproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservationproject_project_id ON public.compoundobservationproject USING btree (project_id);


--
-- Name: compoundobservationproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundobservationproject_source_id ON public.compoundobservationproject USING btree (source_id);


--
-- Name: compoundproject_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproject_compound_id ON public.compoundproject USING btree (compound_id);


--
-- Name: compoundproject_compound_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compoundproject_compound_id_project_id ON public.compoundproject USING btree (compound_id, project_id);


--
-- Name: compoundproject_primary; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproject_primary ON public.compoundproject USING btree ("primary");


--
-- Name: compoundproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproject_project_id ON public.compoundproject USING btree (project_id);


--
-- Name: compoundproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproject_source_id ON public.compoundproject USING btree (source_id);


--
-- Name: compoundproperty_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproperty_compound_id ON public.compoundproperty USING btree (compound_id);


--
-- Name: compoundproperty_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX compoundproperty_customer_key ON public.compoundproperty USING btree (customer_key);


--
-- Name: compoundproperty_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX compoundproperty_source_id ON public.compoundproperty USING btree (source_id);


--
-- Name: config_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX config_customer_key ON public.config USING btree (customer_key);


--
-- Name: config_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX config_key ON public.config USING btree (key);


--
-- Name: config_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX config_project_id ON public.config USING btree (project_id);


--
-- Name: config_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX config_rowhash ON public.config USING btree (rowhash);


--
-- Name: document_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX document_customer_key ON public.document USING btree (customer_key);


--
-- Name: document_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX document_rowhash ON public.document USING btree (rowhash);


--
-- Name: document_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX document_source_id ON public.document USING btree (source_id);


--
-- Name: entityalias_alias; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX entityalias_alias ON public.entityalias USING btree (alias);


--
-- Name: entityalias_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX entityalias_compound_id ON public.entityalias USING btree (compound_id);


--
-- Name: entityalias_generic_entity_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX entityalias_generic_entity_id ON public.entityalias USING btree (generic_entity_id);


--
-- Name: entityalias_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX entityalias_source_id ON public.entityalias USING btree (source_id);


--
-- Name: etlrun_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX etlrun_source_id ON public.etlrun USING btree (source_id);


--
-- Name: experiment_assay_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX experiment_assay_id ON public.experiment USING btree (assay_id);


--
-- Name: experiment_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX experiment_customer_key ON public.experiment USING btree (customer_key);


--
-- Name: experiment_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX experiment_rowhash ON public.experiment USING btree (rowhash);


--
-- Name: experiment_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX experiment_source_id ON public.experiment USING btree (source_id);


--
-- Name: file_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX file_customer_key ON public.file USING btree (customer_key);


--
-- Name: file_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX file_project_id ON public.file USING btree (project_id);


--
-- Name: file_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX file_rowhash ON public.file USING btree (rowhash);


--
-- Name: file_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX file_source_id ON public.file USING btree (source_id);


--
-- Name: genericentity_corporate_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentity_corporate_id ON public.genericentity USING btree (corporate_id) WHERE (archived = 0);


--
-- Name: genericentity_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentity_customer_key ON public.genericentity USING btree (customer_key);


--
-- Name: genericentity_file_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentity_file_id ON public.genericentity USING btree (file_id);


--
-- Name: genericentity_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentity_rowhash ON public.genericentity USING btree (rowhash);


--
-- Name: genericentity_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentity_source_id ON public.genericentity USING btree (source_id);


--
-- Name: genericentityobservation_assay_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_assay_id ON public.genericentityobservation USING btree (assay_id);


--
-- Name: genericentityobservation_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentityobservation_customer_key ON public.genericentityobservation USING btree (customer_key);


--
-- Name: genericentityobservation_document_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_document_id ON public.genericentityobservation USING btree (document_id);


--
-- Name: genericentityobservation_experiment_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_experiment_id ON public.genericentityobservation USING btree (experiment_id);


--
-- Name: genericentityobservation_generic_entity_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_generic_entity_id ON public.genericentityobservation USING btree (generic_entity_id);


--
-- Name: genericentityobservation_page_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_page_id ON public.genericentityobservation USING btree (page_id);


--
-- Name: genericentityobservation_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_rowhash ON public.genericentityobservation USING btree (rowhash);


--
-- Name: genericentityobservation_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservation_source_id ON public.genericentityobservation USING btree (source_id);


--
-- Name: genericentityobservationproject_generic_entity_observati_734c8f; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentityobservationproject_generic_entity_observati_734c8f ON public.genericentityobservationproject USING btree (generic_entity_observation_id, project_id);


--
-- Name: genericentityobservationproject_generic_entity_observation_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservationproject_generic_entity_observation_id ON public.genericentityobservationproject USING btree (generic_entity_observation_id);


--
-- Name: genericentityobservationproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservationproject_project_id ON public.genericentityobservationproject USING btree (project_id);


--
-- Name: genericentityobservationproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityobservationproject_source_id ON public.genericentityobservationproject USING btree (source_id);


--
-- Name: genericentityproject_generic_entity_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityproject_generic_entity_id ON public.genericentityproject USING btree (generic_entity_id);


--
-- Name: genericentityproject_generic_entity_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentityproject_generic_entity_id_project_id ON public.genericentityproject USING btree (generic_entity_id, project_id);


--
-- Name: genericentityproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityproject_project_id ON public.genericentityproject USING btree (project_id);


--
-- Name: genericentityproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityproject_source_id ON public.genericentityproject USING btree (source_id);


--
-- Name: genericentityproperty_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX genericentityproperty_customer_key ON public.genericentityproperty USING btree (customer_key);


--
-- Name: genericentityproperty_generic_entity_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityproperty_generic_entity_id ON public.genericentityproperty USING btree (generic_entity_id);


--
-- Name: genericentityproperty_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX genericentityproperty_source_id ON public.genericentityproperty USING btree (source_id);


--
-- Name: lot_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lot_compound_id ON public.lot USING btree (compound_id);


--
-- Name: lot_compound_id_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lot_compound_id_key ON public.lot USING btree (compound_id, key) WHERE (archived = 0);


--
-- Name: lot_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lot_customer_key ON public.lot USING btree (customer_key);


--
-- Name: lot_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lot_key ON public.lot USING btree (key);


--
-- Name: lot_page_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lot_page_id ON public.lot USING btree (page_id);


--
-- Name: lot_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lot_rowhash ON public.lot USING btree (rowhash);


--
-- Name: lot_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lot_source_id ON public.lot USING btree (source_id);


--
-- Name: lotobservation_assay_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_assay_id ON public.lotobservation USING btree (assay_id);


--
-- Name: lotobservation_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lotobservation_customer_key ON public.lotobservation USING btree (customer_key);


--
-- Name: lotobservation_document_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_document_id ON public.lotobservation USING btree (document_id);


--
-- Name: lotobservation_experiment_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_experiment_id ON public.lotobservation USING btree (experiment_id);


--
-- Name: lotobservation_lot_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_lot_id ON public.lotobservation USING btree (lot_id);


--
-- Name: lotobservation_page_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_page_id ON public.lotobservation USING btree (page_id);


--
-- Name: lotobservation_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_rowhash ON public.lotobservation USING btree (rowhash);


--
-- Name: lotobservation_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservation_source_id ON public.lotobservation USING btree (source_id);


--
-- Name: lotobservationproject_lot_observation_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservationproject_lot_observation_id ON public.lotobservationproject USING btree (lot_observation_id);


--
-- Name: lotobservationproject_lot_observation_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lotobservationproject_lot_observation_id_project_id ON public.lotobservationproject USING btree (lot_observation_id, project_id);


--
-- Name: lotobservationproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservationproject_project_id ON public.lotobservationproject USING btree (project_id);


--
-- Name: lotobservationproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotobservationproject_source_id ON public.lotobservationproject USING btree (source_id);


--
-- Name: lotproject_lot_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotproject_lot_id ON public.lotproject USING btree (lot_id);


--
-- Name: lotproject_lot_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lotproject_lot_id_project_id ON public.lotproject USING btree (lot_id, project_id);


--
-- Name: lotproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotproject_project_id ON public.lotproject USING btree (project_id);


--
-- Name: lotproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotproject_source_id ON public.lotproject USING btree (source_id);


--
-- Name: lotproperty_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX lotproperty_customer_key ON public.lotproperty USING btree (customer_key);


--
-- Name: lotproperty_lot_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotproperty_lot_id ON public.lotproperty USING btree (lot_id);


--
-- Name: lotproperty_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX lotproperty_source_id ON public.lotproperty USING btree (source_id);


--
-- Name: page_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX page_customer_key ON public.page USING btree (customer_key);


--
-- Name: page_document_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX page_document_id ON public.page USING btree (document_id);


--
-- Name: page_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX page_rowhash ON public.page USING btree (rowhash);


--
-- Name: page_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX page_source_id ON public.page USING btree (source_id);


--
-- Name: pose_compound_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_compound_id ON public.pose USING btree (compound_id);


--
-- Name: pose_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX pose_customer_key ON public.pose USING btree (customer_key);


--
-- Name: pose_generic_entity_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_generic_entity_id ON public.pose USING btree (generic_entity_id);


--
-- Name: pose_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_key ON public.pose USING btree (key);


--
-- Name: pose_pose_id_full; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX pose_pose_id_full ON public.pose USING btree (pose_id_full);


--
-- Name: pose_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_project_id ON public.pose USING btree (project_id);


--
-- Name: pose_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_rowhash ON public.pose USING btree (rowhash);


--
-- Name: pose_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX pose_source_id ON public.pose USING btree (source_id);


--
-- Name: poseobservation_assay_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_assay_id ON public.poseobservation USING btree (assay_id);


--
-- Name: poseobservation_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX poseobservation_customer_key ON public.poseobservation USING btree (customer_key);


--
-- Name: poseobservation_document_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_document_id ON public.poseobservation USING btree (document_id);


--
-- Name: poseobservation_experiment_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_experiment_id ON public.poseobservation USING btree (experiment_id);


--
-- Name: poseobservation_page_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_page_id ON public.poseobservation USING btree (page_id);


--
-- Name: poseobservation_pose_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_pose_id ON public.poseobservation USING btree (pose_id);


--
-- Name: poseobservation_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_rowhash ON public.poseobservation USING btree (rowhash);


--
-- Name: poseobservation_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservation_source_id ON public.poseobservation USING btree (source_id);


--
-- Name: poseobservation_structure_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX poseobservation_structure_id ON public.poseobservation USING btree (structure_id);


--
-- Name: poseobservationproject_pose_observation_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservationproject_pose_observation_id ON public.poseobservationproject USING btree (pose_observation_id);


--
-- Name: poseobservationproject_pose_observation_id_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX poseobservationproject_pose_observation_id_project_id ON public.poseobservationproject USING btree (pose_observation_id, project_id);


--
-- Name: poseobservationproject_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservationproject_project_id ON public.poseobservationproject USING btree (project_id);


--
-- Name: poseobservationproject_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX poseobservationproject_source_id ON public.poseobservationproject USING btree (source_id);


--
-- Name: project_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX project_customer_key ON public.project USING btree (customer_key);


--
-- Name: project_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX project_key ON public.project USING btree (key) WHERE (archived = 0);


--
-- Name: source_config_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX source_config_id ON public.source USING btree (config_id);


--
-- Name: source_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX source_key ON public.source USING btree (key);


--
-- Name: source_project_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX source_project_id ON public.source USING btree (project_id);


--
-- Name: structure_customer_key; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE UNIQUE INDEX structure_customer_key ON public.structure USING btree (customer_key);


--
-- Name: structure_rowhash; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX structure_rowhash ON public.structure USING btree (rowhash);


--
-- Name: structure_source_id; Type: INDEX; Schema: public; Owner: simpleschema
--

CREATE INDEX structure_source_id ON public.structure USING btree (source_id);


--
-- Name: assay assay_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.assay
    ADD CONSTRAINT assay_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compound compound_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compound
    ADD CONSTRAINT compound_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundobservation compoundobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: compoundobservation compoundobservation_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundobservation compoundobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: compoundobservation compoundobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: compoundobservation compoundobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: compoundobservation compoundobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundobservationproject compoundobservationproject_compound_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_compound_observation_id_fkey FOREIGN KEY (compound_observation_id) REFERENCES public.compoundobservation(id) ON DELETE CASCADE;


--
-- Name: compoundobservationproject compoundobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: compoundobservationproject compoundobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundproject compoundproject_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundproject compoundproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: compoundproject compoundproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundproperty compoundproperty_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundproperty compoundproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: document document_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: entityalias entityalias_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: entityalias entityalias_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: entityalias entityalias_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: etlrun etlrun_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.etlrun
    ADD CONSTRAINT etlrun_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: experiment experiment_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: experiment experiment_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: file file_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: file file_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentity genericentity_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: genericentity genericentity_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityobservation genericentityobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: genericentityobservation genericentityobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: genericentityobservation genericentityobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: genericentityobservation genericentityobservation_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityobservation genericentityobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: genericentityobservation genericentityobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityobservationproject genericentityobservationproje_generic_entity_observation_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproje_generic_entity_observation_i_fkey FOREIGN KEY (generic_entity_observation_id) REFERENCES public.genericentityobservation(id) ON DELETE CASCADE;


--
-- Name: genericentityobservationproject genericentityobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentityobservationproject genericentityobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityproject genericentityproject_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityproject genericentityproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentityproject genericentityproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityproperty genericentityproperty_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityproperty genericentityproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lot lot_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: lot lot_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: lot lot_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotobservation lotobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: lotobservation lotobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: lotobservation lotobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: lotobservation lotobservation_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotobservation lotobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: lotobservation lotobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotobservationproject lotobservationproject_lot_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_lot_observation_id_fkey FOREIGN KEY (lot_observation_id) REFERENCES public.lotobservation(id) ON DELETE CASCADE;


--
-- Name: lotobservationproject lotobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: lotobservationproject lotobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotproject lotproject_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotproject lotproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: lotproject lotproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotproperty lotproperty_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotproperty lotproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: page page_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: page page_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: pose pose_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id);


--
-- Name: pose pose_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id);


--
-- Name: pose pose_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: pose pose_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: poseobservation poseobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: poseobservation poseobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: poseobservation poseobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: poseobservation poseobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: poseobservation poseobservation_pose_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_pose_id_fkey FOREIGN KEY (pose_id) REFERENCES public.pose(id) ON DELETE CASCADE;


--
-- Name: poseobservation poseobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: poseobservation poseobservation_structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_structure_id_fkey FOREIGN KEY (structure_id) REFERENCES public.structure(id);


--
-- Name: poseobservationproject poseobservationproject_pose_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_pose_observation_id_fkey FOREIGN KEY (pose_observation_id) REFERENCES public.poseobservation(id) ON DELETE CASCADE;


--
-- Name: poseobservationproject poseobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: poseobservationproject poseobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: source source_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.source
    ADD CONSTRAINT source_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.config(id);


--
-- Name: structure structure_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleschema
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT structure_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: simpleschema
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

