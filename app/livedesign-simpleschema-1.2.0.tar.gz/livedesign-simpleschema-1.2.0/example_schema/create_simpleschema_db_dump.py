#!/usr/bin/env python3
import os
import sys
from argparse import ArgumentParser
from contextlib import contextmanager
from peewee import OperationalError
from time import sleep
from traceback import print_exc
from uuid import uuid4

from simpleschema.schemas import SimpleSchema


def parse_args():
    parser = ArgumentParser('Create and Dump SimpleSchema DB')
    parser.add_argument("--database", default="simpleschema",
                        help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost",
                        help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3248,
                        help="Postgres port number (default: 3248)")
    parser.add_argument("--user", default="simpleschema",
                        help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password", default="simpleschema",
                        help="Password to login to db with (default: simpleschema")
    parser.add_argument('--with-docker', dest='with_docker', action='store_true',
                        help='Will start and stop a postgres:10 docker container to use for create/dump. If unset then '
                             '--host/port/user/password args should be used.')
    return parser.parse_args()


def exec(cmd: str) -> (str, str):
    stdout_file = f'/tmp/{uuid4().hex}'
    stderr_file = f'/tmp/{uuid4().hex}'
    code = os.system(f'{cmd} 1>{stdout_file} 2>{stderr_file}')
    stdout = open(stdout_file, 'r').read().strip('\n')
    stderr = open(stderr_file, 'r').read().strip('\n')
    if stderr:
        print(stderr, file=sys.stderr)
    if code != 0:
        print(stdout)
        print(f"exiting unexpectedly with code {code}...")
        sys.exit(code)
    return stdout, stderr


@contextmanager
def docker(use_docker: bool, db: str, port: int, user: str, password: str):
    if use_docker:
        container_id = None
        try:
            container_id, _ = exec(
                f'docker run -d -p 0.0.0.0:{port}:5432 -e POSTGRES_USER={user} -e POSTGRES_PASSWORD={password} '
                f'postgres:10')
            sleep(2)  # wait for postgres to settle
            exec(f'docker exec {container_id} psql -U simpleschema -c "CREATE DATABASE {db}"')
            yield True
        except Exception:
            print_exc()
            yield True
        finally:
            if container_id:
                exec(f'docker rm -f {container_id}')
    else:
        try:
            yield True
        finally:
            pass


def main(db: str, host: str, port: int, user: str, password: str):
    print(f"Creating tables in {db}...")
    target_schema = None
    try:
        # TODO: does peewee log create statements?
        target_schema = SimpleSchema(db,
                                     user=user,
                                     password=password,
                                     host=host,
                                     port=port,
                                     create_missing_tables=True)
    except OperationalError as oe:
        print(oe)
        return
    all_tables_exist = False
    for model in target_schema.all_tables:
        if model.table_exists():
            print(f" Table '{model.get_table_name()}' exists.")
            all_tables_exist = True
        else:
            print(f" ERROR: Table '{model.get_table_name()}' does not exist!")
            all_tables_exist = False
    if all_tables_exist:
        exec(f'PGPASSWORD={password} pg_dump -s -C -h {host} -p {port} -U {user} -f simpleschema.sql simpleschema')


if __name__ == '__main__':
    args = parse_args()
    with docker(args.with_docker, args.database, args.port, args.user, args.password):
        main(args.database, args.host, args.port, args.user, args.password)
