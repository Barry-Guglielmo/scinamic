import json
import os
import re
from datetime import datetime
from hashlib import md5, sha256
from typing import Any, Dict, Optional, Union, Tuple

from peewee import Model, SQL

Structure = Any  # NOTE(dornford): prevent circular imports and create a generic type

SS_TABLE_PREFIX = os.getenv('SS_TABLE_PREFIX', '')
ALLOWED_OPERATORS = ('=', '<', '>', '>=', '<=', '+', '++')


def generate_hash(obj: Optional[Union[str, Dict, bytes, memoryview]], use_sha256=False) -> Optional[str]:
    """Convert a string, binary (file contents), or row dict to a hash for very simple diff or unique checking. Defaults
     to using MD5 unless use_sha256=True"""
    if not isinstance(obj, (str, dict, bytes, memoryview)):
        return None
    binary_obj = (json.dumps(obj, sort_keys=True, default=str) if isinstance(obj, dict) else obj).encode('utf-8') \
        if isinstance(obj, (str, dict)) else obj
    return sha256(binary_obj).hexdigest() if use_sha256 else md5(binary_obj).hexdigest()


def try_cast_as_float(value_string: Union[str, float, int, None]) -> Optional[float]:
    try:
        return float(value_string)
    except ValueError:
        return None


def parse_operator_and_convert_to_number(value) -> Tuple[Optional[str], Optional[float], Optional['datetime'],
                                                         Optional[str]]:
    """Attempt to parse operators from a provided text value and convert the remaining string to float"""
    pre_operators = r'^<=|^>=|^=|^>|^<|^GT|^LT'
    post_operators = r'\+\+$|\+$'
    text_value = None
    num_value = None
    date_value = None
    value_operator = None
    if isinstance(value, datetime):
        date_value = value
    elif isinstance(value, int) or isinstance(value, float):
        num_value = value
    elif isinstance(value, str):
        pre_match = re.search(pre_operators, value)
        post_match = re.search(post_operators, value)
        if pre_match:
            num_value = try_cast_as_float(value[pre_match.end():])
            if num_value is not None:
                value_operator = pre_match.group(0)
                if value_operator == 'GT':
                    value_operator = '>'
                if value_operator == 'LT':
                    value_operator = '<'
            else:
                text_value = value
        elif post_match:
            num_value = try_cast_as_float(value[:post_match.start()])
            if num_value is not None:
                value_operator = post_match.group(0)
        else:
            num_value = try_cast_as_float(value)
            if num_value is None:
                text_value = value
    return text_value, num_value, date_value, value_operator


def value_to_kwargs(value: Optional[Union[str, float, int, 'datetime']],
                    is_property: bool = False,
                    is_pose: bool = False) -> dict:
    """Will try to parse a value and set the num_value, text_value, date_value, or operator arguments in the dict"""
    new_kwargs = dict()
    if value is None:
        return new_kwargs
    elif isinstance(value, datetime):
        new_kwargs['date_value'] = value
    elif is_property:
        # We don't support operators in properties/database columns
        num_val = try_cast_as_float(value)
        if num_val is not None:
            new_kwargs['num_value'] = num_val
        else:
            new_kwargs['text_value'] = value
    elif is_pose:
        # only poses allow structure_id to be set for an observation value
        new_kwargs['structure'] = value
    else:
        text_val, num_val, date_val, value_operator = parse_operator_and_convert_to_number(value)
        new_kwargs['text_value'] = text_val
        new_kwargs['num_value'] = num_val
        new_kwargs['date_value'] = date_val
        new_kwargs['value_operator'] = value_operator
    return new_kwargs


def validate_values(num_value: Optional[Union[float, int]] = None,
                    text_value: Optional[str] = None,
                    date_value: Optional['datetime'] = None,
                    structure: Optional[Structure] = None) -> dict:
    """Check that only one value is set and do some simple validation"""
    if sum(map(bool, [num_value, text_value, date_value, structure])) > 1:
        raise ValueError("Only one of numeric, text, date , or structure values is permitted to be set")
    try:
        if num_value is not None:
            float(num_value)
    except TypeError:
        text_value = str(num_value)
        num_value = None
    if date_value and not isinstance(date_value, datetime):
        text_value = str(date_value)
        date_value = None
    validated_kwargs = {
        'num_value': num_value,
        'text_value': text_value,
        'date_value': date_value,
        # NOTE: structure is validated upstream
    }
    return validated_kwargs


def defaults(value) -> Dict:
    # This returns default and constraints kwargs to get around
    # a limitation in peewee where default field values are not
    # generated in rendered SQL
    # http://docs.peewee-orm.com/en/latest/peewee/models.html#default-field-values

    kwargs = {"default": value}
    if isinstance(value, dict):
        value = f"'{json.dumps(value)}'::json"
    elif isinstance(value, str):
        value = f"'{value}'"
    elif value is True:
        value = 'true'
    elif value is False:
        value = 'false'
    elif value == datetime.utcnow:
        value = "(now() at time zone 'utc')"
    kwargs.update({"constraints": [SQL(f'DEFAULT {value}')]})
    return kwargs


def make_legacy_table_name(model_class: Model) -> str:
    # This is using the legacy_table_names style (still the default in peewee 3.14.0)
    model_name = re.sub(r'\W+', '_', model_class.__name__.lower())
    return SS_TABLE_PREFIX + model_name


def make_snake_case_table_name(model_class: Model) -> str:
    # This is using the new snake case style (see peewee.py)
    snake_case_step1 = re.compile(r'(.)_*([A-Z][a-z]+)')
    snake_case_step2 = re.compile(r'([a-z\d])_*([A-Z])')
    first = snake_case_step1.sub(r'\1_\2', model_class.__name__)
    model_name = snake_case_step2.sub(r'\1_\2', first).lower()
    return SS_TABLE_PREFIX + model_name


def file_full_path_to_kwargs(fullpath: str) -> dict:
    if not os.path.exists(fullpath):
        raise IOError(f"File '{fullpath}' not found.")
    filename = os.path.split(fullpath)[1]
    extension = os.path.splitext(filename)[1].replace('.', '').upper()
    with open(fullpath, 'rb') as file:
        blob = file.read()
    return {
        'filename': filename,
        'extension': extension,
        'blob': blob
    }
