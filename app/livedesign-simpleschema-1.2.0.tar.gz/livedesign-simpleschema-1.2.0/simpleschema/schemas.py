from typing import Optional, List, Type, TypeVar

from simpleschema.models import (BaseModel, Project, Compound, EntityAlias, CompoundProject, Lot, LotProject, Assay,
                                 Experiment, Document, Page, CompoundProperty, LotProperty, LotObservation,
                                 CompoundObservation, LotObservationProject, CompoundObservationProject, ETLRun,
                                 Config, Source, File, GenericEntity, GenericEntityProject, GenericEntityProperty,
                                 GenericEntityObservation, GenericEntityObservationProject, Structure, Pose,
                                 PoseObservation, PoseObservationProject)
from peewee import ProgrammingError
from playhouse.postgres_ext import PostgresqlExtDatabase

ModelType = TypeVar('ModelType', bound=BaseModel)


# singleton
class SimpleSchema(object):
    global_project = None
    default_restricted_project = None
    all_tables = [
        Project,
        Compound,
        EntityAlias,
        CompoundProject,
        Lot,
        LotProject,
        Assay,
        Experiment,
        Document,
        Page,
        CompoundProperty,
        LotProperty,
        LotObservation,
        LotObservationProject,
        CompoundObservation,
        CompoundObservationProject,
        ETLRun,
        Config,
        Source,
        File,
        GenericEntity,
        GenericEntityProject,
        GenericEntityProperty,
        GenericEntityObservation,
        GenericEntityObservationProject,
        Structure,
        Pose,
        PoseObservation,
        PoseObservationProject,
    ]
    assay_tables = [
        PoseObservation,
        PoseObservationProject,
        LotObservation,
        LotObservationProject,
        CompoundObservation,
        CompoundObservationProject,
        GenericEntityObservation,
        GenericEntityObservationProject,
        Experiment,
        Assay,
    ]
    property_tables = [
        LotProperty,
        CompoundProperty,
        GenericEntityProperty,
    ]
    db: PostgresqlExtDatabase = None

    # Helper/utility methods

    # Nuclear option - completely clear DB and start over; can not be rolled back; should only be used for testing
    # WARNING: a full re-DI is required after running this function
    def clear_all(self):
        table_names = [table.get_table_name() for table in self.all_tables]
        if not table_names:
            return None
        sql = f'TRUNCATE {", ".join(table_names)} RESTART IDENTITY CASCADE'
        self.db.execute_sql(sql)

    # Clear assays/properties - Best way to keep consistency with unstructured data sources.
    # Use with care. Updating values via customer_key or hash matching is strongly preferred.
    @classmethod
    def clear_assay_values(cls, include_properties=False):
        for table in cls.assay_tables + (cls.property_tables if include_properties else []):
            for row in table.select():
                row.delete_instance()

    def create_tables(self, tables: Optional[List[Type['ModelType']]] = None):
        try:
            self.db.create_tables(tables if tables else self.all_tables)
        except ProgrammingError:
            # tables already exist
            self.db.rollback()

    def restore_default_projects(self, include_global: bool, default_restricted: str):
        if Project.table_exists():
            if include_global:
                self.global_project = Project.register(key='Global', is_restricted=0)
            else:
                self.global_project = None
            if default_restricted:
                self.default_restricted_project = Project.register(key=default_restricted, is_restricted=1)
            else:
                self.default_restricted_project = None

    def __init__(self,
                 database_name,
                 user='simpleschema',
                 password='simpleschema',
                 host='localhost',
                 port=3247,
                 all_tables: List[Type['ModelType']] = None,
                 create_missing_tables=False,
                 include_global_project=False,
                 default_restricted_project='Default Restricted Project',
                 restore_projects=False,
                 ensure_projects: List[dict] = None):
        self.db = PostgresqlExtDatabase(database_name, user=user, password=password, host=host, port=port)
        self.db.connect()
        if all_tables:
            self.all_tables = all_tables
        self.db.bind(self.all_tables)
        if create_missing_tables:
            missing_tables = [t for t in self.all_tables if not t.table_exists()]
            self.create_tables(missing_tables)
        if ensure_projects:
            for proj_kwargs in ensure_projects:
                if proj_kwargs:
                    Project.get_or_create(**proj_kwargs)
        if restore_projects:
            self.restore_default_projects(include_global_project, default_restricted_project)

    # NOTE: always close database connection on object destruction
    def __del__(self):
        return self.db and self.db.close()
