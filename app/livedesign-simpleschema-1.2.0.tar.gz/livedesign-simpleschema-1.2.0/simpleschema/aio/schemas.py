#!/usr/bin/env python3
from typing import List
from aiopeewee import PooledPostgresqlExtDatabaseAsync

from simpleschema.schemas import SimpleSchema
from simpleschema.models import BaseModel


class SimpleSchemaAsync(SimpleSchema):
    """
    Supplants default peewee.PostgresqlDatabase with asyncio Task-safe
    aiopeewee.PooledPostgresqlExtDatabaseAsync
    """
    db: PooledPostgresqlExtDatabaseAsync

    def __init__(
            self,
            database_name,
            user='simpleschema',
            password='simpleschema',
            host='localhost',
            port=3247,
            max_connections=20,  # NOTE: only allow 20 connections at a time
            stale_timeout=300,  # NOTE: close stale connections after 5 minutes
            timeout=0,  # NOTE: never timeout connection checkout
            all_tables: List[BaseModel] = [],
            create_missing_tables=False,
            include_global_project=False,
            default_restricted_project='Default Restricted Project',
            restore_projects=False,
            ensure_projects=[{}]):
        super().__init__(
            database_name,
            user=user,
            password=password,
            host=host,
            port=port,
            all_tables=all_tables,
            create_missing_tables=create_missing_tables,
            include_global_project=include_global_project,
            default_restricted_project=default_restricted_project,
            restore_projects=restore_projects,
            ensure_projects=ensure_projects,
        )
        if self.db:
            del self.db

        self.db = PooledPostgresqlExtDatabaseAsync(
            database_name,
            max_connections=max_connections,
            stale_timeout=stale_timeout,
            timeout=timeout,
            user=user,
            password=password,
            host=host,
            port=port,
        )
        self.db.bind(self.all_tables)

    # NOTE: always close all database connections on object destruction
    def __del__(self):
        return self.db and (self.db.close_all() if hasattr(self.db, 'close_all') else self.db.close())
