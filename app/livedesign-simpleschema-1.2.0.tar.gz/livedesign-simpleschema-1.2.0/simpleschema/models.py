from collections import defaultdict
from datetime import datetime
from typing import Dict, Generator, List, Optional, Set, Union, Tuple, Type, TypeVar

from simpleschema import EMPTY_MOL_FILE
from simpleschema.exceptions import *  # noqa: F403
from simpleschema.utils import (generate_hash, value_to_kwargs, validate_values, make_legacy_table_name, defaults,
                                file_full_path_to_kwargs)

from peewee import (BooleanField, Model, ForeignKeyField, DeferredForeignKey, SmallIntegerField, DoubleField,
                    BigAutoField, BlobField, CharField, DateTimeField, TextField, Check, EXCLUDED)
from playhouse.shortcuts import model_to_dict
from playhouse.postgres_ext import PostgresqlExtDatabase, JSONField
from playhouse.hybrid import hybrid_property

ALLOWED_OPERATORS = ('=', '<', '>', '>=', '<=', '+', '++')


# Base model classes
class BaseModel(Model):

    class Meta:
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """ExtendedBaseModel subclasses not overriding register() should override this method to prep/validate args"""
        for k in kwargs:
            if kwargs[k] is None:
                continue
            # if field is an object model but an object was not specified...
            model = cls.property_model(k)
            if model is not None and not isinstance(kwargs[k], model):
                # ...do query to get object model instance from database
                kwargs[k] = model.get(**{model.lookup_field: kwargs[k]})
        return kwargs

    @classmethod
    def get_fields(cls) -> Dict:
        return cls._meta.fields

    @classmethod
    def get_table_name(cls) -> str:
        return cls._meta.table_name

    @classmethod
    def find(cls, **kwargs) -> Optional[List[Type['ModelType']]]:
        if not kwargs:
            try:
                return list(cls.select().order_by(cls.id.desc()))
            except cls.DoesNotExist:
                return None
        # NOTE: we need to translate kwargs to equality tests, e.g.:
        #   {'corporate_id': '1'} => [Compound.corporate_id == 1]
        # NOTE: any leftover kwargs will still (rightfully) throw a TypeError if they are for fields not in
        #   cls._meta.fields
        args = []
        for kwarg in list(cls.prep_and_validate_values(kwargs)):
            if kwarg in cls._meta.fields:
                if kwargs[kwarg] is None:
                    kwargs.pop(kwarg)
                else:
                    args.append(getattr(cls, kwarg) == kwargs.pop(kwarg))
        return list(cls.select().where(*args, **kwargs))

    @classmethod
    def find_one(cls, **kwargs) -> Optional[Type['ModelType']]:
        # Warning: If there are multiple matches, only the last one will be returned
        if not kwargs:
            try:
                return cls.select().order_by(cls.id.desc()).get()
            except cls.DoesNotExist:
                return None
        return cls.get_or_none(**kwargs)

    id = BigAutoField()


ModelType = TypeVar('ModelType', bound=BaseModel)


class ExtendedBaseModel(BaseModel):
    lookup_field = None
    CHILDREFS = []  # this should be overridden by particular model implementations

    def find_dependents(self) -> Tuple[int, Set[int]]:
        count = 0
        sources = set()

        def process_query(qry, cnt, srcs):
            # global count, sources
            q_count = qry.count()
            if q_count:
                cnt += q_count
                children = [child for child in qry]
                for child in children:
                    if child and child.source:
                        srcs.add(child.source.id)
            return cnt, srcs

        for child_ref in self.CHILDREFS:
            model_query = getattr(self, child_ref)
            count, sources = process_query(model_query, count, sources)
        return count, sources

    @classmethod
    def property_model(cls, prop) -> Optional['ExtendedBaseModel']:
        return cls.__dict__[prop].__dict__.get('rel_model') if prop in cls.__dict__ else None

    @classmethod
    def register(cls, **kwargs) -> 'ExtendedBaseModel':
        """
        Default register method for all extended base models. This operation
        is effectively an upsert.
        
        Either override this method or prep_and_validate_values()
        """
        entity, _ = cls.get_or_create(**cls.prep_and_validate_values(kwargs))
        # NOTE: by default we only_save_dirty fields -- see Meta on BaseModel
        # also see https://docs.peewee-orm.com/en/3.4.0/peewee/api.html#Model.save
        # and https://docs.peewee-orm.com/en/3.4.0/peewee/api.html#Model.dirty_fields
        entity.save()
        return entity

    @classmethod
    def bulk_prep_and_validate_values(cls, rows: List[Dict]) -> List[Dict]:
        """
        ExtendedBaseModel sub-classes not overriding register() should override this method to bulk prep/validate args.
        """
        fields = rows[0].keys()
        if any(_.keys() != fields for _ in rows):
            raise ValueError('Not all rows have the same fields!')
        return [cls.prep_and_validate_values(_) for _ in rows]

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['ExtendedBaseModel']:
        """
        Default bulk register method for all extended base models. This operation
        is effectively an upsert.

        Either override this method or prep_and_validate_values()
        """
        if not rows:
            return []
        lookup = getattr(cls, cls.lookup_field or 'id')
        updated = [k for k in cls._meta.columns if k != cls.lookup_field]
        return list(
            cls.insert_many(cls.bulk_prep_and_validate_values(rows)).returning(cls).on_conflict(
                # The column to use for identifying row conflicts to update.
                # Uses cls.lookup_field attribute if it is set for the class, else will use cls.id
                conflict_target=[lookup],
                # The fields to update with the values of interest.
                # Note that EXCLUDED is a special temporary table that represents all rows that
                # conflicted -- see https://www.postgresql.org/docs/current/sql-insert.html as
                # well as http://docs.peewee-orm.com/en/latest/peewee/querying.html#bulk-inserts
                #
                # Here's what this field looks like in practice:--
                # {Compound.mol_file: EXCLUDED.mol_file, Compound.person: EXCLUDED.person, ...}
                update={getattr(cls, k): getattr(EXCLUDED, k) for k in updated},
            ))

    def deregister(self, deep: bool = True, purge: bool = False):
        """
        Deregister this entity.

        :param deep: Whether to recursively delete all child entities (default: True)

        :param purge: Whether to delete all entities that reference this entity (default: False)
        """
        self.delete_instance(recursive=deep, delete_nullable=purge)


class ArchivableModelExtended(ExtendedBaseModel):
    lookup_field = 'customer_key'

    def __init__(self, unarchive_match=True, *args, **kwargs):
        # FIXME: add test for unarchive_match
        super().__init__(*args, **kwargs)
        if unarchive_match and self.archived == 1:
            self.unarchive()

    def archive(self):
        self.archived = 1
        self.save()

    def unarchive(self):
        self.archived = 0
        self.save()

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Ensure that customer_key is cast to str"""
        customer_key = kwargs.get('customer_key', None)
        if isinstance(customer_key, int):
            kwargs['customer_key'] = str(customer_key)
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def customer_keys(cls) -> Generator[str, None, None]:
        return (_.customer_key for _ in cls.find() if _.customer_key)

    customer_key = CharField(null=True, unique=True)  # used for reference and/or diff checking
    archived = SmallIntegerField(**defaults(0))  # DI mappings should include WHERE archived = 0


class HashableModel(ArchivableModelExtended):
    hashable_fields = {'customer_key', 'archived'}  # can override this list in implementing models
    rowhash = CharField(index=True, null=True)  # can be set to custom row/dict hash
    autohash: bool = True
    """
    An archivable class that will automatically hash a row during registration.

    If auto-hashing is undesirable, set the `autohash` property on your child
    class to False, i.e.:

        from simpleschema.models import Lot

        Lot.autohash = False
    """

    def update_rowhash(self):
        dct = model_to_dict(self, recurse=False)
        for k in list(dct.keys()):
            # Exclude kwarg for model_to_dict seems to not work in all cases so let's manually pop them out:
            if k not in self.hashable_fields:
                dct.pop(k)
                continue
        self.rowhash = generate_hash(dct)
        self.save()

    @classmethod
    def register(cls, **kwargs) -> 'HashableModel':
        model = super().register(**cls.prep_and_validate_values(kwargs))
        if cls.autohash and isinstance(model, HashableModel):
            model.update_rowhash()
        return model

    @classmethod
    def list_diffs(cls, new_entities: dict) -> dict:
        known_entities = {ent.customer_key: ent.rowhash for ent in cls.select()}
        processed = defaultdict(dict)

        # updates
        for pk in known_entities:
            assert cls.get(customer_key=pk)
            try:
                ent_details = new_entities.pop(pk)
                if ent_details['rowhash'] != known_entities[pk]:
                    processed['updates'][pk] = ent_details

            # deletes
            except KeyError:
                processed['deletes'][pk] = {}

        # inserts
        for pk, ent_details in new_entities.items():
            processed['inserts'][pk] = ent_details

        return processed


class DateFieldModel(HashableModel):

    created_at = DateTimeField(null=True, **defaults(datetime.utcnow))
    modified_at = DateTimeField(null=True, **defaults(datetime.utcnow))


class AclsMixin:
    """
    Mixin class for adding common method(s) for Model classes with "project_acls" backrefs
    """
    project_acls = []

    def get_acls(self) -> List['Project']:
        return [_.project for _ in self.project_acls]


class PropertyModel(ArchivableModelExtended):
    """
    Base model for Compound and Lot Property tables.
    """
    allowed_value_kwargs = ['num_value', 'text_value', 'date_value']

    # compound or lot AS observed_item_id
    key = CharField()  # AS protocol_id
    num_value = DoubleField(null=True)  # AS quantity
    text_value = TextField(null=True)  # AS cat_obs_phenomenon
    date_value = DateTimeField(null=True)  # AS date_value

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        value_kwargs = {k: kwargs.get(k) for k in cls.allowed_value_kwargs}
        validated_value_kwargs = validate_values(**value_kwargs)
        kwargs.update(validated_value_kwargs)
        return super().prep_and_validate_values(kwargs)


class ObservationModel(DateFieldModel, AclsMixin):
    """
    Base model for Compound and Lot observation tables.
    """
    hashable_fields = {
        'customer_key', 'archived', 'lot', 'compound', 'generic_entity', 'pose', 'endpoint', 'text_value', 'num_value',
        'date_value', 'structure', 'unit', 'std_dev', 'value_operator', 'conc', 'conc_unit', 'assay', 'experiment',
        'page', 'document'
    }
    allowed_value_kwargs = ['num_value', 'text_value', 'date_value']
    CHILDREFS = ['project_acls']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        value_kwargs = {k: kwargs.get(k) for k in cls.allowed_value_kwargs}
        validated_value_kwargs = validate_values(**value_kwargs)
        kwargs.update(validated_value_kwargs)
        assay = kwargs.get('assay')
        experiment = kwargs.get('experiment')
        if 'value_operator' in kwargs and kwargs['value_operator'] not in ALLOWED_OPERATORS:
            kwargs['value_operator'] = None
        if not assay:
            if not isinstance(experiment, Experiment):
                raise ValueError("assay (name or Model) or experiment (Model) must be set")
            else:
                assay = experiment.assay
                kwargs['assay'] = assay
        if isinstance(assay, str):
            assay = Assay.register(key=assay, version='1')
            kwargs['assay'] = assay
        if isinstance(experiment, str):
            experiment = Experiment.register(assay=assay, key=None)
            kwargs['experiment'] = experiment

        return super().prep_and_validate_values(kwargs)

    # consensus fields
    endpoint = CharField()  # AS type_id (use surrogate_key)
    unit = CharField(null=True)  # AS unit_id (use surrogate_key)
    text_value = TextField(null=True)  # AS cat_obs_phenomenon
    num_value = DoubleField(null=True)  # AS quantity
    date_value = DateTimeField(null=True)  # AS date_value
    std_dev = DoubleField(null=True)  # AS quantity_std_dev
    value_operator = CharField(null=True)  # AS obs_operator (=,<,>,>=,<=,+,++)
    conc = DoubleField(null=True)  # AS quantity_conc
    conc_unit = CharField(null=True)  # AS quantity_conc_unit (use unit_id surrogate_key)

    class Meta:
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value) = 1", name="only_one_observation_value"),
            Check(f"value_operator IN {ALLOWED_OPERATORS}", name="observation_allowed_operators")
        ]


# SimpleSchema models that are not used by Data Integrator but are useful for ETL implementations of SimpleSchema
class Config(DateFieldModel):
    """
    This table holds ETL config information.
    """
    lookup_field = 'key'
    hashable_fields = {'archived', 'config', 'customer_key', 'key', 'person', 'project'}

    id = BigAutoField()
    key = CharField(unique=True)
    person = CharField(null=True)
    project = DeferredForeignKey('Project', null=True)
    config = JSONField(null=True)


class Source(ExtendedBaseModel):
    """
    This table tracks uploads of data into the SimpleSchema (ETL runs).
    """
    lookup_field = 'key'

    BACKREFS = [
        'poses', 'structures', 'lot_observation_acls', 'lot_observations', 'lot_properties', 'lot_acls', 'lots',
        'generic_entity_observation_acls', 'generic_entity_observations', 'generic_entity_properties',
        'compound_observations', 'compound_properties', 'documents', 'experiments', 'assays', 'compound_acls',
        'entity_aliases', 'compounds', 'generic_entity_files', 'generic_entity_acls', 'generic_entities'
    ]

    def purge(self) -> dict:
        """Must be called under 'with target_schema.db.atomic():'
        Example:
            src = find_source(query)
            purge_report = defaultdict()
            with target_schema.db.atomic:
                purge_report.update(src.purge())
            src.purged = datetime.utcnow()
            src.partial_purge =  purge_report.get('partial')
            src.save()
        """

        purge_report = dict()
        purge_report['partial'] = 0
        conflicting_sources = set()
        for backref in self.BACKREFS:
            short_backref = backref.replace('_by_source', '')
            purge_report[f'{short_backref}_deleted'] = 0
            purge_report[f'{short_backref}_skipped'] = 0
            select_query = getattr(self, backref)
            for ety in select_query.iterator():
                children, all_child_sources = ety.find_dependents()
                if children:
                    purge_report['partial'] = 1
                    for src_id in all_child_sources:
                        if src_id != self.id:
                            conflicting_sources.add(src_id)
                else:
                    ety.deregister()
                    purge_report[f'{short_backref}_deleted'] += 1
        purge_report['conflicting_sources'] = list(conflicting_sources)
        return purge_report

    id = BigAutoField()
    key = CharField(unique=True)
    config = ForeignKeyField(Config, null=True)
    person = CharField(null=True)
    project = DeferredForeignKey('Project', null=True)
    uploaded = DateTimeField(null=True)
    processed = DateTimeField(null=True)
    purged = DateTimeField(null=True)
    partial_purge = SmallIntegerField(null=True)


class ETLRun(ExtendedBaseModel):
    """
    This table tracks the start/end times and status of the last ETL run. There is an optional relationship to
    Source table to track configs used, names or other identifiers, etc.
    """
    started = DateTimeField(**defaults(datetime.utcnow))
    finished = DateTimeField(null=True)
    status = CharField(null=True, **defaults('CREATED'))
    source = ForeignKeyField(Source, null=True)


# Models used by DI (tables, fields, and custom methods)
class Project(ArchivableModelExtended):  # syn_project
    """
    This table contains project details and is mapped to syn_project.
    """
    lookup_field = 'key'
    key = CharField()  # AS project_name
    description = CharField(null=True)  # AS project_desc
    is_restricted = SmallIntegerField(**defaults(1))  # AS is_restricted

    # CASE WHEN archived = 0 THEN 'N' ELSE 'Y' AS active

    def update_description(self, description: str):
        self.description = description
        self.save()

    def restrict(self):
        self.is_restricted = 1
        self.save()

    def unrestrict(self):
        self.is_restricted = 0
        self.save()


Project.add_index(Project.key, unique=True, where=(Project.archived == 0))


class Compound(DateFieldModel, AclsMixin):  # syn_compound
    """
    This table contains compound/structure information and is mapped to syn_compound. Notes:
    - mol_file must be in MOL or single SDF format
    - if `project` is set in kwargs for Compound.register() this project will be set as the "primary" project and used
    in the syn_compound.project_id mapping
    """
    lookup_field = 'corporate_id'
    hashable_fields = {'customer_key', 'archived', 'corporate_id', 'person', 'mol_file'}
    CHILDREFS = ['lots', 'properties', 'observations', 'project_acls', 'aliases', 'poses']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Ensure only one Compound or Generic Entity corporate_id or alias is registered"""
        corporate_id = kwargs.get('corporate_id')
        if corporate_id:
            if GenericEntity.get_or_none(corporate_id=corporate_id, archived=0):
                raise EntityIntegrityError(f"Generic Entity {corporate_id} has already been registered")
            elif EntityAlias.get_or_none(alias=corporate_id):
                raise AliasIntegrityError(f"Alias {corporate_id} has already been registered")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'Compound':
        # NOTE: project is a hybrid_property and cannot be registered directly
        # this will return the Compound entity if it already matches the provided kwargs but try to re-register anyway
        project = kwargs.pop("project", None)
        compound = super().register(**cls.prep_and_validate_values(kwargs))
        if cls.autohash and compound is not None:
            compound.molhash = generate_hash(compound.mol_file)
            compound.save()
        if project:
            CompoundProject.register(primary=True, compound=compound, project=project)
        return compound

    def register_acl(self, project: 'Project', **kwargs) -> 'CompoundProject':
        """
        Register an additional project acl. Please use switch_primary if you would like to swap primary
        projects instead.

        :arg project: The project to acl this compound to; can be a project key (name) or Project instance
        :param project: :class:`str` or :class:`Project`
        """
        return CompoundProject.register(primary=False, compound=self, project=project, **kwargs)

    def register_alias(self, alias: str, **kwargs) -> 'EntityAlias':
        return EntityAlias.register(compound=self, alias=alias, **kwargs)

    def register_lot(self, lot_name: str = None, **kwargs) -> 'Lot':
        return Lot.register(compound=self, key=lot_name, **kwargs)

    def register_pose(self, **kwargs) -> 'Pose':
        return Pose.register(compound=self, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'CompoundObservation':
        if value:
            kwargs.update(value_to_kwargs(value))
        return CompoundObservation.register(compound=self, assay=assay, endpoint=endpoint, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'CompoundProperty':
        if value:
            value_args = value_to_kwargs(value, is_property=True)
            kwargs.update(value_args)
        return CompoundProperty.register(compound=self, key=prop_name, **kwargs)

    def switch_primary(self,
                       project: Union['Project', str],
                       deregister_current: bool = False) -> Union[Project, ForeignKeyField]:
        """
        Switch out the current primary project with a new primary project.

        :arg project: The new project to use as primary. Can be the key (name) of a
            project, or a Project instance.
        :param project: :class:`str` or :class:`Project`
        :arg deregister_current: Whether to also deregister the current
            primary, after adding a new one.
        :param deregister_current: :class:`bool`
        """
        # first do integrity checks on the existing primary project (self.project)
        current_primary = list(CompoundProject.select().where(
            CompoundProject.primary == True,
            CompoundProject.compound == self.id,
        ))[0]
        if project in (current_primary.project, current_primary.project.key):
            return current_primary.project
        new_primary = CompoundProject.register(compound=self, project=project, primary=False)
        current_primary.primary = False
        current_primary.save()
        new_primary.primary = True
        new_primary.save()
        if deregister_current:
            current_primary.deregister()
        return new_primary.project

    # (...project.key AS project ... JOIN CompoundProject ON primary=t
    # JOIN Project ON project.id = CompoundProject.project_id)
    @hybrid_property
    def project(self) -> 'Project':
        primary = list(CompoundProject.select().where(
            CompoundProject.primary == True,
            CompoundProject.compound == self.id,
        ))
        if len(primary) == 0:
            raise PrimaryProjectIntegrityError(f"Compound {self} does not have a primary project.")
        if len(primary) > 1:
            raise PrimaryProjectIntegrityError(f"Compound {self} has more than one primary project.")
        return primary[0].project

    mol_file = TextField(**defaults(EMPTY_MOL_FILE))  # AS cd_structure - MOL or single SDF only
    corporate_id = CharField()  # AS corporate_id
    person = CharField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    molhash = CharField(index=True, null=True)  # MD5 (faster) or SHA256 (less collisions) hash of mol_file
    canonical_smiles = TextField(null=True)  # used mainly for reference
    source = ForeignKeyField(Source, null=True, backref='compounds')


Compound.add_index(Compound.corporate_id, unique=True, where=(Compound.archived == 0))


class CompoundProject(ExtendedBaseModel):  # ld_entities_projects
    """
    This table contains compound project ACLs and is mapped to ld_entities_projects. Notes:
    - if primary==True, then mapping will be for syn_compound.project
    - else, mapping will be for ld_compounds_projects.project
    """
    primary = BooleanField(null=False, index=True, **defaults(False))  # join condition for compound
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='project_acls')  # AS entity_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compounds')  # project.id AS project_id
    source = ForeignKeyField(Source, null=True, backref='compound_acls')

    class Meta:
        indexes = (
            # create unique constraints on compound + project
            (('compound', 'project'), True),)

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        if kwargs.get("primary", False):
            primary = CompoundProject.get_or_none(primary=True, compound=kwargs.get("compound"))
            if (primary is not None and "project" in kwargs and
                    kwargs["project"] not in (primary.project, primary.project.key)):
                raise PrimaryProjectIntegrityError(f"Compound {kwargs['compound']}"
                                                   " has already been registered with a primary project."
                                                   " Use Compound.switch_primary() to change its primary project.")
        return super().prep_and_validate_values(kwargs)


class Document(DateFieldModel):  # syn_document (syn_observation.document_id)
    """
    This table contains document/notebook keys (names/identifiers) and will be mapped to syn_document (referred to by
    observation tables/syn_observation mappings).
    """
    CHILDREFS = ['lot_observations', 'compound_observations', 'pages']
    hashable_fields = {'customer_key', 'archived', 'key'}
    lookup_field = 'key'

    key = CharField()
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='documents')


class Page(DateFieldModel):  # syn_observation.document_page and syn_sample.document_page
    """
    This table contains document/notebook page keys (names/identifiers) and may be referred to by
    syn_observation.document_page and syn_sample.document_page mappings. There is an optional FK
    relationship to the Document table via document_id.
    """
    CHILDREFS = ['lots', 'lot_observations', 'compound_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'document_id'}
    lookup_field = 'key'

    key = CharField()
    document = ForeignKeyField(Document, null=True, backref='pages')
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pages')


class Lot(DateFieldModel, AclsMixin):  # syn_sample
    """
    This table contains lot/batch/sample details and is mapped to syn_sample.
    """
    lookup_field = 'lot_id_full'
    hashable_fields = {'customer_key', 'archived', 'compound', 'key', 'salt', 'person'}
    separator = '-'
    CHILDREFS = ['observations', 'properties', 'project_acls']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        kwargs = super().prep_and_validate_values(kwargs)
        lot_id_full = kwargs.get('lot_id_full')
        parsed_lot_id = f"{kwargs['compound'].corporate_id}{cls.separator}{kwargs['key']}"
        if lot_id_full:
            if lot_id_full != parsed_lot_id:
                raise LotIntegrityError(f"lot_id_full {kwargs['lot_id_full']} does not match parsed {parsed_lot_id}")
        else:
            kwargs['lot_id_full'] = parsed_lot_id
        return kwargs

    def register_acl(self, project: 'Project', **kwargs) -> 'LotProject':
        return LotProject.register(lot=self, project=project, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'LotProperty':
        if value:
            kwargs.update(value_to_kwargs(value, is_property=True))
        return LotProperty.register(lot=self, key=prop_name, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'CompoundObservation':
        if value:
            kwargs.update(value_to_kwargs(value))
        return LotObservation.register(lot=self, assay=assay, endpoint=endpoint, **kwargs)

    key = CharField(index=True)  # AS lot_id; shouldn't start with V
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='lots')  # AS compound_id
    salt = CharField(null=True)  # AS salt_id (use surrogate_key)
    person = CharField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)
    page = ForeignKeyField(Page, null=True, backref='lots')  # page.key AS document_page

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    lot_id_full = CharField(null=True)
    source = ForeignKeyField(Source, null=True, backref='lots')
    # use LotProject join table if using Lot ACLs to add to ld_compounds_projects

    # The following are (optionally) used by DI but not currently implemented in SimpleSchema:
    # source_id - Shows up under the ‘Lot Source’ column (use surrogate_key).
    # alias_id - The value here shows up in the ‘Lot Alias ID’ database column.
    # data1 - Despite the column name, the value here shows up under the ‘Lot Comment’ database column.
    # amt_prepared - The amount prepared for the lot. Shows up in LD under the ‘Lot Amount’ database column.
    # appearance - The appearance of the lot. Shows up under the ‘Lot Appearance’ database column.
    # date_prepared - Values show up under the ‘Lot Date Prepared’ database column.
    # purity - Values show up in the ‘Lot Purity’ database column.
    # solubility - Shows up under the ‘Lot Solubility’ database column.
    # total_formula - Shows up under the ‘Lot Total Formula’ database column.
    # total_weight - Shows up under the ‘Lot Total Weight’ database column.


Lot.add_index(Lot.compound, Lot.key, unique=True, where=(Lot.archived == 0))


class LotProject(ExtendedBaseModel):  # ld_compounds_projects
    """
    This table contains lot project ACLs and is mapped via JOIN to Compound tables to ld_compounds_projects.
    """
    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='project_acls')  # lot.compound.id AS compound_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='lots')  # project.key AS project_id
    source = ForeignKeyField(Source, null=True, backref='lot_acls')

    class Meta:
        indexes = (
            # create a unique on lot + project
            (('lot', 'project'), True),)


class Assay(DateFieldModel):  # syn_phenomenon_type and syn_observation_protocol (subset of syn_observation)
    """
    This table holds the assay/protocol key/name (syn_phenomenon_type.name; e.g. "A2A Binding" or
    "Calculated Properties") and version (syn_observation_protocol.version_num; e.g. "1" or "Bob's v1.7"). Depending on
    aggregation mode, one or both of these will be used for naming, aggregating, and foldering of assay columns.
    """
    CHILDREFS = ['experiments', 'lot_observations', 'compound_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'version'}
    lookup_field = 'key'

    key = CharField()  # AS syn_observation_protocol.phenomenon_type_id
    version = CharField(**defaults('1'))  # AS syn_observation_protocol.version_num
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='assays')


Assay.add_index(Assay.key, Assay.version, unique=True, where=(Assay.archived == 0))


class Experiment(DateFieldModel):  # subset of syn_observation
    """
    This table contains details of an experiment (collection of observations for a particular assay on a particular
    date). Notes:
    - `key` field will be mapped to primary_groupno (falling back to `id` field)
    - `timestamp` field will be mapped to secondary_groupno_date
    """
    CHILDREFS = ['lot_observations', 'compound_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'timestamp'}
    lookup_field = 'key'

    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='experiments')
    key = CharField(null=True)  # COALESCE(key, customer_key) AS primary_groupno
    timestamp = DateTimeField(null=True, **defaults(datetime.utcnow))  # AS secondary_groupno_date
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='experiments')


class CompoundProperty(PropertyModel):  # syn_observation
    """
    This table contains compound level properties (database columns) and will be mapped to syn_observation with 1 AS
    compound_level and 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.
    """
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='properties')  # AS observed_item_id
    source = ForeignKeyField(Source, null=True, backref='compound_properties')
    # 1 AS compound_level
    # 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id


class LotProperty(PropertyModel):  # syn_observation
    """
    This table contains lot/batch/sample level properties (database columns) and will be mapped to syn_observation
    with 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.
    """
    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='properties')  # AS observed_item_id
    source = ForeignKeyField(Source, null=True, backref='lot_properties')
    # 0 AS compound_level
    # 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id


class LotObservation(ObservationModel):  # syn_observation
    """
    This table contains lot level observations and will be mapped to syn_observation.
    """

    def register_acl(self, project: 'Project', **kwargs) -> 'LotObservationProject':
        return LotObservationProject.register(lot_observation=self, project=project, **kwargs)

    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='lot_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='lot_observations')
    document = ForeignKeyField(Document, null=True, backref='lot_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='lot_observations')  # page.key AS document_page
    source = ForeignKeyField(Source, null=True, backref='lot_observations')


class LotObservationProject(ExtendedBaseModel):  # ld_observations_projects
    """
    This table contains lot observation project ACLs.
    """
    lot_observation = ForeignKeyField(LotObservation, on_delete='CASCADE', backref='project_acls')  # AS observation_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='lot_observation_acls')  # project.key AS project_id
    source = ForeignKeyField(Source, null=True, backref='lot_observation_acls')

    class Meta:
        indexes = (
            # create a unique on lot observation + project
            (('lot_observation', 'project'), True),)


class CompoundObservation(ObservationModel):  # syn_observation
    """
    This table contains compound level observations and will be mapped to syn_observation.
    """

    def register_acl(self, project: 'Project', **kwargs) -> 'CompoundObservationProject':
        return CompoundObservationProject.register(compound_observation=self, project=project, **kwargs)

    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='compound_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='compound_observations')
    document = ForeignKeyField(Document, null=True, backref='compound_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='compound_observations')  # page.key AS document_page
    source = ForeignKeyField(Source, null=True, backref='compound_observations')


class CompoundObservationProject(ExtendedBaseModel):  # ld_observations_projects
    """
    This table contains compound observation project ACLs.
    """
    # compound_observation_id AS observation_id
    compound_observation = ForeignKeyField(CompoundObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compound_observation_acls')
    source = ForeignKeyField(Source, null=True, backref='compound_observation_acls')

    class Meta:
        indexes = (
            # create a unique on observation + project
            (('compound_observation', 'project'), True),)


class File(DateFieldModel):  # AS ld_manageable_file and ld_data_blob
    """
    A table for generic entity files and mapped to ld_manageable_file and ld_data_blob
    """
    hashable_fields = {'customer_key', 'archived', 'key', 'extension', 'person', 'project', 'blob'}

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        blob = kwargs.get('blob')
        filepath = kwargs.pop('filepath', None)
        if sum(map(bool, [blob, filepath])) != 1:
            raise ValueError("One and only one of 'blob' or 'filepath' kwargs must be set")
        if filepath:
            file_kwargs = file_full_path_to_kwargs(filepath)
            file_kwargs.update({'key': file_kwargs.pop('filename')})
            kwargs.update(file_kwargs)
        if not isinstance(kwargs['blob'], (bytes, memoryview)):
            raise ValueError(f"blob must be bytes or memoryview type, not {type(kwargs['blob'])}")
        kwargs['extension'] = kwargs.get('extension', '').replace('.', '').upper()
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, blob: Optional[Union[bytes, memoryview]] = None, filepath: Optional[str] = None,
                 **kwargs) -> 'File':
        kwargs.update({'blob': blob, 'filepath': filepath})
        file = super().register(**cls.prep_and_validate_values(kwargs))
        if cls.autohash and file is not None:
            file.blobdigest = generate_hash(file.blob, use_sha256=True)
            file.save()
        return file

    key = CharField()  # AS file_name
    extension = CharField()  # AS file_type
    person = CharField(**defaults('LiveDesign'))  # AS registration_scientist_id (use surrogate_key)
    # project AS registration_project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='generic_entity_files')
    blob = BlobField()  # AS data_blob_id
    blobdigest = CharField(null=True)
    source = ForeignKeyField(Source, null=True, backref='generic_entity_files')


class GenericEntity(DateFieldModel, AclsMixin):  # ld_generic_entity
    """
    This table holds generic entity information and is mapped to ld_generic_entity.
    """
    lookup_field = 'corporate_id'
    hashable_fields = {'customer_key', 'archived', 'corporate_id', 'file', 'person'}
    CHILDREFS = ['properties', 'observations', 'project_acls', 'aliases', 'poses']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        corporate_id = kwargs.get('corporate_id')
        if corporate_id:
            if Compound.get_or_none(corporate_id=corporate_id, archived=0):
                raise EntityIntegrityError(f"Compound {corporate_id} has already been registered")
            if EntityAlias.get_or_none(alias=corporate_id):
                raise AliasIntegrityError(f"Alias {corporate_id} has already been registered")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, corporate_id: str, file: Optional[File], **kwargs) -> 'GenericEntity':
        kwargs['file'] = file
        kwargs['corporate_id'] = corporate_id
        project = kwargs.pop('project', None)
        generic_entity = super().register(**cls.prep_and_validate_values(kwargs))
        if project is not None:
            GenericEntityProject.register(generic_entity=generic_entity, project=project, source=kwargs.get('source'))
        return generic_entity

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityProject':
        """
        Register a project acl.

        :arg project: The project to acl this generic entity to; can be a project key (name) or Project instance
        :param project: :class:`str` or :class:`Project`
        """
        return GenericEntityProject.register(generic_entity=self, project=project, **kwargs)

    def register_alias(self, alias: str, **kwargs) -> 'EntityAlias':
        return EntityAlias.register(generic_entity=self, alias=alias, **kwargs)

    def register_pose(self, **kwargs) -> 'Pose':
        return Pose.register(generic_entity=self, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'GenericEntityObservation':
        if value:
            kwargs.update(value_to_kwargs(value))
        return GenericEntityObservation.register(generic_entity=self, assay=assay, endpoint=endpoint, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'GenericEntityProperty':
        if value:
            value_args = value_to_kwargs(value, is_property=True)
            kwargs.update(value_args)
        return GenericEntityProperty.register(generic_entity=self, key=prop_name, **kwargs)

    corporate_id = CharField()  # AS corporate_id
    person = CharField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)
    file = ForeignKeyField(File, on_delete='CASCADE', null=True)  # AS manageable_file_id

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entities')


GenericEntity.add_index(GenericEntity.corporate_id, unique=True, where=(GenericEntity.archived == 0))


class GenericEntityProject(ExtendedBaseModel):  # ld_entities_projects
    """
    This table contains generic entity project ACLs and is mapped to ld_entities_projects.
    """
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='project_acls')  # AS entity_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compounds')  # project.id AS project_id
    source = ForeignKeyField(Source, null=True, backref='generic_entity_acls')

    class Meta:
        indexes = (
            # create unique constraints on compound + project
            (('generic_entity', 'project'), True),)


class EntityAlias(ExtendedBaseModel):  # ld_entity_alias
    """
    This table contains generic and compound entity aliases (mapped to ld_entity_alias).
    """
    lookup_field = 'alias'

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        alias = kwargs.get('alias')
        if alias:
            if Compound.get_or_none(corporate_id=alias, archived=0):
                raise EntityIntegrityError(f"Compound {alias} has already been registered")
            if GenericEntity.get_or_none(corporate_id=alias, archived=0):
                raise EntityIntegrityError(f"Generic Entity {alias} has already been registered")
        return super().prep_and_validate_values(kwargs)

    alias = CharField(unique=True)  # AS alias
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='aliases', null=True)  # AS entity_id
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='aliases', null=True)  # AS entity_id
    source = ForeignKeyField(Source, null=True, backref='entity_aliases')

    class Meta:
        constraints = [Check("num_nonnulls(generic_entity_id, compound_id) = 1", name="only_one_parent_set")]


class GenericEntityProperty(PropertyModel):  # syn_observation
    """
    This table contains generic entity level properties (database columns; mapped to syn_observation with
    'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id).
    """
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='properties')  # AS observed_item_id

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_properties')


class GenericEntityObservation(ObservationModel):  # syn_observation
    """
    This table contains generic entity level observations (mapped to syn_observation).
    """

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityObservationProject':
        return GenericEntityObservationProject.register(generic_entity_observation=self, project=project, **kwargs)

    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='generic_entity_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='generic_entity_observations')
    document = ForeignKeyField(Document, null=True, backref='generic_entity_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='generic_entity_observations')  # page.key AS document_page
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_observations')


class GenericEntityObservationProject(ExtendedBaseModel):  # ld_observations_projects
    """
    This table contains generic entity observation project ACLs (mapped to ld_observations_projects).
    """
    # generic_entity_observation_id AS observation_id
    generic_entity_observation = ForeignKeyField(GenericEntityObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='generic_entity_observation_acls')
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_observation_acls')

    class Meta:
        indexes = (
            # create a unique on observation + project
            (('generic_entity_observation', 'project'), True),)


class Structure(DateFieldModel):  # ld_structure and ld_structure_data and ld_data_blob
    """
    This table is for representing structures for 3D assays (mapped to ld_structure, ld_structure_data, and
    ld_data_blob). The records here must be referenced by an observation table for the data to show up in LD.
    """
    hashable_fields = {'customer_key', 'archived', 'key', 'type', 'format', 'blob'}
    allowed_structure_types = ('LIGAND', 'PROTEIN', 'OTHER', 'ANIMATION')
    allowed_structure_formats = ('PSE', 'MAE', 'MAEGZ', 'VIB')

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        blob = kwargs.get('blob')
        filepath = kwargs.pop('filepath', None)
        if sum(map(bool, [blob, filepath])) != 1:
            raise ValueError("One and only one of 'blob' or 'filepath' kwargs must be set")
        if filepath:
            file_kwargs = file_full_path_to_kwargs(filepath)
            filename = file_kwargs.pop('filename')
            if not kwargs.get('key'):
                file_kwargs['key'] = filename
            file_kwargs['format'] = file_kwargs.pop('extension')
            kwargs.update(file_kwargs)
        if not isinstance(kwargs['blob'], (bytes, memoryview)):
            raise ValueError(f"blob must be bytes or memoryview type, not {type(kwargs['blob'])}")
        kwargs['type'] = kwargs.get('type', '').upper()
        kwargs['format'] = kwargs.get('format', '').replace('.', '').upper()
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, blob: Optional[Union[bytes, memoryview]] = None, filepath: Optional[str] = None,
                 **kwargs) -> 'Structure':
        kwargs.update({'blob': blob, 'filepath': filepath})
        structure = super().register(**cls.prep_and_validate_values(kwargs))
        if cls.autohash and structure is not None:
            structure.blobdigest = generate_hash(structure.blob, use_sha256=True)
            structure.save()
        return structure

    key = CharField()  # the name of the structure to shows up in the 3D visualizer
    type = CharField(constraints=[Check(f"type IN {allowed_structure_types}",
                                        name="structure_allowed_type")])  # the type of the 3D structure
    format = CharField(constraints=[Check(f"format IN {allowed_structure_formats}",
                                          name="structure_allowed_format")])  # the type/extension of the file
    blob = BlobField()  # references the binary content of the data
    blobdigest = CharField(null=True)

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='structures')


class Pose(DateFieldModel):  # ld_pose
    """
    This table is for representing poses in LiveDesign (mapped to ld_pose). Pose records must be created if you want to
    create pose-level data in an observation table. Different poses show up as different rows in row-per-pose mode.
    """
    lookup_field = 'pose_id_full'
    hashable_fields = {'customer_key', 'archived', 'compound', 'generic_entity', 'key', 'person'}
    separator = '#'
    CHILDREFS = ['observations']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        kwargs = super().prep_and_validate_values(kwargs)
        key = kwargs.get('key') or '1'
        pose_id_full = kwargs.get('pose_id_full')
        parent = kwargs.get('compound') or kwargs.get('generic_entity')
        parsed_pose_id = f"{parent.corporate_id}{cls.separator}{key}"
        if pose_id_full:
            if pose_id_full != parsed_pose_id:
                raise IntegrityError(f"pose_id_full {kwargs['pose_id_full']} does not match parsed {parsed_pose_id}")
        else:
            kwargs['pose_id_full'] = parsed_pose_id
        return kwargs

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime', Structure]] = None,
                             **kwargs) -> 'PoseObservation':
        if value is not None:
            kwargs.update(value_to_kwargs(value, is_pose=True))
        return PoseObservation.register(pose=self, assay=assay, endpoint=endpoint, **kwargs)

    generic_entity = ForeignKeyField(GenericEntity, null=True, backref='poses')  # AS parent_entity_id
    compound = ForeignKeyField(Compound, null=True, backref='poses')  # AS parent_entity_id
    project = ForeignKeyField(Project, null=True, backref='poses')  # AS project_id; No user facing effect right now
    person = CharField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    key = CharField(index=True)
    pose_id_full = CharField(unique=True)
    source = ForeignKeyField(Source, null=True, backref='poses')

    class Meta:
        constraints = [Check("num_nonnulls(generic_entity_id, compound_id) = 1", name="only_one_parent_set")]


class PoseObservation(ObservationModel):  # syn_observation
    """
    This table contains pose level observations (mapped to syn_observation).
    """
    allowed_value_kwargs = ['num_value', 'text_value', 'date_value', 'structure']

    def register_acl(self, project: 'Project', **kwargs) -> 'PoseObservationProject':
        return PoseObservationProject.register(pose_observation=self, project=project, **kwargs)

    pose = ForeignKeyField(Pose, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    structure = ForeignKeyField(Structure, null=True, unique=True, backref='pose_observations')
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='pose_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='pose_observations')
    document = ForeignKeyField(Document, null=True, backref='pose_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='pose_observations')  # page.key AS document_page
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pose_observations')

    class Meta:
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value, structure_id) = 1",
                  name="only_one_pose_observation_value")
        ]


class PoseObservationProject(ExtendedBaseModel):  # ld_observations_projects
    """
    This table contains generic entity observation project ACLs (mapped to ld_observations_projects).
    """
    # pose_observation_id AS observation_id
    pose_observation = ForeignKeyField(PoseObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='pose_observation_acls')
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pose_observation_acls')

    class Meta:
        indexes = (
            # create a unique on observation + project
            (('pose_observation', 'project'), True),)
