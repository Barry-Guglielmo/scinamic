"""Schema, models, and utilities for loading compounds, batches, properties,
and assay data into a PSQL Simple Schema for DI. Optional extensions for loading
SDFs and Spreadsheets and/or webservices"""
from .version import __version__

EMPTY_MOL_FILE = """
  MJ172100                      

  0  0  0  0  0  0  0  0  0  0999 V2000
M  END"""
