"""
Flask/gunicorn-based REST API for SimpleSchema
"""
from flask import Flask, request, render_template, jsonify
import logging
import requests
import os
import secrets

from playhouse.shortcuts import model_to_dict
from simpleschema.schemas import SimpleSchema
from simpleschema.models import Compound, Project, Lot

DEBUG = os.getenv('SIMPLESCHEMA_DEBUG')  # set this to anything to skip auth check
DATABASE = os.getenv('DATABASE', 'simpleschema')
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', 3247))
DB_USER = os.getenv('DB_USER', 'simpleschema')
DB_PASS = os.getenv('DB_PASS', 'simpleschema')
SECRET_KEY = os.getenv('SECRET_KEY', secrets.token_hex())


app = Flask(__name__, static_url_path='/livedesign/simpleschema/static')
app.secret_key = SECRET_KEY

TARGET_SCHEMA = SimpleSchema(DATABASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
TARGET_SCHEMA.db.close()

DOESNT_NEED_DB_CONNECTION = []


@app.before_request
def before_request():
    if request.endpoint not in DOESNT_NEED_DB_CONNECTION:
        TARGET_SCHEMA.db.connect(reuse_if_open=True)


@app.after_request
def after_request(response):
    if request.endpoint not in DOESNT_NEED_DB_CONNECTION:
        if not TARGET_SCHEMA.db.is_closed():
            TARGET_SCHEMA.db.close()
    return response


def check_session_auth(flask_request, require_admin=True):
    if DEBUG:
        return True
    api_endpoint = 'http://localhost:9081/livedesign/api/'
    if require_admin:
        api_endpoint += 'groups'
    else:
        api_endpoint += 'about'
    try:
        session_id = flask_request.cookies.get('JSESSIONID')
        api_request = requests.get(api_endpoint, cookies={'JSESSIONID': session_id})
        assert api_request.status_code == 200
    except AssertionError:
        app.logger.info("User is not authenticated")
        return False
    except (ConnectionRefusedError, requests.exceptions.ConnectionError):
        app.logger.error("Can't connect to LiveDesign. Service may be down or restarting.")
        return False
    return True


@app.route('/livedesign/simpleschema/api/find/project', methods=['GET', 'POST'])
def find_project():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        proj = Project.get_or_none(**query_dict)
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if proj:
        return jsonify(model_to_dict(proj, recurse=False))
    else:
        return jsonify()


@app.route('/livedesign/simpleschema/api/register/project', methods=['GET', 'POST'])
def register_project():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        proj = Project.register(**query_dict)
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if proj:
        return jsonify(model_to_dict(proj, recurse=False))
    else:
        return jsonify()


@app.route('/livedesign/simpleschema/api/find/compound', methods=['GET', 'POST'])
def find_compound():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        cmpd = Compound.get_or_none(**query_dict)
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if cmpd:
        return jsonify(model_to_dict(cmpd, recurse=False))
    else:
        return jsonify()


@app.route('/livedesign/simpleschema/api/register/compound', methods=['GET', 'POST'])
def register_compound():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        project_id = query_dict.pop('project_id', None)
        query_dict['project'] = Project.get_or_none(id=project_id) if project_id else None
        cmpd = Compound.register(**Compound.prep_and_validate_values(query_dict))
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if cmpd:
        return jsonify(model_to_dict(cmpd, recurse=False))
    else:
        return jsonify()


@app.route('/livedesign/simpleschema/api/find/lot', methods=['GET', 'POST'])
def find_lot():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        compound_id = query_dict.pop('compound_id', None)
        if compound_id:
            query_dict['compound'] = Compound.get_or_none(id=compound_id)
        lot = Lot.get_or_none(**query_dict)
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if lot:
        return jsonify(model_to_dict(lot, recurse=False))
    else:
        return jsonify()


@app.route('/livedesign/simpleschema/api/register/lot', methods=['GET', 'POST'])
def register_lot():
    if not check_session_auth(request, require_admin=True):
        return render_template("401.html")
    if request.method == 'GET':
        if not request.args:
            return jsonify(error='No query parameters'), 202
        query_dict = request.args
    else:
        query_dict = request.json
        if not query_dict:
            return jsonify(error='No JSON content found'), 202
    try:
        compound_id = query_dict.pop('compound_id', None)
        query_dict['compound'] = Compound.get_or_none(id=compound_id)
        lot = Lot.register(**Lot.prep_and_validate_values(query_dict))
    except (AttributeError, ValueError, Exception) as e:
        return jsonify(error=str(e)), 202
    if lot:
        return jsonify(model_to_dict(lot, recurse=False))
    else:
        return jsonify()


if __name__ == '__main__':
    app.run('0.0.0.0', 8870, debug=True)
else:
    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)
