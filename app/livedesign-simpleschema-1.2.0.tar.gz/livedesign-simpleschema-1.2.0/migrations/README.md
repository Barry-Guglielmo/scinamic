# SimpleSchema migration scripts

These scripts will attempt to migrate previous versions of SimpleSchema with any known breaking changes.

These python migration scripts only apply to SimpleSchema versions >= 1.0.0. For migrations from earlier versions of SimpleSchema 
or from (now deprecated) SDFUSchema to SimpleSchema will require manual intervention. See 00-old_to_new_migration.sql for an example.  

# Executing Python Schema Migrations

To run schema migrations for a simpleschema package, first install the canonical `simpleschema` package as normal in a virtualenv, and activate it. Follow instructions in the packages README for more information.

Once you have activated your virtualenv, cd to the `migrations` directory within the package you are running migrations for. Each migration script will take config parameters as arguments. Run the script without any arguments for more details. For example:
```
cd simpleschema/migrations
python 00-example.py
```

Migrations, if needed, should be run in order. 


And that's it!

# Writing Schema Migrations

Schema migrations must exist in a `/migrations` folder beneath the top-level simpleschema package. For consistency and by convention, new migrations should be named in numerical order and match the regex `\d{2}-[a-z_]+\.py$`. New migrations should also include a docstring at the top of the file with a `Written By`, `Date Added`, and `Reason` entry.

See the [pewee playhouse schema migration documentation](http://docs.peewee-orm.com/en/latest/peewee/playhouse.html#schema-migrations) for more information on what actions you can perform.

# SQL Migrations for SimpleSchema versions <1.0.0

To migrate versions of SimpleSchema before Releases and Python Schema Migrations were being tracked (e.g. <1.0.0) you 
will have to do a manual SQL migration. The basic steps of this are as follows:
1. Stop DI.
2. Create a new schema in the SimpleSchema database (`old`).
3. Move everything in the `public` schema to the `old`.
4. Install the new SimpleSchema tables into the `public` schema.
5. Validate SQL `SELECT` queries and then use them to select from tables in the old schema into the new schema.
6. Update auto-incrementing PK sequences
7. Re-install DI audit tables/triggers and do full re-DI with new DI mappings (same DI source name!)

## Create an "old" schema and move everything from "public" to "old"

Stop DI service. Run the following in the SimpleSchema DB:
```SQL
CREATE SCHEMA old;

// move the old simpleschema tables in 'public' to 'old'
DO LANGUAGE plpgsql
$body$
DECLARE
   l_old_schema NAME = 'public';
   l_new_schema NAME = 'old';
   l_sql TEXT;
BEGIN
  FOR l_sql IN
    SELECT
        format('ALTER TABLE %I.%I SET SCHEMA %I', n.nspname, c.relname, l_new_schema)
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE
        n.nspname = l_old_schema AND
        c.relkind = 'r'
  LOOP
    RAISE NOTICE 'applying %', l_sql;
    EXECUTE l_sql;
  END LOOP;
END;
$body$;
```

## Install new SimpleSchema

Create a new virtualenv, install your desired SimpleSchema version/revision, and use `create_tables` to install all the 
new tables into the public (default) schema.

## Validate SQL SELECT queries and run INSERT queries

Review each of the SELECT queries and ensure they are not throwing any errors and are doing what is expected. Ideally 
the SELECT queries should be naming the columns the same as within the new table in the SimpleSchema public schema and 
in the same order.

When selecting and inserting PK ids the auto-incrementing PK sequence will not be aware of this and can cause errors 
with future inserts if not updated. To update it run:

```SQL
select setval('tablename_id_seq', coalesce((select max(id)+1 from public.tablename),1),false);
```

For example, to upgrade from 0.14.x to 1.2.x, the following SQL can be used (but should still be validated first!):

```SQL
--Project--
insert into public.project select id, customer_key::TEXT, coalesce(archived,0), name as key, description, coalesce(is_restricted,1) from old.project;
select setval('project_id_seq', coalesce((select max(id)+1 from public.project),1),false);

--Config-- NOTE: If old.config does not have any values in it, an error will be thrown. (Key can't be null and it doesn't have a default value)
insert into public.config select id, null as customer_key,coalesce(archived,0), null as rowhash, timezone('utc'::text,now()) as created_at, coalesce(cast(lastmod as timestamp),timezone('utc'::text,now())) as modified_at, name as key, person, confjson as config, (select id from public.project pp where pp.key=projectname) from old.config;
select setval('config_id_seq', coalesce((select max(id)+1 from public.config),1),false);
--Add configs from source, set source id to customer keys to be used later in source to get the config_ids for new source
-- Note: os.name is filling in for key here because key cannot be null. 
insert into public.config(customer_key,key,config,project_id) select cast(os.id as text) as customer_key, os.name as key, os.config as config, (select distinct project_id from old.lotobservationproject where os.id=old.lotobservationproject.source_id) from old.source os;

--Source--
insert into public.source as ps select id, name as key,(select id from public.config as pc where old.source.id::TEXT=pc.customer_key), person, uploaded, processed,purged, partial_purge from old.source;
select setval('source_id_seq',coalesce((select max(id)+1 from public.source),1),false);
--Remove source_id from config customer_key--
update config set customer_key = null where true;

--Compound--
insert into public.compound select id, customer_key::TEXT, coalesce(archived,0), rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now()) as modified_at, coalesce(mol_file,'
  MJ172100                      

  0  0  0  0  0  0  0  0  0  0999 V2000
M  END'::text), corporate_id, person, molhash, canonical_smiles, source_id from old.compound;
select setval('compound_id_seq', coalesce((select max(id)+1 from public.compound),1),false);

--Assay-- 
insert into public.assay(key,version,source_id) select distinct assay_name as key, assay_protocol as version,source_id from old.lotobservation;
insert into public.assay(key,version,source_id) select distinct assay_name as key, assay_protocol as version,source_id from old.compoundobservation where assay_name not in(select distinct assay_name from old.lotobservation);
select setval('assay_id_seq', coalesce((select max(id)+1 from public.assay),1),false);

--Experiment--
insert into public.experiment(key,assay_id,timestamp,source_id) select distinct experiment_id as key,(select id from public.assay as pa where pa.key= old.lotobservation.assay_name), coalesce(experiment_timestamp,timezone('utc'::text,now())) as timestamp, source_id from old.lotobservation;
insert into public.experiment(key, assay_id, timestamp,source_id) select distinct experiment_id as key,(select id from public.assay as pa where pa.key=old.compoundobservation.assay_name), coalesce(experiment_timestamp,timezone('utc'::text,now())) as timestamp, source_id from old.compoundobservation;
select setval('experiment_id_seq', coalesce((select max(id)+1 from public.experiment),1),false);

--Lot--
insert into public.lot select id, customer_key::TEXT, coalesce(archived,0), rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now())  as modified_at, batch_name as key, compound_id, salt,coalesce(person,'LiveDesign'::character varying), null as page_id, corp_name_full as lot_id_full, source_id from old.batch;
select setval('lot_id_seq', coalesce((select max(id)+1 from public.lot),1),false);

--Lotobservation--
insert into public.lotobservation select olo.id, customer_key::TEXT, coalesce(archived,0), rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now()) as modified_at, assay_endpoint as endpoint, assay_unit as unit, text_value, num_value, date_value, std_dev, value_operator, conc, conc_unit, null as document_id, null as page_id, batch_id as lot_id, a.id as assay_id, e.id as experiment_id, source_id from old.lotobservation olo JOIN assay a ON a.key = olo.assay_name JOIN experiment e ON e.key = olo.experiment_id and e.timestamp = olo.experiment_timestamp and e.assay_id = a.id WHERE num_nonnulls(num_value, text_value) = 1;
select setval('lotobservation_id_seq', coalesce((select max(id)+1 from public.lotobservation),1),false);

--Compoundobservation--  Endpoint can't be null, and it doesn't have a default
insert into public.compoundobservation select oco.id, customer_key::TEXT, coalesce(archived,0), rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now())  as modified_at, assay_endpoint as endpoint, assay_unit as unit, text_value, num_value, date_value, std_dev, value_operator, conc, conc_unit, null as document_id, null as page_id, compound_id, a.id as assay_id, e.id as experiment_id, source_id from old.compoundobservation oco JOIN assay a ON a.key = oco.assay_name JOIN experiment e ON e.key = oco.experiment_id and e.timestamp = oco.experiment_timestamp and e.assay_id = a.id WHERE num_nonnulls(num_value, text_value) = 1;
select setval('compoundobservation_id_seq', coalesce((select max(id)+1 from public.compoundobservation),1),false);

--Compoundobservationproject--
insert into public.compoundobservationproject select id, compound_observation_id, project_id, source_id from old.compoundobservationproject;
select setval('compoundobservationproject_id_seq',coalesce((select max(id)+1 from public.compoundobservationproject),1),false );

--Compoundproject--
insert into public.compoundproject select id, coalesce("primary",false), compound_id,project_id,(select source_id from compound where compound.id=compound_id) from old.compoundproject;
select setval('compoundproject_id_seq', coalesce((select max(id)+1 from public.compoundproject),1),false);

--Compoundproperty--
insert into public.compoundproperty select id, customer_key::TEXT, coalesce(archived,0), property_name as key, num_value, text_value, date_value, compound_id, source_id from old.compoundproperty;
select setval('compoundproperty_id_seq', coalesce((select max(id)+1 from public.compoundproperty),1),false);

--Lotproperty--
insert into public.lotproperty select id, customer_key::TEXT, coalesce(archived,0),property_name as key, num_value, text_value, date_value, batch_id as lot_id, source_id from old.lotproperty;
select setval('lotproperty_id_seq', coalesce((select max(id)+1 from public.lotproperty),1),false);

--Lotproject--
insert into public.lotproject select id,batch_id as lot_id, project_id, source_id from old.batchproject;
select setval('lotproject_id_seq',coalesce((select max(id)+1 from public.lotproject),1),false);

--Lotobservationproject--
insert into public.lotobservationproject select id, lot_observation_id, project_id, source_id from old.lotobservationproject as olop where olop.lot_observation_id in(select id from public.lotobservation)	;
select setval('lotobservationproject_id_seq',coalesce((select max(id)+1 from public.lotobservationproject),1),false);

--Etlrun--
insert into etlrun select id, to_timestamp(lastrun.timestamp) as started, to_timestamp(lastrun.timestamp) as finished, ('CREATED'::character varying) as  status, null as source_id from old.lastrun;
select setval('etlrun_id_seq', coalesce((select max(id)+1 from public.etlrun),1),false);

--CompoundAlias--
insert into public.compoundalias(alias,compound_id,source_id) 
select corporate_id_alias as alias, compound_id, source_id from old.compoundalias;
```

If upgrading from 0.14.x to ≥1.1.x the CompoundAlias mappings need to be changed to:

```SQL
--EntityAlias--
insert into public.entityAlias(alias,generic_entity_id,compound_id,source_id)
select corporate_id_alias as alias, null as generic_entity_id, compound_id, source_id from old.compoundalias;
```

An example of upgrading from a much older version of SimpleSchema (<0.14.x):

```SQL
--Project--
insert into public.project select id, null as customer_key, 0 as archived, name as key, null as description, is_restricted from old.simpleproject;
select setval('project_id_seq', coalesce((select max(id)+1 from public.project),1),false);

--Compound--
insert into public.compound select id, system_pk::TEXT as customer_key, 0 as archived, null as rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now()) as modified_at, coalesce(mol_file,'
  MJ172100                      

  0  0  0  0  0  0  0  0  0  0999 V2000
M  END'::text), corporate_id, person, hash as molhash, canonical_smiles, null as source_id from old.parentcompound;
select setval('compound_id_seq', coalesce((select max(id)+1 from public.compound),1),false);

--Assay-- 
insert into public.assay(key,version,source_id) select distinct assay_name as key, assay_protocol as version,null::integer as source_id from old.assaydata;
select setval('assay_id_seq', coalesce((select max(id)+1 from public.assay),1),false);

--Experiment--
insert into public.experiment(key,assay_id,timestamp) select distinct experiment_id as key,(select id from public.assay as pa where pa.key=old.assaydata.assay_name and pa.version=old.assaydata.assay_protocol) as assay_id, coalesce(experiment_timestamp,timezone('utc'::text,now())) as timestamp from old.assaydata;
select setval('experiment_id_seq', coalesce((select max(id)+1 from public.experiment),1),false);

--Lot--
insert into public.lot select id, system_pk::TEXT as customer_key, 0 as archived, null as rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now()) as modified_at, batch_name as key, compound_id, salt,coalesce(person,'LiveDesign'::character varying), null as page_id, corp_name_full as lot_id_full, null::integer as source_id from old.compoundbatch;
select setval('lot_id_seq', coalesce((select max(id)+1 from public.lot),1),false);

--LotObservation--
insert into public.lotobservation select oad.id, system_pk::TEXT as customer_key, 0 as archived, null as rowhash, coalesce(reg_date,timezone('utc'::text,now())) as created_at, timezone('utc'::text,now()) as modified_at,assay_endpoint as endpoint, assay_unit as unit, text_value, num_value, null as date_value,std_dev, value_operator, conc,conc_unit,null as document_id,null as page_id,batch_id as lot_id,a.id as assay_id,e.id as experiment_id, null::integer as source_id from old.assaydata oad JOIN assay a ON a.key = oad.assay_name JOIN experiment e ON e.key = oad.experiment_id and e.timestamp = oad.experiment_timestamp and e.assay_id = a.id WHERE num_nonnulls(num_value, text_value) = 1;
select setval('lotobservation_id_seq', coalesce((select max(id)+1 from public.lotobservation),1),false);

--LotObservationProject--
insert into public.lotobservationproject(lot_observation_id, project_id) select id, project_id from old.assaydata;

--CompoundProperty--
insert into public.compoundproperty select id, null as customer_key, 0 as archived, property_name as key, num_value, text_value, null as date_value, compound_id, null as source_id from old.compoundproperties;
select setval('compoundproperty_id_seq', coalesce((select max(id)+1 from public.compoundproperty),1),false);

--LotProperty--
insert into public.lotproperty select id, null as customer_key, 0 as archived, property_name as key, num_value, text_value, null as date_value, batch_id as lot_id, null as source_id from old.lotproperties;
select setval('lotproperty_id_seq', coalesce((select max(id)+1 from public.lotproperty),1),false);
```