#!/usr/bin/env python3
"""
Written By: Mike Braden
Date Added: 03/17/2022
Reason:
    Some customers find the float/real datatype too small for num_value and/or concentration columns.
"""
from argparse import ArgumentParser

from peewee import DoubleField, OperationalError
from playhouse.migrate import PostgresqlMigrator, migrate
from simpleschema.schemas import SimpleSchema
from simpleschema.models import PropertyModel, ObservationModel


def main():
    parser = ArgumentParser(
        description='Changes the datatype of num_value fields from float to double in observation tables'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost", help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3247, help="Postgres port number (default: 3247)")
    parser.add_argument("--user", default="simpleschema", help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password", default="simpleschema",
                        help="Password to login to db with (default: simpleschema")

    args = parser.parse_args()
    target = None
    try:
        target = SimpleSchema(args.database,
                              user=args.user,
                              password=args.password,
                              host=args.host,
                              port=args.port)
    except OperationalError as oe:
        print(oe)
        exit(1)
    migrator = PostgresqlMigrator(target.db)

    with target.db.atomic():
        for table_model in target.all_tables:
            if issubclass(table_model, (PropertyModel, ObservationModel)):
                table_name = table_model.get_table_name()
                if isinstance(table_model.num_value, DoubleField):
                    print(f"{table_name}.num_value has already been migrated to a double precision field. Skipping.")
                    continue
                print(f"Changing {table_name}.num_value from float to double precision")
                migrate(
                    migrator.alter_column_type(table_name, 'num_value', DoubleField())
                )
    print("\nMigration complete.")


if __name__ == "__main__":
    main()
