# SimpleSchema Architecture and Package for DataIntegrator ETL

A simplified PSQL database schema with known DI configuration. Can be written directly using SQL. Alternatively, 
includes a python interface that can be used to populate LiveDesign with real compounds and assay data. The Python API 
uses the PeeWee ORM, which represents database records as regular python objects. Whether using direct SQL or the Python
API, when the save method(s) are called, DI automatically handles synchronization with LD.

Note that the `aiosimpleschema` package has been moved to a submodule of the simpleschema package. See below for 
updated installation instructions. Any references to the `aiosimpleschema` package should be updated to use 
`simpleschema.aio`.

# SimpleSchema Architecture Details

## Table Models

Each of these classes represent actual tables in the database. Class properties represent columns, and will have the 
same name. Foreign keys are represented with an implicit "_id" column. All date fields are `timestamp without time zone` 
data type. It is strongly recommended that any timestamps with a time component, particularly auditing fields 
(e.g. `created_at`, `modified_at`, `etlrun.started_at`, etc.) use UTC time. Most but not all of these fields have 
default values of `datetime.utcnow()`.Note that any constraints and defaults are applied at both the SQL and Python API 
levels.

The syntax for the following tables' fields is:
* `fieldname`: CONSTRAINT (datatype: `default`) - description

### Project

This table contains project details and is mapped to syn_project.
 * `id`: PK/AUTO (bigserial)
 * `key`: REQUIRED/UNIQUE (varchar255) - any project name here will be added/created in LD
 * `description`: OPTIONAL (varchar255) - project description
 * `is_restricted`: REQUIRED (int2: `1`) - 1 = project/data is restricted to users with explicit access to this project; 0 = project/data is unrestricted and any user can access  
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for project from customer's source DB, API, etc.
 * `archived`: OPTIONAL (int2: 1) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"

### Compound

This table contains compound/structure information and is mapped to syn_compound. Note that `mol_file` must be in MOL or single SDF format and `corporate_id` must not match an existing entry in `EntityAlias.alias` or `GenericEntity.corporate_id`.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`; see also "Notes on Hashing" on how to detect if row values have changed)
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'person', 'corporate_id', 'mol_file', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" section)
 * `mol_file`: REQUIRED (text: `EMPTY_MOL_FILE_STRING`) - must be in MDL MOL format or single SDF
 * `corporate_id`: REQUIRED/UNIQUE (varchar255) - as it says in the tin (will be used for incremental updates unless `customer_key` is available)
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `mol_hash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of `mol_file` (see "Notes on Hashing" in Usage section)
 * `canonical_smiles`: OPTIONAL (text) - if you have it, only used for reference
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### EntityAlias

This table contains compound and generic entity aliases and is mapped to ld_entity_alias.
 * `alias`: PK/UNIQUE (varchar255) - (string) alias of compound
 * `compound_id`: FK to Compound table (either compound_id or generic_entity_id should be set)
 * `generic_entity_id`: FK to GenericEntity table (either compound_id or generic_entity_id should be set)
 * `source_id`: OPTIONAL FK to Source table

### CompoundProject

This table contains compound project ACLs and is mapped to ld_entities_projects. Note that if primary==True, then 
mapping will be for syn_compound.project, otherwise the mapping will be for ld_compounds_projects.project
 * `id`: PK/AUTO (bigserial) 
 * `compound_id`: FOREIGN KEY to Compound table
 * `project_id`: FOREIGN KEY to Project table
 * `primary`: OPTIONAL (bool: `false`) - boolean field to indicate if primary project ACL
 * `source_id`: OPTIONAL FK to Source table

### Lot

This table contains lot/batch/sample details and is mapped to syn_sample.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for lot from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'person', 'compound', 'customer_key', 'salt', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
 * `key`: REQUIRED (varchar255) - suffix of full lot ID, such as "1" of "CPD1234-1" or "02" of "CPD1234-02"; unique composite key of (`key`, `compound_id`) 
 * `compound_id`: REQUIRED/FOREIGN KEY to Compound table; unique composite key of (`key`, `compound_id`) 
 * `salt`: OPTIONAL (varchar255) - suffix of salt name of full lot+salt ID, such as "S01" of "CPD1234-02-S01"
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `page`: OPTIONAL FK to Page table - the document/notebook page of the lot; shows up in LD under the ‘Notebook Page’ database column.
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `lot_id_full`: REQUIRED/UNIQUE (varchar255) - the full ID for this lot, such as "CPD1234-02" or "CPD1234-02-S01" (if you want to use the full salt ID)
 * `source_id`: OPTIONAL FK to Source table

### LotProject

This table contains lot project ACLs and is mapped via JOIN to Compound tables to ld_compounds_projects. Note that this 
is a workaround for LiveDesign not supporting lot-level ACLs.
 * `id`: PK/AUTO (bigserial) 
 * `lot_id`: FOREIGN KEY to Lot table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

### Assay

This table holds details of type of phenomenon being measured in an assay/protocol, particularly the name 
(syn_phenomenon_type.name, e.g. "A2A Binding" or "Calculated Properties") and version 
(syn_observation_protocol.version_num; e.g. "1" or "Bob's v1.7").
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for assay/protocol/version from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'version', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `key`: REQUIRED (varchar255) - assay/protocol name; used for column naming and grouping of assays into folders; all assay endpoints will be grouped under this name
 * `version`: OPTIONAL (varchar255: `'1'`) - assay/protocol version; displays as "Protocol" in hover-over tooltips; may be used for column naming depending on whether PROTOCOL is included in aggregation mode 
 * `source_id`: OPTIONAL FK to Source table

An assay can have multiple protocol versions, contain one or more endpoints, and be run in multiple experiment runs. An 
`assay_id` is required for any Observation. The `Assay.key` field is the name of the assay/protocol (e.g. "A2A 
Binding"). It will be used in column naming, grouping of assay endpoints, and placing assays/endpoints in folders in the
LiveDesign Data & Columns tree. The `Assay.version` field is the version of the assay/protocol (e.g. "v20220401" or 
"PROTOCOL-1234") and is optional. It's value will appear in column tooltips. Depending on aggregation mode, the 
assay/protocol version can be used in column naming (default not). There is no unique constraint on the `Assay.key` 
field however there is a  unique constraint on the (`Assay.key`, `version`) composite key.

### Experiment

This table contains details of the run of a particular version of an assay/protocol on a particular date.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for experiment from customer's source DB
 * `assay_id`: REQUIRED FK to Assay table
 * `key`: OPTIONAL (varchar255) - experiment name/identifier; if set will be used as primary grouping identifier for all observations in this experiment, otherwise will use `customer_key` (if set), otherwise `id`
 * `timestamp`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when experiment was run; will be used as secondary grouping identifier; also what’s used in adv search limited to experimental dates
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'timestamp', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

The `Experiment.key` field is the name/identifier of the experiment (e.g "Box1"). A notebook/page identifier could also 
be used here, though see the "Document" and "Page" sections below. If set, the `Experiment.key` will appear in tooltips 
and be used as the "primary grouping key" to align observations from different endpoints for the same assay and 
experiment run. If `Experiment.key` is unset, the DI mappings will fall back setting the "primary grouping key" to 
`Experiment.customer_key`, then `Experiment.id`, then `'0'`. The `Experiment.timestamp` field will appear in tooltips, 
be used for advanced searching for observations by date, and will be used as the "secondary grouping date" to align 
observations from different endpoints for the same assay and experiment. If `Experiment.timestamp` is unset the 
"secondary grouping date" will fall back to `now()` (in the postgres server's timezone). 

Experiments/references from observations is optional. Because of this there is no check that the observation's 
`assay_id` is the same as the `assay_id` for the Experiment referenced by the observation's `experiment_id` field. Any 
ETLs should ensure that these values are not in conflict. If the observation row's `experiment_id` is unset then 
"primary_groupno" will be set to `'0'` and "secondary_groupno_date" will be set to `now()` (in the postgres server's 
timezone). 

### Document

This table contains document keys (names/identifiers) and will be mapped to syn_document (referred to by observation 
tables/syn_observation mappings).
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for document from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `key`: REQUIRED (varchar255) - document name/identifier (appears as "Notebook" in the hover-over tooltip) 
 * `source_id`: OPTIONAL FK to Source table

### Page

This table contains document page keys (names/identifiers) and may be referred to by syn_observation.document_page. 
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for document page from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived', 'document_id'} fields in the row (see "Notes on Hashing" in Usage section)
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `key`: REQUIRED (varchar255) - document page name/identifier (appears as "Notebook" in the hover-over tooltip)
 * `document_id`: OPTIONAL FK to Document table
 * `source_id`: OPTIONAL FK to Source table

Note that page can be a child of document (via document_id PK) OR document and page can be unrelated entities.

### CompoundProperty

This table contains compound-level properties (database columns) and will be mapped to syn_observation with 1 AS 
compound_level and 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for (compound) property from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `key`: REQUIRED (varchar255) - name of the property
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `compound_id`: REQUIRED/FOREIGN KEY to Compound table
 * `source_id`: OPTIONAL - FK to Source table

### CompoundObservation

This table contains compound-level observations and will be mapped to syn_observation with compound_level == 1.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for (compound) observation from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
 * `compound_id`: REQUIRED/FOREIGN KEY to Compound table
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `assay_id`: REQUIRED PK to Assay table; provides assay/protocol name and version
 * `experiment_id`: REQUIRED PK to Experiment table; provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
 * `endpoint`: OPTIONAL (varchar255) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
 * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
 * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
 * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
 * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
 * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
 * `page_id`: OPTIONAL FK to Page table; if unset then document_page will be set to `'0'` 
 * `document_id`: OPTIONAL FK to Document table
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### CompoundObservationProject

This table contains compound observation project ACLs and will be mapped to ld_observations_projects.
 * `compoundobservation_id`: FOREIGN KEY to CompoundObservation table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

### LotProperty

This table contains lot-level properties (database columns) and will be mapped to syn_observation
with 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for lot property from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `key`: REQUIRED (varchar255) - name of the property
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `lot_id`: REQUIRED/FOREIGN KEY to Lot table
 * `source_id`: OPTIONAL FK to Source table

### LotObservation

This table contains lot-level observations and will be mapped to syn_observation.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (varchar255) - string PK for lot property from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'lot', 'text_value', 'assay', 'std_dev', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
 * `lot_id`: REQUIRED/FOREIGN KEY to Lot table
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `assay_id`: REQUIRED PK to Assay table; provides assay/protocol name and version
 * `experiment_id`: REQUIRED PK to Experiment table; provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
 * `endpoint`: OPTIONAL (varchar255) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
 * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
 * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
 * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
 * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
 * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
 * `page_id`: OPTIONAL FK to Page table; if unset then document_page will be set to `'0'` 
 * `document_id`: OPTIONAL FK to Document table
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### LotObservationProject

This table contains lot observation project ACLs and will be mapped to ld_observations_projects.
 * `lotobservation_id`: FOREIGN KEY to LotObservation table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

### File

A table for generic entity files and mapped to ld_manageable_file and ld_data_blob.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'extension', 'person', 'project', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
 * `key`: REQUIRED (varchar255) - filename of the file
 * `extension`: REQUIRED (varchar255) - extension/type of the file
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `project_id`: FOREIGN KEY to Project table
 * `blob`: REQUIRED (bytea) - binary blob of file contents
 * `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### GenericEntity

This table holds generic entity information and is mapped to ld_generic_entity. Note that `corporate_id` must not match an existing entry in `EntityAlias.alias` or `GenericEntity.corporate_id`.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`; see also "Notes on Hashing" on how to detect if row values have changed)
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'corporate_id', 'file_id', 'person'} fields in the row (see "Notes on Hashing" section)
 * `file_id`: OPTIONAL FK to File table
 * `corporate_id`: REQUIRED/UNIQUE (varchar255) - as it says in the tin (will be used for incremental updates unless `customer_key` is available)
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table


### GenericEntityProject

This table contains generic entity project ACLs and is mapped to ld_entities_projects.
 * `id`: PK/AUTO (bigserial) 
 * `generic_entity_id`: FOREIGN KEY to Compound table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

### GenericEntityProperty

This table contains generic entity level properties (database columns; mapped to syn_observation with 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id).
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `key`: REQUIRED (varchar255) - name of the property
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `generic_entity_id`: REQUIRED/FOREIGN KEY to GenericEntity table
 * `source_id`: OPTIONAL FK to Source table

### GenericEntityObservation

This table contains generic entity level observations (mapped to syn_observation).
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
 * `generic_entity_id`: REQUIRED/FOREIGN KEY to GenericEntity table
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `assay_id`: REQUIRED PK to Assay table; provides assay/protocol name and version
 * `experiment_id`: REQUIRED PK to Experiment table; provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
 * `endpoint`: OPTIONAL (varchar255) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
 * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
 * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
 * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
 * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
 * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
 * `page_id`: OPTIONAL FK to Page table; if unset then document_page will be set to `'0'` 
 * `document_id`: OPTIONAL FK to Document table
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### GenericEntityObservationProject

This table contains generic entity observation project ACLs (mapped to ld_observations_projects).
 * `generic_entity_observation_id`: FOREIGN KEY to GenericEntityObservation table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

### Structure

This table is for representing structures for 3D assays (mapped to ld_structure, ld_structure_data, and ld_data_blob). The records here must be referenced by an observation table for the data to show up in LD.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'type', 'format', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
 * `key`: REQUIRED (varchar255) - the name of the structure to shows up in the 3D visualizer
 * `type`: REQUIRED (varchar255) - the type of the 3D structure; must be one of ('LIGAND', 'PROTEIN', 'OTHER', 'ANIMATION')
 * `format`: REQUIRED (varchar255) - extension/type of the file; must be one of ('PSE', 'MAE', 'MAEGZ', 'VIB')
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `blob`: REQUIRED (bytea) - binary blob of file contents
 * `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### Pose

This table is for representing poses in LiveDesign (mapped to ld_pose). Pose records must be created if you want to create pose-level data in an observation table. Different poses show up as different rows in row-per-pose mode.
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'compound', 'generic_entity', 'key', 'person'} fields in the row (see "Notes on Hashing" in Usage section)
 * `compound_id`: OPTIONAL FK to Compound table (one of `compound_id` or `generic_entity_id` must be set)
 * `generic_entity_id`: OPTIONAL FK to Compound table (one of `compound_id` or `generice_entity_id` must be set)
 * `key`: REQUIRED (varchar255) - suffix of full pose ID, such as "1" of "CPD1234#1" or "02" of "GEN1234#02" 
 * `pose_id_full`: REQUIRED/UNIQUE (varchar255) - the full ID for this pose, such as "CPD1234#1" or "GEN1234#02"
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
 * `project_id`: OPTIONAL FK to Project table - the project associated with the pose; no user effect right now
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

Note that `key` and `pose_id_full` are not used by DI and are merely used for ensuring unique identification for compound and generic entity poses. If only `key` is provided then the `pose_id_full` will be appended to the parent's corporate_id with a `'#'` separator.

### PoseObservation

This table contains pose level observations (mapped to syn_observation).
 * `id`: PK/AUTO (bigserial)
 * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
 * `archived`: OPTIONAL (int2: `1`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
 * `pose_id`: REQUIRED/FOREIGN KEY to Pose table
 * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
 * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
 * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
 * `structure_id`: OPTIONAL/UNIQUE FK to Structure table - structure value for the property (only one value should be set)
 * `assay_id`: REQUIRED PK to Assay table; provides assay/protocol name and version
 * `experiment_id`: REQUIRED PK to Experiment table; provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
 * `endpoint`: OPTIONAL (varchar255) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
 * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
 * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
 * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
 * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
 * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
 * `page_id`: OPTIONAL FK to Page table; if unset then document_page will be set to `'0'` 
 * `document_id`: OPTIONAL FK to Document table
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `source_id`: OPTIONAL FK to Source table

### PoseObservationProject

This table contains generic entity observation project ACLs (mapped to ld_observations_projects).
 * `pose_observation_id`: FOREIGN KEY to PoseObservation table
 * `project_id`: FOREIGN KEY to Project table
 * `source_id`: OPTIONAL FK to Source table

## ETL/Audit Table Models

Note that the Source, Config, and ETLRun tables are optional and are only used for auditing purposes and particular 
ETL implementations.

### Source (auditing table not used by DI)

This table tracks uploads of data into the SimpleSchema (ETL runs).
 * `id`: PK/AUTO (bigserial)
 * `key`: REQUIRED/UNIQUE (varchar255) - filename or other reference for data source
 * `config`: OPTIONAL (varchar255) - JSON field to store config settings used for loading data from source
 * `lastlog`: OPTIONAL (varchar255) - filename of last log file related to source
 * `lastreport`: OPTIONAL (text) - CLOB of last summary report related to source
 * `person`: OPTIONAL (varchar255: `'LiveDesign'`) - name of person who uploaded data source
 * `projectname`: OPTIONAL (varchar255) - project name to associate data upload with
 * `uploaded`: OPTIONAL (timestamp) - timestamp source was uploaded
 * `processed`: OPTIONAL (timestamp) - timestamp source was processed
 * `purged`: OPTIONAL (timestamp) - timestamp source was purged
 * `partial_purge`: OPTIONAL (int2) - whether source was partially (1) or fully purged (0)

### Config (auditing table not used by DI)

This table holds ETL config information.
 * `id`: PK/AUTO (bigserial)
 * `confjson`: OPTIONAL (json) - JSON field to store config settings used for loading/transforming data
 * `key`: REQUIRED/UNIQUE (varchar255) - name for configuration settings
 * `projectname`: OPTIONAL (varchar255) - project name to associate all data uploaded with this config
 * `projectdefault`: OPTIONAL (int4) - whether to use projectname as default project for all data
 * `person`: OPTIONAL (varchar255) - name of person who created/updated config
 * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
 * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
 * `archived`: OPTIONAL (int2: `1`) - "soft delete" option; 1 for archived/"deleted"
 * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'archived', 'config', 'customer_key', 'key', 'person', 'project'} fields in the row (see "Notes on Hashing" in Usage section)

### ETLRun (auditing table not used by DI)

This table tracks the start/end times and status of the last ETL run. There is an optional relationship to the Source 
table to track config used, filenames or other identifiers, etc.
 * `id`: PK/AUTO (bigserial)
 * `started`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when ETL run was started/record was created
 * `finished`: OPTIONAL (timestamp without timezone) - timestamp of when ETL run was finished
 * `status` = OPTIONAL (varchar255: `'CREATED'`) - status of ETL run; suggested labels are CREATED, RUNNING, LOAD_FINISHED, LOAD_FAILED, FINISHED, FAILED
 * `source` = OPTIONAL FK to Source table
 
## Primary Key, `customer_key`, and `key` fields

All tables have an auto-incrementing big integer primary key field `id`. Primary keys should not be re-used, for example
if data is deleted and reloaded into the schema, otherwise the Data Integrator service may ignore those rows as already 
processed. The `id` fields are used in any foreign key relationships between tables (e.g. 
`Lot.compound_id -> Compound.id`).

Most tables have a `customer_key` field for storing (string) primary keys from the customer's source database. It is 
strongly recommended using these values if they are available as they can allow for incremental updates, particularly 
of observation, experiment, and/or assay rows. The `customer_key` can also be useful for updating the `key` or other 
unique identifiers for an entity, `Compound.corporate_id` for example.

The `key` fields in tables are for storing (string) name/identifiers for the entity. Most `key` fields contain a unique 
index and can be used for querying. The exceptions for this are:

* In the Compound table, the `Compound.corporate_id` field is for storing the unique string identifier of the compound 
(e.g. `'CPD1'`).
* In the Lot table, the `Lot.key` field is used for storing the batch name/identifier (e.g. `'1'`) with a non-unique index and the 
`Lot.lot_id_full` is for storing the full lot ID (e.g. `'CPD1-1'`) and has a unique index.
* In the Pose table, the `Pose.key` is used for storing the pose name/identifier (e.g. `'1'`) for either a compound or 
generic entity parent with a non-unique index and the `Pose.pose_id_full` is for storing the full pose ID (e.g. 
`'CPD1#1'` or `'GEN1#02'`) and has a unique index.
* In the File and Structure tables, the `key` field is used for storing the filename or name of the structure but does 
not have a unique index. 

## Compound and Generic Entity corporate IDs and aliases integrity

`Compound` and `GenericEntity` parent entities share a common `EntityAlias` table. In order to ensure identity integrity 
across these parent entities the following must be observed: 

* A `compound.corporate_id` should not be registered that matches an existing `genericentity.corporate_id`
* A `genericentity.corporate_id` should not be registered that matches an existing `compound.corporate_id`
* An `entityalias.alias` Aliases should not be registered that matches an existing `compound.corporate_id` or `genericentity.corporate_id`

The simpleschema python API has checks for these in the `prep_and_validate_values()` and/or `register()` methods each of 
these table models. Direct SQL users should do their own integrity checks before registering or updating `corporate_id` 
or `alias` values.

## Observation endpoint and value(s)

An observation row's `endpoint` field is the particular type of observation being measured in a given assay (e.g. "Ki", 
"IC50", "% Inhibition"). An assay can have more than one endpoint associated with it. The endpoint, along with `unit`, 
`conc`, and `conc_unit`, will be used to name the assay column in LiveDesign. All endpoints with the same `Assay.key` 
will be grouped under that assay and its folder in the LiveDesign Data and Columns tree. 

Only one of `text_value`, `num_value`, `date_value`, or `structure_id` (PoseObservation table only) should be used for 
any property or observation. If using the Python API, the `simpleschema.utils.try_cast_as_float()`, 
`simpleschema.models.ExtendedBaseModel.check_num_text_date_values()`, and/or 
`simpleschema.utils.parse_operator_and_convert_to_number()` helper methods can help automatically parse a property or 
observation value. 

Note DI will coalesce an observation row's `(experiment.key, experiment.customer_key, experiment.id, '0')` to set the 
"primary grouping key" for all endpoints in the same assay+version+experiment+compound/lot. This "primary grouping key" 
is used for aligning values from different endpoints for the same compound/lot in the same 
assay/version + experiment run, particularly in Row per Experiment mode. Different compounds/lots for the same 
experiment run can use the same "primary grouping key" and thus the same experiment row or default `'0'` value. If, 
however, there are more than one replicate of the same compound/lot in the experiment run then each replicate for the 
same compound/lot should get a unique Experiment set, thus allowing them to have unique "primary grouping key" values. 
For example, if CPD1 is run twice in experiment you could name one experiment `Experiment` and the other `Experiment-1`. 
Another option would be to concatenate the Box ID or file/row number and register a new experiment for every replicate 
in the experiment run. This is particularly useful for loading data from flat files such as SDF or CSV but can cause 
excessive data replication in the Experiment table.

## Generic Entity and Structure files

SimpleSchema supports loading files for Generic Entities or (Pose Observation) Structures as binary data into the `blob` 
field of the `File` and `Structure` tables, respectively. File name or content/hash uniqueness is not enforced. It is 
strongly recommended to check for file uniqueness before registering files (see Note on Hashing section below). 

## Updates vs. full reloads

If the data provides a unique key for individual data points or compounds they can optionally store them in the database
with the "customer_key" fields. This may allow for data to be updated incrementally by comparing new values with those 
stored previously, which is favorable for LD performance. In cases where updates/inserts can not be simply parsed, it is
often reasonable to clear all assay values and reload from scratch on some regular basis.

### Storing canonical smiles and mol_files
There are separate fields in the Compound class for `canonical_smiles` and `mol_files`. Data Integrator requires a MOL 
file to register structures, but MOL files are poorly standardized. The canonical SMILES field is provided as a 
convenience to determine if a structure has been updated, and is optional. Note that string comparison of (canonical) 
SMILES or MOL/SDF is a slow and inaccurate method of comparing whether two structures are different. A 
`Compound.mol_hash` field is also available for quickly checking for differences in the `mol_file` field. See "Notes on 
Hashing" section below.

### Note on Hashing

The many of the SimpleSchema table models provide a column for storing a hash of select columns in the row (`rowhash`). 
This hash allows for the quick comparison of entities for detecting differences between corresponding SimpleSchema and 
source DB rows. In the Python API, example/suggested fields (columns) are provided for each "hashable" model (table) 
(`Model.hashable_fields`). These fields and/or the methods to generate the hash can be customized. By default, the 
Python API will automatically calculate the `rowhash` when using the Model.register() method, though note that only fields 
that are in the `hashable_fields` list AND in the model will be used to generate the (auto)hash. For 
example, the LotObservation and CompoundObservation both have `compound` and `lot` in their `hashable_fields` list but 
`lot` will only be used for LotObservation and `compound` will only be used for CompoundObservation. Any methods that 
update fields in a (hashable) model entity/row should also update the `rowhash`.  

Any ETL script utilizing the `rowhash` column for comparisons should ensure that the list of columns/fields, name of keys, 
and their order in the dictionary object used to generate/compare the hash value is the same for both the source DB and 
the SimpleSchema.  

The Compound table model also provides a column for storing a hash of the `mol_file` field. This hash allows for the 
quick comparison of the row's `mol_file` for differences. Any ETL script should ensure that this hash is generated 
using the same algorithm for new and existing rows. The Python API defaults to using MD5 on the binary encoded 
`mol_file` string.

The File and Structure table models also provide columns for storing a hash of the `blob` field. This hash allows for the 
quick comparison of the row's `mol_file` for differences and/or duplicates. Any ETL script should ensure that this hash 
is generated using the same algorithm for new and existing rows. The Python API defaults to using SHA256, returning a 
hexdigest string, for the `blob_hash` fields in these tables.

# Using the SimpleSchema Python API

## SimpleSchema Python Package Installation

### Requirements

 * Python ≥ 3.8 virtual environment
 * All other package requirements are managed by pip

### SimpleSchema Setup

1. If you have not already, create your database, create a user, and grant all privileges to that user:
```bash
psql -h localhost -p 3247 -U postgres -c "CREATE DATABASE example_db"
psql -h localhost -p 3247 -U postgres -c "CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_pass'"
psql -h localhost -p 3247 -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE example_db to example_user"

```
2. Find the [simpleschema release tar.gz file](https://github.com/schrodinger/livedesign-simpleschema/releases "livedesign-simpleschema GitHub releases page") for the version you want to install and download/transfer it to where you want to install the package.
3. Set up a virtualenv (python ≥ 3.8) and install the simpleschema package (in this example, release tag=`v1.1.0`):
```bash
virtualenv -p `which python3` venv
source venv/bin/activate
pip3 install livedesign-simpleschema-1.1.0.tar.gz
```
If you want extra features, such as AIO or Web API, add them to the egg as a csv with no spaces (on OSX/ZSH you may need to escape the first square bracket): 
```bash
# ensure AIO requirements are met:
pip3 install livedesign-simpleschema-1.1.0.tar.gz\[aio]

# ensure Web API requirements are met:
pip3 install livedesign-simpleschema-1.1.0.tar.gz\[web]

# ensure that both AIO and Web API requirements are met:
pip3 install livedesign-simpleschema-1.1.0.tar.gz\[aio,web]
```
4. Create tables (change `example_db`, `example_user`, and `example_pass` appropriately):
```bash
create_tables --user example_user --password example_pass example_db
```
(run `create_tables -h` for more options)

### Development Setup

To install the SimpleSchema in a development environment, first clone the livedesign-simpleschema git repo 
(https://github.com/schrodinger/livedesign-simpleschema.git) and checkout a new or existing branch. After creating and 
activating your virtualenv, run:

```bash
virtualenv -p `which python3` venv
source venv/bin/activate
pip3 install -e livedesign-simpleschema/.
# Add any optional features in a similar way as above, example:
# pip3 install -e /path/to/livedesign-simpleschema/.\[aio]
```

For development work you can manually start a Postgresql 10 Docker container and create the database for use with the 
python API:

```bash
# This must be run in a virtualenv with the simpleschema package installed and by a user who has docker privs
PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema -e POSTGRES_PASSWORD=simpleschema postgres:10)
sleep 2
docker exec $PGCONTAINER psql -U simpleschema -c "CREATE DATABASE example_db"
create_tables example_db --port 3248
# to run interactive psql from outside the container:
PGPASSWORD=simpleschema psql -h localhost -p 3248 -U simpleschema -d example_db
```

When you are done with the docker container you can stop/remove it with:

```bash
docker rm -f $PGCONTAINER
```

## Using the Python API

The SimpleSchema class offers a few utility and class functions which can be used interactively or in your ETL scripts. 
See `livedesign-integrations/SDFU/` for examples of customizing the peewee/simpleschema objects and 
methods for writing to the SimpleSchema database.
* `simpleschema.models.ExtendedBaseModel` class has methods that all Model classes inherit, with the ability to customize these on a per-model basis, such as:
  * `prep_and_validate_values()`: prepare and validate kwargs before register() method is called
  * `value_to_kwargs()`: try to parse a `value` parameter to a dict with number (with operator), text, or date value
  * `check_num_text_date_values()`: do some validation on the number, text, and date value
  * `register()`: get_or_create a model instance with the provided parameters 
* `simpleschema.utils` has additional static helper methods, such as:
  * `generate_hash()`: generate an MD5 hash of the provided string or dict
  * `try_cast_as_float()`: try to cast a provided string value as a float
  * `parse_operator_and_convert_to_number()`: try to strip out allowed operators from a string value and cast the rest as a float
  * `file_full_path_to_kwargs()`: takes a (full/relative) file path, reads the file, and returns a dictionary of filename, extension, and blob
* `simpleschema.models.compound` has `register_alias()`, `register_lot()`, and `switch_primary()` methods 
* `simpleschema.models.compound` and `lot` have `register_acl()`, `register_observation()`, and `register_property()` methods
* Assay and/or full data clearing methods (these should be avoided in production):
  * `simpleschema.schema.SimpleSchema.clear_assay_values()`: method to delete all existing assay data. Used in cases where incremental changes are not available from the source data. It is strongly recommended to not use this method.
  * `simpleschema.schema.SimpleSchema.clear_all()`: method to truncate all tables and reset all identity sequences. Use sparingly and only in testing. If used in prod, a full re-DI is required each time.

### Insert, Update, Delete \[Interactive]

All database values can be inserted, updated, or deleted from the python interpreter. For example, you can quickly update a compound structure or change specific assay values by manipulating the ORM objects. Please see the PeeWee documentation for additional details.

```python
from simpleschema.schemas import SimpleSchema
from simpleschema.models import Project, Compound, Lot, LotObservation
 
mol = '''some MOL file string''' 
corp_id = 'CPD1234'
batch_no = 1
target_schema = SimpleSchema('NAME_OF_DATABASE')
with target_schema.db.atomic():
    global_project = Project.register(key='Global', is_restricted=0)
    compound = Compound.register(project=global_project, mol_file=mol, corporate_id=corp_id)
    lot = Lot.register(compound=compound, key=batch_no)
    assay_result = lot.register_observation(assay_name='Foo', endpoint='Bar', num_value=23)
    # or
    assay_result2 = LotObservation.register(lot=lot, assay_name='Foo', endpoint='Bar', num_value=42)
```
These objects can be queried and updated, and once saved will be updated immediately in LD.
```python
from simpleschema.models import Compound


cmpd = Compound.get(key='CPD1234')
cmpd.mol_file = '''some new MOL file string'''
cmpd.save()
```

### The BaseModel.prep_and_validate_values() and register() methods

The `prep_and_validate_values()` method will, after any Model-specific overrides, strip out any arguments that do not 
match fields in the model class. In addition, if any of the arguments refer to another model (e.g. `compound=foo`) and 
the value of that argument is not a Model class (e.g. `CompoundProject.register(compound='CPD1')`) the 
`prep_and_validate_values()` will attempt to get the model instance based on the `Model.lookup_field` (e.g. 
`compound=Compound.get(corporate_id='CPD1')`). If this model entity does not exist (e.g. a compound with 'CPD1' 
corporate ID has not been registered yet) then a `peewee.DoesNotExist` exception will be raised. If multiple models 
exist with the provided kwargs (e.g. `Assay.get(key='Foo')` where there are multiple assays with name 'Foo' and 
different versions) then only one will be returned. Note that subsequent gets with the same query may return a different
entity.

The `register()` method on all table models will use the peewee `get_or_create()` method on provided kwargs, passing 
them to `prep_and_validate_values()`. If the model has a unique constraint on any of the fields 
(e.g. `Compound.corporate_id`) and the kwargs only matches this field and is trying to register a different value for 
another field then an IntegrityError will be raised. For example: a compound has already been registered with 
`Compound.corporate_id == 'CPD1'` and `Compound.person == None`. A user attempts to register 
`Compound.register(corporate_id='CPD1', person='Bob Dobbs')`; this will raise the IntegrityError exception.

It is strongly recommended registering all entities with explicit keyword arguments, particularly those involved in FK 
relationships. For example, when registering observations, the Assay, Experiment, Document, and Page entities should be 
registered first and then passed to the observation's register 

### Transactions

Peewee will autocommit on individual operations, so it's often best to wrap procedures in a database transaction. In the 
event of an error, no changes will be written to the database and the transaction is rolled back. For this, you can use 
the SimpleSchema.db.atomic() context wrapper. Example:
```python
from simpleschema.schemas import SimpleSchema
from simpleschema.models import Project

target_schema = SimpleSchema('NAME_OF_DATABASE')
with target_schema.db.atomic():
     project = Project.register(key='Test', is_restricted=1)
```

## Using Asynchronous IO (AIO) Features

To utilize AIO features in the SimpleSchema python API just use the schema and models from `simpleschema.aio` and add an 
`await` before any async method. Example:

```python
from simpleschema.aio.schemas import SimpleSchemaAsync
from simpleschema.aio.models import Project

target_schema = SimpleSchemaAsync('NAME_OF_DATABASE')
project = await Project.register(key='Test', is_restricted=1)
```

## Customizing Schemas, (Table) Models, Utilities, and Helper Methods

SimpleSchema is provided as a package that can be installed using pip. Any customizations to any part of the 
simpleschema package can be done by either creating a custom branch for your changes or merely adding files to the 
livedesign-simpleschema/simpleschema directory structure without adding them to git (master). This will allow you to 
inherit and override any classes or methods while still pulling updates/bug fixes from the master repo. An example 
(`simpleschema/custom.py`):
```python
"""Example file for creating your own custom Schema class, Model class, or other functions/overrides. Create a 
custom.py file in the simpleschema package directory (tracked in your branch but not in master). You would call this 
file 'from simpleschema.custom import MySchema'"""
from simpleschema.schemas import SimpleSchema
from simpleschema import models


class Foo(models.Project):
    """Some overrides"""


class MySchema(SimpleSchema):
    """Some overrides and using other custom classes like the Foo model class above"""

```

# Using the SimpleSchema WebAPI

Note that the SimpleSchema WebAPI is still under development and should not be used in a production environment. 

## SimpleSchema WebAPI Installation

### Requirements

 * Python ≥ 3.8 virtual environment
 * simpleschema package installed with `web` optional features included (e.g. `pip3 install livedesign-simpleschema-release-v1.1.0.tar.gz\[web]`)
 * SimpleSchema database and all tables created
 
### WebAPI Setup

Within the virtualenv, set any of the following environment variables if the shown defaults are not desired:

```bash
export DATABASE=simpleschema
export DB_HOST=localhost
export DB_PORT=3247
export DB_USER=simpleschema
export DB_PASS=simpleschema
export SECRET_KEY=$(python -c 'import secrets; print(secrets.token_hex())') # used for securely signing the session cookie; can be any string
export API_PORT=8870
export API_TIMEOUT=172800
export API_WORKERS=2
```

While still in the virtualenv, run gunicorn:

```bash
gunicorn -b 127.0.0.1:${API_PORT} --timeout ${API_TIMEOUT} --workers ${API_WORKERS} simpleschema.webapi:app
```

### Development Setup

By default, the WebAPI will use the LiveDesign session/cookies to verify that the user has LD Admin role. In a 
development/testing environment you can skip this check by setting the following environment variable to any value:

```bash
export SIMPLESCHEMA_DEBUG=1
```

## Using the Web API

The Web API has the following routes defined:
* `/livedesign/simpleschema/api/find/project`
* `/livedesign/simpleschema/api/find/compound`
* `/livedesign/simpleschema/api/find/lot`
* `/livedesign/simpleschema/api/register/project`
* `/livedesign/simpleschema/api/register/compound`
* `/livedesign/simpleschema/api/register/lot`

All API endpoints will accept GET (query parameters; e.g `?key=Foo`) or POST (`content-type: application/json` header 
and JSON body) requests. If a related table model/foreign key needs referencing (e.g. `Compound.project` or 
`Lot.compound`) then it should be provided in the query args/dict as `model_id` with the PK of that model entity. For 
example: `/livedesign/simpleschema/api/register/lot?compound_id=1&key=23`

# Using the SimpleSchema SQL API

## SimpleSchema SQL Installation

### Requirements

 * Postgresql ≥ 10
 * DBA access

### SimpleSchema Setup

Download/transfer the [simpleschema release tar.gz file](https://github.com/schrodinger/livedesign-simpleschema/releases "livedesign-simpleschema GitHub releases page") 
for the version you want to install to your database instance. For this example, the release tag is `v1.1.0` for version `1.1.0`:

```bash
tar xzf livedesign-simpleschema-1.1.0.tar.gz livedesign-simpleschema-1.1.0/example_schema/simpleschema.sql
```

This file will create the database (default: `simpleschema`), all tables and relations, and change ownership to a 
particular user (default: `simpleschema`). If the default DB name and username are not desired be sure to search and 
replace the database name (`simpleschema`) and DB username (`simpleschema`) in the SQL file with the appropriate names 
before loading. If you have already created the database, remove the `CREATE DATABASE` line from the sql file. 

Be sure the user exists before loading the SQL file. Example:

```bash
psql -h localhost -p 3247 -U postgres -c "CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_pass'"
```

Load the SQL dump file using psql and a DBA user. Example:

```bash
psql -h localhost -p 3247 -U postgres -f livedesign-simpleschema-1.1.0/example_schema/simpleschema.sql
```

### Create a DB User and Grant Access

Connect to the database as a DBA user, for example:

```bash
psql -h localhost -p 3247 -U postgres -d example_db
```

Grant all privileges:

```sql
CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_pass';
GRANT ALL PRIVILEGES ON DATABASE example_db to example_user;
```

Grant limited privileges:

```sql
CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_password';
REVOKE ALL ON DATABASE example_db FROM example_user;
GRANT CONNECT ON DATABASE example_db TO example_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON ALL TABLES IN SCHEMA public TO example_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO example_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO example_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO example_user;
```

## Using the SQL API

Inserting new entries should be done in parent->child order (e.g Compound then Lot). Updating existing entities or 
inserting new child entities should look up one of the (parent) entity' unique field (e.g. `customer_key`, `key`, 
`corporate_id`) or combination of fields (e.g. `assay.key + assay.version`). Using the `customer_key` fields when 
inserting new rows and querying for rows is strongly preferred.

### Example registrations

```sql
INSERT INTO project(key,is_restricted) VALUES ('Global', 0);
INSERT INTO project(key,is_restricted) VALUES ('Default Restricted Project', 1);
INSERT INTO compound(corporate_id,mol_file) VALUES ('CPD1', E'your mol file string here');
INSERT INTO compoundproject(compound_id,project_id,"primary") 
 SELECT c.id,p.id,true 
 FROM compound c, project p
 WHERE c.corporate_id = 'CPD1' AND p.key = 'Global';
INSERT INTO lot(compound_id,key,lot_id_full) 
 SELECT c.id,'1',CONCAT(c.corporate_id,'-1') 
 FROM compound c 
 WHERE c.corporate_id = 'CPD1';
INSERT INTO compoundproperty(compound_id,key,num_value)
 SELECT c.id, 'Some Property', 1.23
 FROM compound c
 WHERE c.corporate_id = 'CPD1';
INSERT INTO assay(key,version) VALUES ('Assay1', 'Version1');
INSERT INTO compoundobservation(customer_key, compound_id, assay_id, endpoint, text_value)
 SELECT 1, c.id, a.id, 'Some Endpoint', 'Some text value'
 FROM compound c, assay a
 WHERE c.corporate_id = 'CPD1' AND (a.key = 'Assay1' AND a.version = 'Version1');
INSERT INTO compoundobservationproject(compound_observation_id,project_id)
 SELECT co.id,p.id 
 FROM compoundobservation co, project p
 WHERE co.customer_key = 1 AND p.key = 'Global';
```
