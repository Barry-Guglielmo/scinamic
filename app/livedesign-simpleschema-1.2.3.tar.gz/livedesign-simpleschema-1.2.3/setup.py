import os
import re
from setuptools import setup, find_packages

VERSIONFILE = "simpleschema/version.py"
verstrline = open(VERSIONFILE, "rt").read()
VSRE = r"^__version__ = ['\"]([^'\"]*)['\"]"
mo = re.search(VSRE, verstrline, re.M)
if mo:
    verstr = mo.group(1)
else:
    raise RuntimeError("Unable to find version string in %s." % (VERSIONFILE,))


def package_files(directory):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.join('..', path, filename))
    return paths


extra_files = package_files('simpleschema/docs')  # find all docs files recursively

setup(name='simpleschema',
      version=verstr,
      description='Simple PSQL schema for LiveDesign Data Integrator',
      url='http://github.com/schrodinger/livedesign-simpleschema',
      author='Michael Braden',
      author_email='michael.braden@schrodinger.com',
      license='MIT',
      packages=find_packages(),
      package_data={'': extra_files},  # Include documentation
      python_requires='>=3.8.0',
      install_requires=['psycopg2-binary==2.9.3', 'peewee==3.14.10'],
      extras_require={
          'aio': [
              'aio-peewee>=0.4.0', 'aiosqlite==0.16.0',
              'vroom @ git+https://github.com/schrodinger/livedesign-vroom.git@v1.0.0'
          ],
          'web': ['requests==2.27.1', 'gunicorn==19.9.0', 'Flask==2.0.3', 'Werkzeug==2.2.2']
      },
      scripts=['tests/run_simpleschema_tests', 'tests/run_aio_simpleschema_tests'],
      entry_points={'console_scripts': ['create_tables=simpleschema.create_tables:main',
                                        'ss_docsrv=simpleschema.docsrv:main']},
      zip_safe=False)
