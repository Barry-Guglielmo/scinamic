# SimpleSchema

A simplified PSQL database schema with known DI configuration. Can be written directly using SQL. Alternatively, 
includes a python interface that can be used to populate LiveDesign with real compounds and assay data. The Python API 
uses the PeeWee ORM, which represents database records as regular python objects. Whether using direct SQL or the Python
API, when the save method(s) are called, DI automatically handles synchronization with LD.

# SimpleSchema Documentation

The SimpleSchema documentation has been moved to sphinx/autodoc generated HTML docs. These can be accessed in several 
ways:

* untar/unzip the SimpleSchema release package, navigate to the `simpleschema/docs/html` directory and open `index.html` in your favorite browser
* if you have installed the SimpleSchema package into a python virtual environment, you can find the docs in `<venv dir>/lib/python<version>/site-packages/simpleschema/docs/html`
* if you have installed the SimpleSchema package using the `web` optional features (e.g. `pip3 install livedesign-simpleschema-1.2.3.tar.gz\[web]`), you can run (in the activated virtual env) `ss_docsrv` to start a small Flask service and go to http://localhost:8880 to view the docs

