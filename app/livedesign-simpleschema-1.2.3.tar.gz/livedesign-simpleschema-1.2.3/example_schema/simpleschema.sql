--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Debian 14.8-1.pgdg110+1)
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assay; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assay (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    version text DEFAULT '1'::text NOT NULL,
    source_id bigint
);


--
-- Name: assay_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assay_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assay_id_seq OWNED BY public.assay.id;


--
-- Name: assaymetadatavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assaymetadatavalue (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    key_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    show_time_component boolean DEFAULT false,
    CONSTRAINT only_one_or_none_assaymetadata_value CHECK ((num_nonnulls(num_value, text_value, date_value) <= 1))
);


--
-- Name: assaymetadatavalue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assaymetadatavalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assaymetadatavalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assaymetadatavalue_id_seq OWNED BY public.assaymetadatavalue.id;


--
-- Name: compound; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compound (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    mol_file text DEFAULT '
  MJ172100                      

  0  0  0  0  0  0  0  0  0  0999 V2000
M  END'::text NOT NULL,
    corporate_id text NOT NULL,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    molhash character varying(255),
    canonical_smiles text,
    source_id bigint
);


--
-- Name: compound_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compound_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compound_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compound_id_seq OWNED BY public.compound.id;


--
-- Name: compoundobservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compoundobservation (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    endpoint text NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    compound_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


--
-- Name: compoundobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compoundobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compoundobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compoundobservation_id_seq OWNED BY public.compoundobservation.id;


--
-- Name: compoundobservationproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compoundobservationproject (
    id bigint NOT NULL,
    compound_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: compoundobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compoundobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compoundobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compoundobservationproject_id_seq OWNED BY public.compoundobservationproject.id;


--
-- Name: compoundproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compoundproject (
    id bigint NOT NULL,
    "primary" boolean DEFAULT false NOT NULL,
    compound_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: compoundproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compoundproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compoundproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compoundproject_id_seq OWNED BY public.compoundproject.id;


--
-- Name: compoundproperty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compoundproperty (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    key text NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    compound_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: compoundproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.compoundproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: compoundproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.compoundproperty_id_seq OWNED BY public.compoundproperty.id;


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    person text,
    config json,
    project_id bigint
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key character varying(255) NOT NULL,
    source_id bigint
);


--
-- Name: document_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_id_seq OWNED BY public.document.id;


--
-- Name: entityalias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entityalias (
    id bigint NOT NULL,
    alias text NOT NULL,
    generic_entity_id bigint,
    compound_id bigint,
    source_id bigint,
    CONSTRAINT only_one_parent_set CHECK ((num_nonnulls(generic_entity_id, compound_id) = 1))
);


--
-- Name: entityalias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entityalias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entityalias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entityalias_id_seq OWNED BY public.entityalias.id;


--
-- Name: entitymetadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entitymetadata (
    id bigint NOT NULL,
    key text NOT NULL,
    folder_path text,
    value_type character varying(255) DEFAULT 'STRING'::character varying NOT NULL,
    CONSTRAINT metadata_allowed_value_types CHECK ((upper((value_type)::text) = ANY (ARRAY['INTEGER'::text, 'FLOAT'::text, 'STRING'::text, 'DATE'::text, 'DATETIME'::text])))
);


--
-- Name: entitymetadata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entitymetadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entitymetadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entitymetadata_id_seq OWNED BY public.entitymetadata.id;


--
-- Name: entitymetadatavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entitymetadatavalue (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    key_id bigint NOT NULL,
    genericentity_id bigint NOT NULL,
    CONSTRAINT only_one_or_none_entitymetadata_value CHECK ((num_nonnulls(num_value, text_value, date_value) <= 1))
);


--
-- Name: entitymetadatavalue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entitymetadatavalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entitymetadatavalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entitymetadatavalue_id_seq OWNED BY public.entitymetadatavalue.id;


--
-- Name: entityrelationshipchild; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entityrelationshipchild (
    id bigint NOT NULL,
    entity_id bigint NOT NULL,
    parent_id bigint NOT NULL,
    child_order smallint NOT NULL
);


--
-- Name: entityrelationshipchild_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entityrelationshipchild_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entityrelationshipchild_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entityrelationshipchild_id_seq OWNED BY public.entityrelationshipchild.id;


--
-- Name: entityrelationshipmetadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entityrelationshipmetadata (
    id bigint NOT NULL,
    relationship_child_id bigint NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: entityrelationshipmetadata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entityrelationshipmetadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entityrelationshipmetadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entityrelationshipmetadata_id_seq OWNED BY public.entityrelationshipmetadata.id;


--
-- Name: entityrelationshipparent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entityrelationshipparent (
    id bigint NOT NULL,
    entity_id bigint NOT NULL,
    relationship_type text NOT NULL
);


--
-- Name: entityrelationshipparent_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entityrelationshipparent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entityrelationshipparent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entityrelationshipparent_id_seq OWNED BY public.entityrelationshipparent.id;


--
-- Name: etlrun; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.etlrun (
    id bigint NOT NULL,
    started timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text) NOT NULL,
    finished timestamp without time zone,
    status character varying(255) DEFAULT 'CREATED'::character varying,
    source_id bigint
);


--
-- Name: etlrun_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.etlrun_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: etlrun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.etlrun_id_seq OWNED BY public.etlrun.id;


--
-- Name: experiment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experiment (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    assay_id bigint NOT NULL,
    key text DEFAULT '0'::text,
    "timestamp" timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    source_id bigint
);


--
-- Name: experiment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.experiment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: experiment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.experiment_id_seq OWNED BY public.experiment.id;


--
-- Name: experimentmetadatavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.experimentmetadatavalue (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    key_id bigint NOT NULL,
    assay_level boolean DEFAULT false NOT NULL,
    experiment_id bigint NOT NULL,
    show_time_component boolean DEFAULT false,
    CONSTRAINT only_one_or_none_experimentmetadata_value CHECK ((num_nonnulls(num_value, text_value, date_value) <= 1))
);


--
-- Name: experimentmetadatavalue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.experimentmetadatavalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: experimentmetadatavalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.experimentmetadatavalue_id_seq OWNED BY public.experimentmetadatavalue.id;


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    extension text NOT NULL,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    project_id bigint NOT NULL,
    blob bytea NOT NULL,
    blobdigest character varying(255),
    source_id bigint
);


--
-- Name: file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_id_seq OWNED BY public.file.id;


--
-- Name: genericentity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentity (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    corporate_id text NOT NULL,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    file_id bigint,
    source_id bigint
);


--
-- Name: genericentity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentity_id_seq OWNED BY public.genericentity.id;


--
-- Name: genericentitylink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylink (
    id bigint NOT NULL,
    generic_entity_id bigint NOT NULL,
    linking_type text NOT NULL
);


--
-- Name: genericentitylink_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylink_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylink_id_seq OWNED BY public.genericentitylink.id;


--
-- Name: genericentitylot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylot (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    generic_entity_id bigint NOT NULL,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    lot_id_full text,
    source_id bigint
);


--
-- Name: genericentitylot_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylot_id_seq OWNED BY public.genericentitylot.id;


--
-- Name: genericentitylotobservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylotobservation (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    endpoint text NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    lot_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


--
-- Name: genericentitylotobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylotobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylotobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylotobservation_id_seq OWNED BY public.genericentitylotobservation.id;


--
-- Name: genericentitylotobservationproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylotobservationproject (
    id bigint NOT NULL,
    lot_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentitylotobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylotobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylotobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylotobservationproject_id_seq OWNED BY public.genericentitylotobservationproject.id;


--
-- Name: genericentitylotproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylotproject (
    id bigint NOT NULL,
    lot_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentitylotproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylotproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylotproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylotproject_id_seq OWNED BY public.genericentitylotproject.id;


--
-- Name: genericentitylotproperty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentitylotproperty (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    key text NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    lot_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentitylotproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentitylotproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentitylotproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentitylotproperty_id_seq OWNED BY public.genericentitylotproperty.id;


--
-- Name: genericentityobservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentityobservation (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    endpoint text NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    generic_entity_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


--
-- Name: genericentityobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentityobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentityobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentityobservation_id_seq OWNED BY public.genericentityobservation.id;


--
-- Name: genericentityobservationproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentityobservationproject (
    id bigint NOT NULL,
    generic_entity_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentityobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentityobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentityobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentityobservationproject_id_seq OWNED BY public.genericentityobservationproject.id;


--
-- Name: genericentityproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentityproject (
    id bigint NOT NULL,
    generic_entity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentityproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentityproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentityproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentityproject_id_seq OWNED BY public.genericentityproject.id;


--
-- Name: genericentityproperty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.genericentityproperty (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    key text NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    generic_entity_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: genericentityproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.genericentityproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: genericentityproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.genericentityproperty_id_seq OWNED BY public.genericentityproperty.id;


--
-- Name: lot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lot (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    compound_id bigint NOT NULL,
    salt text,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    page_id bigint,
    lot_id_full text,
    source_id bigint
);


--
-- Name: lot_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lot_id_seq OWNED BY public.lot.id;


--
-- Name: lotobservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lotobservation (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    endpoint text NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    lot_id bigint NOT NULL,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value) = 1))
);


--
-- Name: lotobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lotobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lotobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lotobservation_id_seq OWNED BY public.lotobservation.id;


--
-- Name: lotobservationproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lotobservationproject (
    id bigint NOT NULL,
    lot_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: lotobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lotobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lotobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lotobservationproject_id_seq OWNED BY public.lotobservationproject.id;


--
-- Name: lotproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lotproject (
    id bigint NOT NULL,
    lot_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: lotproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lotproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lotproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lotproject_id_seq OWNED BY public.lotproject.id;


--
-- Name: lotproperty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lotproperty (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    key text NOT NULL,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    lot_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: lotproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lotproperty_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lotproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lotproperty_id_seq OWNED BY public.lotproperty.id;


--
-- Name: metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metadata (
    id bigint NOT NULL,
    key text NOT NULL,
    assay_level boolean DEFAULT true NOT NULL
);


--
-- Name: metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.metadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.metadata_id_seq OWNED BY public.metadata.id;


--
-- Name: observationmetadatavalue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.observationmetadatavalue (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    num_value double precision,
    text_value text,
    date_value timestamp without time zone,
    key_id bigint NOT NULL,
    compoundobservation_id bigint,
    lotobservation_id bigint,
    genericentityobservation_id bigint,
    poseobservation_id bigint,
    show_time_component boolean DEFAULT false,
    CONSTRAINT metadata_has_only_one_relation CHECK ((num_nonnulls(compoundobservation_id, lotobservation_id, genericentityobservation_id, poseobservation_id) = 1))
);


--
-- Name: observationmetadatavalue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.observationmetadatavalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: observationmetadatavalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.observationmetadatavalue_id_seq OWNED BY public.observationmetadatavalue.id;


--
-- Name: page; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    document_id bigint,
    source_id bigint
);


--
-- Name: page_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.page_id_seq OWNED BY public.page.id;


--
-- Name: pose; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pose (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    generic_entity_id bigint,
    compound_id bigint,
    project_id bigint,
    person text DEFAULT 'LiveDesign'::text NOT NULL,
    key text NOT NULL,
    pose_id_full text NOT NULL,
    source_id bigint,
    CONSTRAINT only_one_parent_set CHECK ((num_nonnulls(generic_entity_id, compound_id) = 1))
);


--
-- Name: pose_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pose_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pose_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pose_id_seq OWNED BY public.pose.id;


--
-- Name: poseobservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poseobservation (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    endpoint text NOT NULL,
    unit character varying(255),
    text_value text,
    num_value double precision,
    date_value timestamp without time zone,
    std_dev double precision,
    value_operator character varying(255),
    conc double precision,
    conc_unit character varying(255),
    pose_id bigint NOT NULL,
    structure_id bigint,
    assay_id bigint NOT NULL,
    experiment_id bigint,
    document_id bigint,
    page_id bigint,
    source_id bigint,
    CONSTRAINT observation_allowed_operators CHECK (((value_operator)::text = ANY ((ARRAY['='::character varying, '<'::character varying, '>'::character varying, '>='::character varying, '<='::character varying, '+'::character varying, '++'::character varying])::text[]))),
    CONSTRAINT only_one_pose_observation_value CHECK ((num_nonnulls(num_value, text_value, date_value, structure_id) = 1))
);


--
-- Name: poseobservation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.poseobservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: poseobservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.poseobservation_id_seq OWNED BY public.poseobservation.id;


--
-- Name: poseobservationproject; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poseobservationproject (
    id bigint NOT NULL,
    pose_observation_id bigint NOT NULL,
    project_id bigint NOT NULL,
    source_id bigint
);


--
-- Name: poseobservationproject_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.poseobservationproject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: poseobservationproject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.poseobservationproject_id_seq OWNED BY public.poseobservationproject.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    key text NOT NULL,
    description text,
    is_restricted smallint DEFAULT 1 NOT NULL
);


--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source (
    id bigint NOT NULL,
    key text NOT NULL,
    config_id bigint,
    person text,
    uploaded timestamp without time zone,
    processed timestamp without time zone,
    purged timestamp without time zone,
    partial_purge smallint,
    project_id bigint
);


--
-- Name: source_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.source_id_seq OWNED BY public.source.id;


--
-- Name: structure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structure (
    id bigint NOT NULL,
    archived smallint DEFAULT 0 NOT NULL,
    customer_key text,
    rowhash character varying(255),
    created_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    modified_at timestamp without time zone DEFAULT (now() AT TIME ZONE 'utc'::text),
    key text NOT NULL,
    type text NOT NULL,
    format text NOT NULL,
    blob bytea NOT NULL,
    blobdigest character varying(255),
    source_id bigint,
    CONSTRAINT structure_allowed_format CHECK ((format = ANY (ARRAY['PSE'::text, 'MAE'::text, 'MAEGZ'::text, 'VIB'::text]))),
    CONSTRAINT structure_allowed_type CHECK ((type = ANY (ARRAY['LIGAND'::text, 'PROTEIN'::text, 'OTHER'::text, 'ANIMATION'::text])))
);


--
-- Name: structure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.structure_id_seq OWNED BY public.structure.id;


--
-- Name: assay id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assay ALTER COLUMN id SET DEFAULT nextval('public.assay_id_seq'::regclass);


--
-- Name: assaymetadatavalue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assaymetadatavalue ALTER COLUMN id SET DEFAULT nextval('public.assaymetadatavalue_id_seq'::regclass);


--
-- Name: compound id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound ALTER COLUMN id SET DEFAULT nextval('public.compound_id_seq'::regclass);


--
-- Name: compoundobservation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation ALTER COLUMN id SET DEFAULT nextval('public.compoundobservation_id_seq'::regclass);


--
-- Name: compoundobservationproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservationproject ALTER COLUMN id SET DEFAULT nextval('public.compoundobservationproject_id_seq'::regclass);


--
-- Name: compoundproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproject ALTER COLUMN id SET DEFAULT nextval('public.compoundproject_id_seq'::regclass);


--
-- Name: compoundproperty id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproperty ALTER COLUMN id SET DEFAULT nextval('public.compoundproperty_id_seq'::regclass);


--
-- Name: config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Name: document id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document ALTER COLUMN id SET DEFAULT nextval('public.document_id_seq'::regclass);


--
-- Name: entityalias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityalias ALTER COLUMN id SET DEFAULT nextval('public.entityalias_id_seq'::regclass);


--
-- Name: entitymetadata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadata ALTER COLUMN id SET DEFAULT nextval('public.entitymetadata_id_seq'::regclass);


--
-- Name: entitymetadatavalue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadatavalue ALTER COLUMN id SET DEFAULT nextval('public.entitymetadatavalue_id_seq'::regclass);


--
-- Name: entityrelationshipchild id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipchild ALTER COLUMN id SET DEFAULT nextval('public.entityrelationshipchild_id_seq'::regclass);


--
-- Name: entityrelationshipmetadata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipmetadata ALTER COLUMN id SET DEFAULT nextval('public.entityrelationshipmetadata_id_seq'::regclass);


--
-- Name: entityrelationshipparent id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipparent ALTER COLUMN id SET DEFAULT nextval('public.entityrelationshipparent_id_seq'::regclass);


--
-- Name: etlrun id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.etlrun ALTER COLUMN id SET DEFAULT nextval('public.etlrun_id_seq'::regclass);


--
-- Name: experiment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment ALTER COLUMN id SET DEFAULT nextval('public.experiment_id_seq'::regclass);


--
-- Name: experimentmetadatavalue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experimentmetadatavalue ALTER COLUMN id SET DEFAULT nextval('public.experimentmetadatavalue_id_seq'::regclass);


--
-- Name: file id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file ALTER COLUMN id SET DEFAULT nextval('public.file_id_seq'::regclass);


--
-- Name: genericentity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentity ALTER COLUMN id SET DEFAULT nextval('public.genericentity_id_seq'::regclass);


--
-- Name: genericentitylink id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylink ALTER COLUMN id SET DEFAULT nextval('public.genericentitylink_id_seq'::regclass);


--
-- Name: genericentitylot id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylot ALTER COLUMN id SET DEFAULT nextval('public.genericentitylot_id_seq'::regclass);


--
-- Name: genericentitylotobservation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation ALTER COLUMN id SET DEFAULT nextval('public.genericentitylotobservation_id_seq'::regclass);


--
-- Name: genericentitylotobservationproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservationproject ALTER COLUMN id SET DEFAULT nextval('public.genericentitylotobservationproject_id_seq'::regclass);


--
-- Name: genericentitylotproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproject ALTER COLUMN id SET DEFAULT nextval('public.genericentitylotproject_id_seq'::regclass);


--
-- Name: genericentitylotproperty id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproperty ALTER COLUMN id SET DEFAULT nextval('public.genericentitylotproperty_id_seq'::regclass);


--
-- Name: genericentityobservation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation ALTER COLUMN id SET DEFAULT nextval('public.genericentityobservation_id_seq'::regclass);


--
-- Name: genericentityobservationproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservationproject ALTER COLUMN id SET DEFAULT nextval('public.genericentityobservationproject_id_seq'::regclass);


--
-- Name: genericentityproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproject ALTER COLUMN id SET DEFAULT nextval('public.genericentityproject_id_seq'::regclass);


--
-- Name: genericentityproperty id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproperty ALTER COLUMN id SET DEFAULT nextval('public.genericentityproperty_id_seq'::regclass);


--
-- Name: lot id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot ALTER COLUMN id SET DEFAULT nextval('public.lot_id_seq'::regclass);


--
-- Name: lotobservation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation ALTER COLUMN id SET DEFAULT nextval('public.lotobservation_id_seq'::regclass);


--
-- Name: lotobservationproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservationproject ALTER COLUMN id SET DEFAULT nextval('public.lotobservationproject_id_seq'::regclass);


--
-- Name: lotproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproject ALTER COLUMN id SET DEFAULT nextval('public.lotproject_id_seq'::regclass);


--
-- Name: lotproperty id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproperty ALTER COLUMN id SET DEFAULT nextval('public.lotproperty_id_seq'::regclass);


--
-- Name: metadata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadata ALTER COLUMN id SET DEFAULT nextval('public.metadata_id_seq'::regclass);


--
-- Name: observationmetadatavalue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue ALTER COLUMN id SET DEFAULT nextval('public.observationmetadatavalue_id_seq'::regclass);


--
-- Name: page id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page ALTER COLUMN id SET DEFAULT nextval('public.page_id_seq'::regclass);


--
-- Name: pose id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose ALTER COLUMN id SET DEFAULT nextval('public.pose_id_seq'::regclass);


--
-- Name: poseobservation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation ALTER COLUMN id SET DEFAULT nextval('public.poseobservation_id_seq'::regclass);


--
-- Name: poseobservationproject id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservationproject ALTER COLUMN id SET DEFAULT nextval('public.poseobservationproject_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: source id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source ALTER COLUMN id SET DEFAULT nextval('public.source_id_seq'::regclass);


--
-- Name: structure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structure ALTER COLUMN id SET DEFAULT nextval('public.structure_id_seq'::regclass);


--
-- Name: assay assay_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assay
    ADD CONSTRAINT assay_pkey PRIMARY KEY (id);


--
-- Name: assaymetadatavalue assaymetadatavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assaymetadatavalue
    ADD CONSTRAINT assaymetadatavalue_pkey PRIMARY KEY (id);


--
-- Name: compound compound_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound
    ADD CONSTRAINT compound_pkey PRIMARY KEY (id);


--
-- Name: compoundobservation compoundobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_pkey PRIMARY KEY (id);


--
-- Name: compoundobservationproject compoundobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_pkey PRIMARY KEY (id);


--
-- Name: compoundproject compoundproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_pkey PRIMARY KEY (id);


--
-- Name: compoundproperty compoundproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (id);


--
-- Name: entityalias entityalias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_pkey PRIMARY KEY (id);


--
-- Name: entitymetadata entitymetadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadata
    ADD CONSTRAINT entitymetadata_pkey PRIMARY KEY (id);


--
-- Name: entitymetadatavalue entitymetadatavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadatavalue
    ADD CONSTRAINT entitymetadatavalue_pkey PRIMARY KEY (id);


--
-- Name: entityrelationshipchild entityrelationshipchild_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipchild
    ADD CONSTRAINT entityrelationshipchild_pkey PRIMARY KEY (id);


--
-- Name: entityrelationshipmetadata entityrelationshipmetadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipmetadata
    ADD CONSTRAINT entityrelationshipmetadata_pkey PRIMARY KEY (id);


--
-- Name: entityrelationshipparent entityrelationshipparent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipparent
    ADD CONSTRAINT entityrelationshipparent_pkey PRIMARY KEY (id);


--
-- Name: etlrun etlrun_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.etlrun
    ADD CONSTRAINT etlrun_pkey PRIMARY KEY (id);


--
-- Name: experiment experiment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_pkey PRIMARY KEY (id);


--
-- Name: experimentmetadatavalue experimentmetadatavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experimentmetadatavalue
    ADD CONSTRAINT experimentmetadatavalue_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: genericentity genericentity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_pkey PRIMARY KEY (id);


--
-- Name: genericentitylink genericentitylink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylink
    ADD CONSTRAINT genericentitylink_pkey PRIMARY KEY (id);


--
-- Name: genericentitylot genericentitylot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylot
    ADD CONSTRAINT genericentitylot_pkey PRIMARY KEY (id);


--
-- Name: genericentitylotobservation genericentitylotobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_pkey PRIMARY KEY (id);


--
-- Name: genericentitylotobservationproject genericentitylotobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservationproject
    ADD CONSTRAINT genericentitylotobservationproject_pkey PRIMARY KEY (id);


--
-- Name: genericentitylotproject genericentitylotproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproject
    ADD CONSTRAINT genericentitylotproject_pkey PRIMARY KEY (id);


--
-- Name: genericentitylotproperty genericentitylotproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproperty
    ADD CONSTRAINT genericentitylotproperty_pkey PRIMARY KEY (id);


--
-- Name: genericentityobservation genericentityobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_pkey PRIMARY KEY (id);


--
-- Name: genericentityobservationproject genericentityobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_pkey PRIMARY KEY (id);


--
-- Name: genericentityproject genericentityproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_pkey PRIMARY KEY (id);


--
-- Name: genericentityproperty genericentityproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_pkey PRIMARY KEY (id);


--
-- Name: lot lot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_pkey PRIMARY KEY (id);


--
-- Name: lotobservation lotobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_pkey PRIMARY KEY (id);


--
-- Name: lotobservationproject lotobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_pkey PRIMARY KEY (id);


--
-- Name: lotproject lotproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_pkey PRIMARY KEY (id);


--
-- Name: lotproperty lotproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_pkey PRIMARY KEY (id);


--
-- Name: metadata metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_pkey PRIMARY KEY (id);


--
-- Name: observationmetadatavalue observationmetadatavalue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_pkey PRIMARY KEY (id);


--
-- Name: page page_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_pkey PRIMARY KEY (id);


--
-- Name: pose pose_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_pkey PRIMARY KEY (id);


--
-- Name: poseobservation poseobservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_pkey PRIMARY KEY (id);


--
-- Name: poseobservationproject poseobservationproject_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: structure structure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT structure_pkey PRIMARY KEY (id);


--
-- Name: assay_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assay_customer_key ON public.assay USING btree (customer_key);


--
-- Name: assay_key_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assay_key_version ON public.assay USING btree (key, version) WHERE (archived = 0);


--
-- Name: assay_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assay_rowhash ON public.assay USING btree (rowhash);


--
-- Name: assay_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assay_source_id ON public.assay USING btree (source_id);


--
-- Name: assaymetadatavalue_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assaymetadatavalue_assay_id ON public.assaymetadatavalue USING btree (assay_id);


--
-- Name: assaymetadatavalue_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assaymetadatavalue_customer_key ON public.assaymetadatavalue USING btree (customer_key);


--
-- Name: assaymetadatavalue_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assaymetadatavalue_key_id ON public.assaymetadatavalue USING btree (key_id);


--
-- Name: assaymetadatavalue_key_id_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX assaymetadatavalue_key_id_assay_id ON public.assaymetadatavalue USING btree (key_id, assay_id);


--
-- Name: compound_corporate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compound_corporate_id ON public.compound USING btree (corporate_id) WHERE (archived = 0);


--
-- Name: compound_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compound_customer_key ON public.compound USING btree (customer_key);


--
-- Name: compound_molhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compound_molhash ON public.compound USING btree (molhash);


--
-- Name: compound_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compound_rowhash ON public.compound USING btree (rowhash);


--
-- Name: compound_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compound_source_id ON public.compound USING btree (source_id);


--
-- Name: compoundobservation_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_assay_id ON public.compoundobservation USING btree (assay_id);


--
-- Name: compoundobservation_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_compound_id ON public.compoundobservation USING btree (compound_id);


--
-- Name: compoundobservation_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compoundobservation_customer_key ON public.compoundobservation USING btree (customer_key);


--
-- Name: compoundobservation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_document_id ON public.compoundobservation USING btree (document_id);


--
-- Name: compoundobservation_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_experiment_id ON public.compoundobservation USING btree (experiment_id);


--
-- Name: compoundobservation_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_page_id ON public.compoundobservation USING btree (page_id);


--
-- Name: compoundobservation_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_rowhash ON public.compoundobservation USING btree (rowhash);


--
-- Name: compoundobservation_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservation_source_id ON public.compoundobservation USING btree (source_id);


--
-- Name: compoundobservationproject_compound_observation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservationproject_compound_observation_id ON public.compoundobservationproject USING btree (compound_observation_id);


--
-- Name: compoundobservationproject_compound_observation_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compoundobservationproject_compound_observation_id_project_id ON public.compoundobservationproject USING btree (compound_observation_id, project_id);


--
-- Name: compoundobservationproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservationproject_project_id ON public.compoundobservationproject USING btree (project_id);


--
-- Name: compoundobservationproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundobservationproject_source_id ON public.compoundobservationproject USING btree (source_id);


--
-- Name: compoundproject_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproject_compound_id ON public.compoundproject USING btree (compound_id);


--
-- Name: compoundproject_compound_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compoundproject_compound_id_project_id ON public.compoundproject USING btree (compound_id, project_id);


--
-- Name: compoundproject_primary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproject_primary ON public.compoundproject USING btree ("primary");


--
-- Name: compoundproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproject_project_id ON public.compoundproject USING btree (project_id);


--
-- Name: compoundproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproject_source_id ON public.compoundproject USING btree (source_id);


--
-- Name: compoundproperty_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproperty_compound_id ON public.compoundproperty USING btree (compound_id);


--
-- Name: compoundproperty_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX compoundproperty_customer_key ON public.compoundproperty USING btree (customer_key);


--
-- Name: compoundproperty_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX compoundproperty_source_id ON public.compoundproperty USING btree (source_id);


--
-- Name: config_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX config_customer_key ON public.config USING btree (customer_key);


--
-- Name: config_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX config_key ON public.config USING btree (key);


--
-- Name: config_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX config_project_id ON public.config USING btree (project_id);


--
-- Name: config_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX config_rowhash ON public.config USING btree (rowhash);


--
-- Name: document_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_customer_key ON public.document USING btree (customer_key);


--
-- Name: document_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_rowhash ON public.document USING btree (rowhash);


--
-- Name: document_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_source_id ON public.document USING btree (source_id);


--
-- Name: entityalias_alias; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entityalias_alias ON public.entityalias USING btree (alias);


--
-- Name: entityalias_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityalias_compound_id ON public.entityalias USING btree (compound_id);


--
-- Name: entityalias_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityalias_generic_entity_id ON public.entityalias USING btree (generic_entity_id);


--
-- Name: entityalias_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityalias_source_id ON public.entityalias USING btree (source_id);


--
-- Name: entitymetadata_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entitymetadata_key ON public.entitymetadata USING btree (key);


--
-- Name: entitymetadatavalue_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entitymetadatavalue_customer_key ON public.entitymetadatavalue USING btree (customer_key);


--
-- Name: entitymetadatavalue_genericentity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entitymetadatavalue_genericentity_id ON public.entitymetadatavalue USING btree (genericentity_id);


--
-- Name: entitymetadatavalue_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entitymetadatavalue_key_id ON public.entitymetadatavalue USING btree (key_id);


--
-- Name: entitymetadatavalue_key_id_genericentity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entitymetadatavalue_key_id_genericentity_id ON public.entitymetadatavalue USING btree (key_id, genericentity_id);


--
-- Name: entityrelationshipchild_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityrelationshipchild_entity_id ON public.entityrelationshipchild USING btree (entity_id);


--
-- Name: entityrelationshipchild_entity_id_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entityrelationshipchild_entity_id_parent_id ON public.entityrelationshipchild USING btree (entity_id, parent_id);


--
-- Name: entityrelationshipchild_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityrelationshipchild_parent_id ON public.entityrelationshipchild USING btree (parent_id);


--
-- Name: entityrelationshipchild_parent_id_child_order; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX entityrelationshipchild_parent_id_child_order ON public.entityrelationshipchild USING btree (parent_id, child_order);


--
-- Name: entityrelationshipmetadata_relationship_child_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityrelationshipmetadata_relationship_child_id ON public.entityrelationshipmetadata USING btree (relationship_child_id);


--
-- Name: entityrelationshipparent_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX entityrelationshipparent_entity_id ON public.entityrelationshipparent USING btree (entity_id);


--
-- Name: etlrun_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX etlrun_source_id ON public.etlrun USING btree (source_id);


--
-- Name: experiment_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX experiment_assay_id ON public.experiment USING btree (assay_id);


--
-- Name: experiment_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX experiment_customer_key ON public.experiment USING btree (customer_key);


--
-- Name: experiment_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX experiment_rowhash ON public.experiment USING btree (rowhash);


--
-- Name: experiment_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX experiment_source_id ON public.experiment USING btree (source_id);


--
-- Name: experimentmetadatavalue_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX experimentmetadatavalue_customer_key ON public.experimentmetadatavalue USING btree (customer_key);


--
-- Name: experimentmetadatavalue_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX experimentmetadatavalue_experiment_id ON public.experimentmetadatavalue USING btree (experiment_id);


--
-- Name: experimentmetadatavalue_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX experimentmetadatavalue_key_id ON public.experimentmetadatavalue USING btree (key_id);


--
-- Name: experimentmetadatavalue_key_id_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX experimentmetadatavalue_key_id_experiment_id ON public.experimentmetadatavalue USING btree (key_id, experiment_id);


--
-- Name: file_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX file_customer_key ON public.file USING btree (customer_key);


--
-- Name: file_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_project_id ON public.file USING btree (project_id);


--
-- Name: file_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_rowhash ON public.file USING btree (rowhash);


--
-- Name: file_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_source_id ON public.file USING btree (source_id);


--
-- Name: genericentity_corporate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentity_corporate_id ON public.genericentity USING btree (corporate_id) WHERE (archived = 0);


--
-- Name: genericentity_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentity_customer_key ON public.genericentity USING btree (customer_key);


--
-- Name: genericentity_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentity_file_id ON public.genericentity USING btree (file_id);


--
-- Name: genericentity_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentity_rowhash ON public.genericentity USING btree (rowhash);


--
-- Name: genericentity_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentity_source_id ON public.genericentity USING btree (source_id);


--
-- Name: genericentitylink_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylink_generic_entity_id ON public.genericentitylink USING btree (generic_entity_id);


--
-- Name: genericentitylot_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylot_customer_key ON public.genericentitylot USING btree (customer_key);


--
-- Name: genericentitylot_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylot_generic_entity_id ON public.genericentitylot USING btree (generic_entity_id);


--
-- Name: genericentitylot_generic_entity_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylot_generic_entity_id_key ON public.genericentitylot USING btree (generic_entity_id, key) WHERE (archived = 0);


--
-- Name: genericentitylot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylot_key ON public.genericentitylot USING btree (key);


--
-- Name: genericentitylot_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylot_rowhash ON public.genericentitylot USING btree (rowhash);


--
-- Name: genericentitylot_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylot_source_id ON public.genericentitylot USING btree (source_id);


--
-- Name: genericentitylotobservation_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_assay_id ON public.genericentitylotobservation USING btree (assay_id);


--
-- Name: genericentitylotobservation_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylotobservation_customer_key ON public.genericentitylotobservation USING btree (customer_key);


--
-- Name: genericentitylotobservation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_document_id ON public.genericentitylotobservation USING btree (document_id);


--
-- Name: genericentitylotobservation_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_experiment_id ON public.genericentitylotobservation USING btree (experiment_id);


--
-- Name: genericentitylotobservation_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_lot_id ON public.genericentitylotobservation USING btree (lot_id);


--
-- Name: genericentitylotobservation_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_rowhash ON public.genericentitylotobservation USING btree (rowhash);


--
-- Name: genericentitylotobservation_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservation_source_id ON public.genericentitylotobservation USING btree (source_id);


--
-- Name: genericentitylotobservationproject_lot_observation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservationproject_lot_observation_id ON public.genericentitylotobservationproject USING btree (lot_observation_id);


--
-- Name: genericentitylotobservationproject_lot_observation_id_project_i; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylotobservationproject_lot_observation_id_project_i ON public.genericentitylotobservationproject USING btree (lot_observation_id, project_id);


--
-- Name: genericentitylotobservationproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservationproject_project_id ON public.genericentitylotobservationproject USING btree (project_id);


--
-- Name: genericentitylotobservationproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotobservationproject_source_id ON public.genericentitylotobservationproject USING btree (source_id);


--
-- Name: genericentitylotproject_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotproject_lot_id ON public.genericentitylotproject USING btree (lot_id);


--
-- Name: genericentitylotproject_lot_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylotproject_lot_id_project_id ON public.genericentitylotproject USING btree (lot_id, project_id);


--
-- Name: genericentitylotproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotproject_project_id ON public.genericentitylotproject USING btree (project_id);


--
-- Name: genericentitylotproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotproject_source_id ON public.genericentitylotproject USING btree (source_id);


--
-- Name: genericentitylotproperty_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentitylotproperty_customer_key ON public.genericentitylotproperty USING btree (customer_key);


--
-- Name: genericentitylotproperty_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotproperty_lot_id ON public.genericentitylotproperty USING btree (lot_id);


--
-- Name: genericentitylotproperty_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentitylotproperty_source_id ON public.genericentitylotproperty USING btree (source_id);


--
-- Name: genericentityobservation_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_assay_id ON public.genericentityobservation USING btree (assay_id);


--
-- Name: genericentityobservation_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentityobservation_customer_key ON public.genericentityobservation USING btree (customer_key);


--
-- Name: genericentityobservation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_document_id ON public.genericentityobservation USING btree (document_id);


--
-- Name: genericentityobservation_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_experiment_id ON public.genericentityobservation USING btree (experiment_id);


--
-- Name: genericentityobservation_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_generic_entity_id ON public.genericentityobservation USING btree (generic_entity_id);


--
-- Name: genericentityobservation_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_page_id ON public.genericentityobservation USING btree (page_id);


--
-- Name: genericentityobservation_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_rowhash ON public.genericentityobservation USING btree (rowhash);


--
-- Name: genericentityobservation_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservation_source_id ON public.genericentityobservation USING btree (source_id);


--
-- Name: genericentityobservationproject_generic_entity_observati_734c8f; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentityobservationproject_generic_entity_observati_734c8f ON public.genericentityobservationproject USING btree (generic_entity_observation_id, project_id);


--
-- Name: genericentityobservationproject_generic_entity_observation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservationproject_generic_entity_observation_id ON public.genericentityobservationproject USING btree (generic_entity_observation_id);


--
-- Name: genericentityobservationproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservationproject_project_id ON public.genericentityobservationproject USING btree (project_id);


--
-- Name: genericentityobservationproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityobservationproject_source_id ON public.genericentityobservationproject USING btree (source_id);


--
-- Name: genericentityproject_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityproject_generic_entity_id ON public.genericentityproject USING btree (generic_entity_id);


--
-- Name: genericentityproject_generic_entity_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentityproject_generic_entity_id_project_id ON public.genericentityproject USING btree (generic_entity_id, project_id);


--
-- Name: genericentityproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityproject_project_id ON public.genericentityproject USING btree (project_id);


--
-- Name: genericentityproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityproject_source_id ON public.genericentityproject USING btree (source_id);


--
-- Name: genericentityproperty_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX genericentityproperty_customer_key ON public.genericentityproperty USING btree (customer_key);


--
-- Name: genericentityproperty_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityproperty_generic_entity_id ON public.genericentityproperty USING btree (generic_entity_id);


--
-- Name: genericentityproperty_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX genericentityproperty_source_id ON public.genericentityproperty USING btree (source_id);


--
-- Name: lot_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lot_compound_id ON public.lot USING btree (compound_id);


--
-- Name: lot_compound_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lot_compound_id_key ON public.lot USING btree (compound_id, key) WHERE (archived = 0);


--
-- Name: lot_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lot_customer_key ON public.lot USING btree (customer_key);


--
-- Name: lot_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lot_key ON public.lot USING btree (key);


--
-- Name: lot_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lot_page_id ON public.lot USING btree (page_id);


--
-- Name: lot_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lot_rowhash ON public.lot USING btree (rowhash);


--
-- Name: lot_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lot_source_id ON public.lot USING btree (source_id);


--
-- Name: lotobservation_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_assay_id ON public.lotobservation USING btree (assay_id);


--
-- Name: lotobservation_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lotobservation_customer_key ON public.lotobservation USING btree (customer_key);


--
-- Name: lotobservation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_document_id ON public.lotobservation USING btree (document_id);


--
-- Name: lotobservation_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_experiment_id ON public.lotobservation USING btree (experiment_id);


--
-- Name: lotobservation_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_lot_id ON public.lotobservation USING btree (lot_id);


--
-- Name: lotobservation_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_page_id ON public.lotobservation USING btree (page_id);


--
-- Name: lotobservation_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_rowhash ON public.lotobservation USING btree (rowhash);


--
-- Name: lotobservation_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservation_source_id ON public.lotobservation USING btree (source_id);


--
-- Name: lotobservationproject_lot_observation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservationproject_lot_observation_id ON public.lotobservationproject USING btree (lot_observation_id);


--
-- Name: lotobservationproject_lot_observation_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lotobservationproject_lot_observation_id_project_id ON public.lotobservationproject USING btree (lot_observation_id, project_id);


--
-- Name: lotobservationproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservationproject_project_id ON public.lotobservationproject USING btree (project_id);


--
-- Name: lotobservationproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotobservationproject_source_id ON public.lotobservationproject USING btree (source_id);


--
-- Name: lotproject_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotproject_lot_id ON public.lotproject USING btree (lot_id);


--
-- Name: lotproject_lot_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lotproject_lot_id_project_id ON public.lotproject USING btree (lot_id, project_id);


--
-- Name: lotproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotproject_project_id ON public.lotproject USING btree (project_id);


--
-- Name: lotproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotproject_source_id ON public.lotproject USING btree (source_id);


--
-- Name: lotproperty_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lotproperty_customer_key ON public.lotproperty USING btree (customer_key);


--
-- Name: lotproperty_lot_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotproperty_lot_id ON public.lotproperty USING btree (lot_id);


--
-- Name: lotproperty_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lotproperty_source_id ON public.lotproperty USING btree (source_id);


--
-- Name: metadata_key_assay_level; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX metadata_key_assay_level ON public.metadata USING btree (key, assay_level);


--
-- Name: observationmetadatavalue_compoundobservation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX observationmetadatavalue_compoundobservation_id ON public.observationmetadatavalue USING btree (compoundobservation_id);


--
-- Name: observationmetadatavalue_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX observationmetadatavalue_customer_key ON public.observationmetadatavalue USING btree (customer_key);


--
-- Name: observationmetadatavalue_genericentityobservation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX observationmetadatavalue_genericentityobservation_id ON public.observationmetadatavalue USING btree (genericentityobservation_id);


--
-- Name: observationmetadatavalue_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX observationmetadatavalue_key_id ON public.observationmetadatavalue USING btree (key_id);


--
-- Name: observationmetadatavalue_key_id_compoundobservation_id_l_e8c0ff; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX observationmetadatavalue_key_id_compoundobservation_id_l_e8c0ff ON public.observationmetadatavalue USING btree (key_id, compoundobservation_id, lotobservation_id, genericentityobservation_id, poseobservation_id);


--
-- Name: observationmetadatavalue_lotobservation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX observationmetadatavalue_lotobservation_id ON public.observationmetadatavalue USING btree (lotobservation_id);


--
-- Name: observationmetadatavalue_poseobservation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX observationmetadatavalue_poseobservation_id ON public.observationmetadatavalue USING btree (poseobservation_id);


--
-- Name: page_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX page_customer_key ON public.page USING btree (customer_key);


--
-- Name: page_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX page_document_id ON public.page USING btree (document_id);


--
-- Name: page_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX page_rowhash ON public.page USING btree (rowhash);


--
-- Name: page_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX page_source_id ON public.page USING btree (source_id);


--
-- Name: pose_compound_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_compound_id ON public.pose USING btree (compound_id);


--
-- Name: pose_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pose_customer_key ON public.pose USING btree (customer_key);


--
-- Name: pose_generic_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_generic_entity_id ON public.pose USING btree (generic_entity_id);


--
-- Name: pose_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_key ON public.pose USING btree (key);


--
-- Name: pose_pose_id_full; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pose_pose_id_full ON public.pose USING btree (pose_id_full);


--
-- Name: pose_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_project_id ON public.pose USING btree (project_id);


--
-- Name: pose_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_rowhash ON public.pose USING btree (rowhash);


--
-- Name: pose_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pose_source_id ON public.pose USING btree (source_id);


--
-- Name: poseobservation_assay_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_assay_id ON public.poseobservation USING btree (assay_id);


--
-- Name: poseobservation_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poseobservation_customer_key ON public.poseobservation USING btree (customer_key);


--
-- Name: poseobservation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_document_id ON public.poseobservation USING btree (document_id);


--
-- Name: poseobservation_experiment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_experiment_id ON public.poseobservation USING btree (experiment_id);


--
-- Name: poseobservation_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_page_id ON public.poseobservation USING btree (page_id);


--
-- Name: poseobservation_pose_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_pose_id ON public.poseobservation USING btree (pose_id);


--
-- Name: poseobservation_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_rowhash ON public.poseobservation USING btree (rowhash);


--
-- Name: poseobservation_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservation_source_id ON public.poseobservation USING btree (source_id);


--
-- Name: poseobservation_structure_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poseobservation_structure_id ON public.poseobservation USING btree (structure_id);


--
-- Name: poseobservationproject_pose_observation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservationproject_pose_observation_id ON public.poseobservationproject USING btree (pose_observation_id);


--
-- Name: poseobservationproject_pose_observation_id_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poseobservationproject_pose_observation_id_project_id ON public.poseobservationproject USING btree (pose_observation_id, project_id);


--
-- Name: poseobservationproject_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservationproject_project_id ON public.poseobservationproject USING btree (project_id);


--
-- Name: poseobservationproject_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poseobservationproject_source_id ON public.poseobservationproject USING btree (source_id);


--
-- Name: project_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_customer_key ON public.project USING btree (customer_key);


--
-- Name: project_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_key ON public.project USING btree (key) WHERE (archived = 0);


--
-- Name: source_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_config_id ON public.source USING btree (config_id);


--
-- Name: source_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX source_key ON public.source USING btree (key);


--
-- Name: source_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX source_project_id ON public.source USING btree (project_id);


--
-- Name: structure_customer_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX structure_customer_key ON public.structure USING btree (customer_key);


--
-- Name: structure_rowhash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX structure_rowhash ON public.structure USING btree (rowhash);


--
-- Name: structure_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX structure_source_id ON public.structure USING btree (source_id);


--
-- Name: assay assay_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assay
    ADD CONSTRAINT assay_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: assaymetadatavalue assaymetadatavalue_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assaymetadatavalue
    ADD CONSTRAINT assaymetadatavalue_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id);


--
-- Name: assaymetadatavalue assaymetadatavalue_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assaymetadatavalue
    ADD CONSTRAINT assaymetadatavalue_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.metadata(id);


--
-- Name: compound compound_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound
    ADD CONSTRAINT compound_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundobservation compoundobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: compoundobservation compoundobservation_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundobservation compoundobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: compoundobservation compoundobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: compoundobservation compoundobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: compoundobservation compoundobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservation
    ADD CONSTRAINT compoundobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundobservationproject compoundobservationproject_compound_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_compound_observation_id_fkey FOREIGN KEY (compound_observation_id) REFERENCES public.compoundobservation(id) ON DELETE CASCADE;


--
-- Name: compoundobservationproject compoundobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: compoundobservationproject compoundobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundobservationproject
    ADD CONSTRAINT compoundobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundproject compoundproject_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundproject compoundproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: compoundproject compoundproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproject
    ADD CONSTRAINT compoundproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: compoundproperty compoundproperty_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: compoundproperty compoundproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compoundproperty
    ADD CONSTRAINT compoundproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: document document_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: entityalias entityalias_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: entityalias entityalias_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: entityalias entityalias_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityalias
    ADD CONSTRAINT entityalias_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: entitymetadatavalue entitymetadatavalue_genericentity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadatavalue
    ADD CONSTRAINT entitymetadatavalue_genericentity_id_fkey FOREIGN KEY (genericentity_id) REFERENCES public.genericentity(id);


--
-- Name: entitymetadatavalue entitymetadatavalue_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entitymetadatavalue
    ADD CONSTRAINT entitymetadatavalue_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.entitymetadata(id);


--
-- Name: entityrelationshipchild entityrelationshipchild_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipchild
    ADD CONSTRAINT entityrelationshipchild_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: entityrelationshipchild entityrelationshipchild_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipchild
    ADD CONSTRAINT entityrelationshipchild_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.entityrelationshipparent(id) ON DELETE CASCADE;


--
-- Name: entityrelationshipmetadata entityrelationshipmetadata_relationship_child_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipmetadata
    ADD CONSTRAINT entityrelationshipmetadata_relationship_child_id_fkey FOREIGN KEY (relationship_child_id) REFERENCES public.entityrelationshipchild(id) ON DELETE CASCADE;


--
-- Name: entityrelationshipparent entityrelationshipparent_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entityrelationshipparent
    ADD CONSTRAINT entityrelationshipparent_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: etlrun etlrun_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.etlrun
    ADD CONSTRAINT etlrun_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: experiment experiment_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: experiment experiment_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experiment
    ADD CONSTRAINT experiment_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: experimentmetadatavalue experimentmetadatavalue_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experimentmetadatavalue
    ADD CONSTRAINT experimentmetadatavalue_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: experimentmetadatavalue experimentmetadatavalue_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.experimentmetadatavalue
    ADD CONSTRAINT experimentmetadatavalue_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.metadata(id);


--
-- Name: file file_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: file file_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentity genericentity_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: genericentity genericentity_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentity
    ADD CONSTRAINT genericentity_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentitylink genericentitylink_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylink
    ADD CONSTRAINT genericentitylink_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentitylot genericentitylot_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylot
    ADD CONSTRAINT genericentitylot_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentitylot genericentitylot_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylot
    ADD CONSTRAINT genericentitylot_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentitylotobservation genericentitylotobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: genericentitylotobservation genericentitylotobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: genericentitylotobservation genericentitylotobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: genericentitylotobservation genericentitylotobservation_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.genericentitylot(id) ON DELETE CASCADE;


--
-- Name: genericentitylotobservation genericentitylotobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservation
    ADD CONSTRAINT genericentitylotobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentitylotobservationproject genericentitylotobservationproject_lot_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservationproject
    ADD CONSTRAINT genericentitylotobservationproject_lot_observation_id_fkey FOREIGN KEY (lot_observation_id) REFERENCES public.genericentitylotobservation(id) ON DELETE CASCADE;


--
-- Name: genericentitylotobservationproject genericentitylotobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservationproject
    ADD CONSTRAINT genericentitylotobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentitylotobservationproject genericentitylotobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotobservationproject
    ADD CONSTRAINT genericentitylotobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentitylotproject genericentitylotproject_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproject
    ADD CONSTRAINT genericentitylotproject_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.genericentitylot(id) ON DELETE CASCADE;


--
-- Name: genericentitylotproject genericentitylotproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproject
    ADD CONSTRAINT genericentitylotproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentitylotproject genericentitylotproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproject
    ADD CONSTRAINT genericentitylotproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentitylotproperty genericentitylotproperty_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproperty
    ADD CONSTRAINT genericentitylotproperty_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.genericentitylot(id) ON DELETE CASCADE;


--
-- Name: genericentitylotproperty genericentitylotproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentitylotproperty
    ADD CONSTRAINT genericentitylotproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityobservation genericentityobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: genericentityobservation genericentityobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: genericentityobservation genericentityobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: genericentityobservation genericentityobservation_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityobservation genericentityobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: genericentityobservation genericentityobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservation
    ADD CONSTRAINT genericentityobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityobservationproject genericentityobservationproje_generic_entity_observation_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproje_generic_entity_observation_i_fkey FOREIGN KEY (generic_entity_observation_id) REFERENCES public.genericentityobservation(id) ON DELETE CASCADE;


--
-- Name: genericentityobservationproject genericentityobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentityobservationproject genericentityobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityobservationproject
    ADD CONSTRAINT genericentityobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityproject genericentityproject_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityproject genericentityproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: genericentityproject genericentityproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproject
    ADD CONSTRAINT genericentityproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: genericentityproperty genericentityproperty_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id) ON DELETE CASCADE;


--
-- Name: genericentityproperty genericentityproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.genericentityproperty
    ADD CONSTRAINT genericentityproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lot lot_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id) ON DELETE CASCADE;


--
-- Name: lot lot_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: lot lot_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotobservation lotobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: lotobservation lotobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: lotobservation lotobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: lotobservation lotobservation_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotobservation lotobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: lotobservation lotobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservation
    ADD CONSTRAINT lotobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotobservationproject lotobservationproject_lot_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_lot_observation_id_fkey FOREIGN KEY (lot_observation_id) REFERENCES public.lotobservation(id) ON DELETE CASCADE;


--
-- Name: lotobservationproject lotobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: lotobservationproject lotobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotobservationproject
    ADD CONSTRAINT lotobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotproject lotproject_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotproject lotproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: lotproject lotproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproject
    ADD CONSTRAINT lotproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: lotproperty lotproperty_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id) ON DELETE CASCADE;


--
-- Name: lotproperty lotproperty_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lotproperty
    ADD CONSTRAINT lotproperty_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: observationmetadatavalue observationmetadatavalue_compoundobservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_compoundobservation_id_fkey FOREIGN KEY (compoundobservation_id) REFERENCES public.compoundobservation(id);


--
-- Name: observationmetadatavalue observationmetadatavalue_genericentityobservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_genericentityobservation_id_fkey FOREIGN KEY (genericentityobservation_id) REFERENCES public.genericentityobservation(id);


--
-- Name: observationmetadatavalue observationmetadatavalue_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_key_id_fkey FOREIGN KEY (key_id) REFERENCES public.metadata(id);


--
-- Name: observationmetadatavalue observationmetadatavalue_lotobservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_lotobservation_id_fkey FOREIGN KEY (lotobservation_id) REFERENCES public.lotobservation(id);


--
-- Name: observationmetadatavalue observationmetadatavalue_poseobservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.observationmetadatavalue
    ADD CONSTRAINT observationmetadatavalue_poseobservation_id_fkey FOREIGN KEY (poseobservation_id) REFERENCES public.poseobservation(id);


--
-- Name: page page_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: page page_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page
    ADD CONSTRAINT page_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: pose pose_compound_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_compound_id_fkey FOREIGN KEY (compound_id) REFERENCES public.compound(id);


--
-- Name: pose pose_generic_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_generic_entity_id_fkey FOREIGN KEY (generic_entity_id) REFERENCES public.genericentity(id);


--
-- Name: pose pose_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: pose pose_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pose
    ADD CONSTRAINT pose_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: poseobservation poseobservation_assay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_assay_id_fkey FOREIGN KEY (assay_id) REFERENCES public.assay(id) ON DELETE CASCADE;


--
-- Name: poseobservation poseobservation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(id);


--
-- Name: poseobservation poseobservation_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES public.experiment(id);


--
-- Name: poseobservation poseobservation_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.page(id);


--
-- Name: poseobservation poseobservation_pose_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_pose_id_fkey FOREIGN KEY (pose_id) REFERENCES public.pose(id) ON DELETE CASCADE;


--
-- Name: poseobservation poseobservation_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: poseobservation poseobservation_structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservation
    ADD CONSTRAINT poseobservation_structure_id_fkey FOREIGN KEY (structure_id) REFERENCES public.structure(id);


--
-- Name: poseobservationproject poseobservationproject_pose_observation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_pose_observation_id_fkey FOREIGN KEY (pose_observation_id) REFERENCES public.poseobservation(id) ON DELETE CASCADE;


--
-- Name: poseobservationproject poseobservationproject_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: poseobservationproject poseobservationproject_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poseobservationproject
    ADD CONSTRAINT poseobservationproject_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- Name: source source_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source
    ADD CONSTRAINT source_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.config(id);


--
-- Name: structure structure_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structure
    ADD CONSTRAINT structure_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.source(id);


--
-- PostgreSQL database dump complete
--

