# simpleschema Database Example Files and ERDs

## SimpleSchema Database with Example A2A Data

`simpleschema_with_data.sql` has a SimpleSchema database with A2A and COX example data.
`simpleschema_with_data_and_replicates.sql` has a SimpleSchema database with A2A and COX example data and "pseudo 
replicates" with the same mean as the non-replicates file. These files were created without create statements and 
ownership or other ACLs/permissions. 
.

To load these files, first be sure the user and database exist and the user owns the database. For example, as a DBA 
user:

```bash
psql -h localhost -p 3247 -U postgres -c "CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_pass'"
psql -h localhost -p 3247 -U postgres -c "CREATE DATABASE example_db WITH OWNER 'simpleschema_owner'"
```

Then load the SQL dump file using the simpleschema owner into the database you created. Example:

```bash
# empty schema only
PGPASSWORD="example_pass" psql -h localhost -p 3247 -U simpleschema_owner -d example_db -f simpleschema.sql
# schema with data
PGPASSWORD="example_pass" psql -h localhost -p 3247 -U simpleschema_owner -d example_db -f simpleschema_with_data.sql
# schema with data and pseudoreplicates
PGPASSWORD="example_pass" psql -h localhost -p 3247 -U simpleschema_owner -d example_db -f simpleschema_with_data_and_replicates.sql
```

The `with_data` files were originally created using the (deprecated) SDFUploader for SimpleSchema. These files should be
updated with all the appropriate migration scripts and then re-exported again. An example of how to do this with a 
Posgtgresql 14 Docker container: 

```bash
PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema_owner -e POSTGRES_PASSWORD=simpleschema postgres:14)
sleep 2
# load old SQL file
PGPASSWORD=simpleschema psql -h localhost -p 3248 -U simpleschema_owner -c "CREATE DATABASE example_db"
PGPASSWORD=simpleschema psql -h localhost -p 3248 -U simpleschema_owner -d example_db -f simpleschema_with_data.sql
# activate simpleschema venv and run migrations
source venv/bin/activate
# run migration #04
python3 migrations/04-migrate_most_char_fields_to_text.py --port 3248 --user simpleschema_owner --password simpleschema example_db
# whether or not a migration is needed, run create_tables to make sure any missing tables have been added
create_tables example_db --port 3248
# then export the db
PGPASSWORD=simpleschema pg_dump --no-owner --no-acl --format=plain --blobs -h localhost -p 3248 -U simpleschema_owner -f simpleschema_with_data.sql -d example_db
```

## Empty SimpleSchema Database and ERD

`simpleschema.sql` is the database only (no data); created using `create_simpleschema_db_dump.py`. Note that using this 
script with the `--with-docker` argument requires executing user access to Docker engine; using it without `--with-docker` 
requires providing connection details for the database server (see script help text). 

To manually start a Postgresql 14 Docker container, create the database, create the tables, and do the dump (change user
and database names as needed):
```bash
# This must be run in a virtualenv with the simpleschema package installed and by a user who has docker privs
PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema_owner -e POSTGRES_PASSWORD=simpleschema postgres:14)
sleep 2
docker exec $PGCONTAINER psql -U simpleschema_owner -c "CREATE DATABASE example_db"
create_tables example_db --port 3248
PGPASSWORD=simpleschema pg_dump -s --no-owner --no-acl --format=plain -h localhost -p 3248 -U simpleschema_owner -f simpleschema.sql -d example_db
```

When you are done with the docker container you can stop/remove it with:
```bash
docker rm -f $PGCONTAINER
```

ERD SVG and/or PNG files can be created:
* using SQL Developer: File->Data Modeler->Import->Data Dictionary to create the ERD; generate images via File->Data 
Modeler->Print Diagram
* using DBeaver: in the lower left project browser right click on Diagrams and select "Create new ER diagram", give it 
a name, and select only the tables you want as initial objects (e.g. everything except Config, ETLRun, and Source); 
save the ERD and/or image files via File->Save As

Arrange the objects as best as possible to fit in the space and save the ERD and/or images.