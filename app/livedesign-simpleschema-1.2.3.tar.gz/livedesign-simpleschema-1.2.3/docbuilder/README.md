# SimpleSchema document builder

To (re)build docs for SimpleSchema, first ensure you have `sphinx` and `autodoc` installed in your python (virtual) 
environment then run `make clean; make html`