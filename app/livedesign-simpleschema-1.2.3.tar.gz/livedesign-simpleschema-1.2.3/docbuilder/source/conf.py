# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'SimpleSchema'
copyright = '2023, Mike Braden and Ziyana Samanani'
author = 'Mike Braden and Ziyana Samanani'
release = '1.2.x'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

import os
import sys

sys.path.insert(0, os.path.abspath('..'))
sys.path.append(os.path.abspath(os.path.join('..', '..', 'simpleschema')))

extensions = ['sphinx.ext.autodoc', 'sphinx.ext.autodoc.typehints', 'sphinx.ext.coverage', 'sphinx.ext.napoleon']

autodoc_typehints = 'description'

autodoc_skip_members = ['__init__']

autodoc_short_name = True

autodoc_source_suffix = [".rst", ".md", ".py"]

pdf_documents = [('index', 'simpleschema_documentation.pdf', 'SimpleSchema Documentation V1.2.x')]

entry_points = {'sphinx.builders': ['pdf = sphinx.builders.pdfbuilder']}

templates_path = ['_templates']
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'classic'

exclude_patterns = ['_static/chembl_migration.py']

html_theme_options = {
    "body_max_width": "1000px"
}

html_sidebars = {
    '**': [
        'globaltoc.html',
        'searchbox.html'
    ]
}

html_static_path = ['_static']
html_css_files = ["custom.css"]