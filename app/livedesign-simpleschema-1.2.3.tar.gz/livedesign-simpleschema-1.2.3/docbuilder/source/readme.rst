README
========

This page gives an overview of a simple "blessed" Postgres database schema for use as a source database for DI. This schema can be used as the endpoint for an ETL (HVR, cron'd python script, etc.),
an SDF upload script, or other compound and/or assay data uploader.

A simplified PSQL database schema with known DI configuration. Can be written directly using SQL. Alternatively,
includes a python interface that can be used to populate LiveDesign with real compounds and assay data. The Python API
uses the PeeWee ORM, which represents database records as regular python objects. Whether using direct SQL or the Python
API, when the save method(s) are called, DI automatically handles synchronization with LD.

Note that the `aiosimpleschema` package has been moved to a submodule of the simpleschema package. See below for
updated installation instructions. Any references to the `aiosimpleschema` package should be updated to use
`simpleschema.aio`.

Quick Start
------------

Installation
############

Download the `latest SimpleSchema release tarball <https://github.com/schrodinger/livedesign-simpleschema/releases>`_.

Choose ONE of the following to install/set up the SimpleSchema database:

**Use the SQL dumps of example schemas to create the database**

1. Create a database user for the SimpleSchema database (`CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_pass'`)
2. Create a database for SimpleSchema with the user in step 1 as the database owner (`CREATE DATABASE example_db WITH OWNER 'simpleschema_owner'`)
3. Extract the SimpleSchema release tarball; browse to `livedesign-simpleschema/example_schema/` directory
4. Choose the SQL file you want to use (empty simpleschema, simpleschema with data, or simpleschema with data and replicates)
5. Restore the dump file using the database user you created (step 1) into the database you created (step 2)

**Use the SimpleSchema python API**

1. Create a database user for the SimpleSchema database (`CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_pass'`)
2. Create a database for SimpleSchema with the user in step 1 as the database owner (`CREATE DATABASE example_db WITH OWNER 'simpleschema_owner'`)
3. Create a python ≥ 3.8 virtual environment
4. Activate the virtual environment and `pip install` the SimpleSchema release tarball
5. Run `create_tables` with appropriate arguments (user, pass, port, database name, etc.)

Upgrades
#########

Upgrading from previous versions of SimpleSchema (≥1.0.0 to latest) can be done by:

1. Stop any running DI services
2. Download the `latest SimpleSchema release tarball <https://github.com/schrodinger/livedesign-simpleschema/releases>`_.
3. Activate your simpleschema python virtual environment
4. Run `pip uninstall simpleschema`
5. `pip install` the SimpleSchema release tarball
6. Untar the SimpleSchema release tarball and run any/all migration scripts in `livedesign-simpleschema/migrations`
7. Run `create_tables` with appropriate arguments (user, pass, port, database name, etc.) to make sure any new tables are created
8. See the `livedesign-simpleschema/migrations/README.md` file for more details

Architecture Details
---------------------

ERD for Example SimpleSchema 1.2.x
###################################

Note that this ERD does not include all currently supported tables such as generic entity lot (and all associated
tables), entity and experimental metadata, and entity relationships.

.. image:: /_static/simpleschema_ERD.png
    :alt: ERD for SimpleSchema

Table Models
#############

Each of these classes represent actual tables in the database. Class properties represent columns, and will have the
same name. Foreign keys are represented with an implicit "_id" column. All date fields are `timestamp without time zone`
data type. It is strongly recommended that any timestamps with a time component, particularly auditing fields
(e.g. `created_at`, `modified_at`, `etlrun.started_at`, etc.) use UTC time. Most but not all of these fields have
default values of `datetime.utcnow()`. Note that any constraints and defaults are applied at both the SQL and Python API
levels.

The syntax for the following tables' fields is:

* `fieldname`: CONSTRAINT (datatype: `default`) - description

`Project <simpleschema.html#models.Project>`_
***********************************************

This table contains project details and is mapped to syn_project.

* `id`: PK/AUTO (bigserial)
* `key`: REQUIRED/UNIQUE (text) - any project name here will be added/created in LD
* `description`: OPTIONAL (text) - project description
* `is_restricted`: REQUIRED (int2: `1`) - if set to 1, project/data is restricted to users with explicit access to this project; if set to 0, project/data is unrestricted and any user can access
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted

`Compound <simpleschema.html#models.Compound>`_
***********************************************

This table contains compound/structure information and is mapped to syn_compound. Note that `mol_file` must be in MOL or single SDF format and `corporate_id` must not match an existing entry in `EntityAlias.alias` or `GenericEntity.corporate_id`.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`; see also "Notes on Hashing" on how to detect if row values have changed)
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'person', 'corporate_id', 'mol_file', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" section)
* `mol_file`: REQUIRED (text: `EMPTY_MOL_FILE_STRING`) - must be in MDL MOL format or single SDF
* `corporate_id`: REQUIRED/UNIQUE (text) - as it says in the tin (will be used for incremental updates unless `customer_key` is available)
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `mol_hash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of `mol_file` (see "Notes on Hashing" in Usage section)
* `canonical_smiles`: OPTIONAL (text) - if you have it, only used for reference
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`EntityAlias <simpleschema.html#models.EntityAlias>`_
******************************************************

This table contains compound and generic entity aliases and is mapped to ld_entity_alias.

* `alias`: PK/UNIQUE (text) - string alias of compound
* `compound_id`: FOREIGN KEY to Compound table (int) - either compound_id or generic_entity_id should be set
* `generic_entity_id`: FOREIGN KEY to GenericEntity table (int) - either compound_id or generic_entity_id should be set
* `source_id`: OPTIONAL FOREIGN KEY to Source table

`CompoundProject <simpleschema.html#models.CompoundProject>`_
***************************************************************

This table contains compound project ACLs and is mapped to ld_entities_projects. Note that if primary is True, then
mapping will be for `syn_compound.project`, otherwise the mapping will be for `ld_compounds_projects.project`.

* `id`: PK/AUTO (bigserial)
* `compound_id`: FOREIGN KEY to Compound table (int)
* `project_id`: FOREIGN KEY to Project table (int)
* `primary`: OPTIONAL (bool: `false`) - boolean field to indicate if primary project ACL
* `source_id`: OPTIONAL FOREIGN KEY to Source table

`Lot <simpleschema.html#models.Lot>`_
***************************************

This table contains lot/batch/sample details and is mapped to syn_sample.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'person', 'compound', 'customer_key', 'salt', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
* `key`: REQUIRED (text) - suffix of full lot ID, such as "1" of "CPD1234-1" or "02" of "CPD1234-02"; unique composite key of (`key`, `compound_id`)
* `compound_id`: REQUIRED/FOREIGN KEY to Compound table; unique composite key of (`key`, `compound_id`)
* `salt`: OPTIONAL (text) - suffix of salt name of full lot+salt ID, such as "S01" of "CPD1234-02-S01"
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `page`: OPTIONAL FOREIGN KEY to Page table (int) - the document/notebook page of the lot; shows up in LD under the ‘Notebook Page’ database column.
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `lot_id_full`: REQUIRED/UNIQUE (text) - the full ID for this lot, such as "CPD1234-02" or "CPD1234-02-S01" (if you want to use the full salt ID)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`LotProject <simpleschema.html#models.LotProject>`_
****************************************************

This table contains lot project ACLs and is mapped via JOIN to Compound tables to ld_compounds_projects. Note that this is a workaround for LiveDesign not supporting lot-level ACLs.

* `id`: PK/AUTO (bigserial)
* `lot_id`: FOREIGN KEY to Lot table (int)
* `project_id`: FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`Assay <simpleschema.html#models.Assay>`_
******************************************

This table holds details of type of phenomenon being measured in an assay/protocol, particularly the name (syn_phenomenon_type.name, e.g.
"A2A Binding" or "Calculated Properties") and version (syn_observation_protocol.version_num; e.g. "1" or "Bob's v1.7").

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for assay/protocol/version from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'version', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `key`: REQUIRED (text) - assay/protocol name; used for column naming and grouping of assays into folders; all assay endpoints will be grouped under this name
* `version`: OPTIONAL (text: `'1'`) - assay/protocol version; displays as "Protocol" in hover-over tooltips; may be used for column naming depending on whether PROTOCOL is included in aggregation mode
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

An assay can have multiple protocol versions, contain one or more endpoints, and be run in multiple experiment runs. An
`assay_id` is required for any Observation. The `Assay.key` field is the name of the assay/protocol (e.g. "A2A
Binding"). It will be used in column naming, grouping of assay endpoints, and placing assays/endpoints in folders in the
LiveDesign Data & Columns tree. The `Assay.version` field is the version of the assay/protocol (e.g. "v20220401" or
"PROTOCOL-1234") and is optional. It's value will appear in column tooltips. Depending on aggregation mode, the
assay/protocol version can be used in column naming (default not). There is no unique constraint on the `Assay.key`
field however there is a  unique constraint on the (`Assay.key`, `version`) composite key.

`Experiment <simpleschema.html#models.Experiment>`_
*****************************************************

This table contains details of the run of a particular version of an assay/protocol on a particular date.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for experiment from customer's source DB
* `assay_id`: REQUIRED FOREIGN KEY to Assay table (int)
* `key`: OPTIONAL (text) - experiment name/identifier; if set will be used as primary grouping identifier for all observations in this experiment, otherwise will use `customer_key` (if set), otherwise `id`
* `timestamp`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when experiment was run; will be used as secondary grouping identifier; also what’s used in adv search limited to experimental dates
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'timestamp', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

The `Experiment.key` field is the name/identifier of the experiment (e.g "Box1"). A notebook/page identifier could also
be used here, though see the "Document" and "Page" sections below. If set, the `Experiment.key` will appear in tooltips
and be used as the "primary grouping key" to align observations from different endpoints for the same assay and
experiment run. If `Experiment.key` is unset, the DI mappings will fall back setting the "primary grouping key" to
`Experiment.customer_key`, then `Experiment.id`, then `'0'`. The `Experiment.timestamp` field will appear in tooltips,
be used for advanced searching for observations by date, and will be used as the "secondary grouping date" to align
observations from different endpoints for the same assay and experiment. If `Experiment.timestamp` is unset the
"secondary grouping date" will fall back to `now()` (in the postgres server's timezone).

Experiments' values are optional – particularly `Experiment.key` and `Experiment.timestamp` – but references from the
observations tables is required. If the observation row's `experiment_id` is unset and/or there are no rows in the
`Experiment` table then the observation row will not be selected by the DI query and will not get sync'd into
LiveDesign. Note there is no check that the observation's `assay_id` is the same as the `assay_id` for the Experiment
referenced by the observation's `experiment_id` field. Any ETLs should ensure that these values are not in conflict.

`Document <simpleschema.html#models.Document>`_
*************************************************

This table contains document keys (names/identifiers) and will be mapped to syn_document (referred to by observation tables/syn_observation mappings).

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for document from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `key`: REQUIRED (varchar255) - document name/identifier (appears as "Notebook" in the hover-over tooltip)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`Page <simpleschema.html#models.Page>`_
****************************************

This table contains document page keys (names/identifiers) and may be referred to by syn_observation.document_page.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for document page from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived', 'document_id'} fields in the row (see "Notes on Hashing" in Usage section)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `key`: REQUIRED (text) - document page name/identifier (appears as "Notebook" in the hover-over tooltip)
* `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Note that page can be a child of document (via document_id PK) OR document and page can be unrelated entities.

`CompoundProperty <simpleschema.html#models.CompoundProperty>`_
*****************************************************************

This table contains compound-level properties (database columns) and will be mapped to syn_observation with 1 AS compound_level and
'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for compound property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key`: REQUIRED (text) - name of the property
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `compound_id`: REQUIRED/FOREIGN KEY to Compound table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`CompoundObservation <simpleschema.html#models.CompoundObservation>`_
**********************************************************************

This table contains compound-level observations and will be mapped to syn_observation with compound_level == 1.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for (compound) observation from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
* `compound_id`: REQUIRED FOREIGN KEY to Compound table (int)
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
* `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
* `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
* `std_dev`: OPTIONAL (double) - standard deviation of the observation value
* `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
* `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
* `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
* `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
* `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
* `document_id`: OPTIONAL FOREGIN KEY to Document table (int)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`CompoundObservationProject <simpleschema.html#models.CompoundObservationProject>`_
*************************************************************************************

This table contains compound observation project ACLs and will be mapped to ld_observations_projects.

* `id`: PK/AUTO (bigserial)
* `compoundobservation_id`: REQUIRED FOREIGN KEY to CompoundObservation table (int)
* `project_id`: REQUIRED FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`LotProperty <simpleschema.html#models.Property>`_
****************************************************

This table contains lot-level properties (database columns) and will be mapped to syn_observation with 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key`: REQUIRED (text) - name of the property
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `lot_id`: REQUIRED/FOREIGN KEY to Lot table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`LotObservation <simpleschema.html#models.LotObservation>`_
*************************************************************

This table contains lot-level observations and will be mapped to syn_observation.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'lot', 'text_value', 'assay', 'std_dev', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
* `lot_id`: REQUIRED FOREIGN KEY to Lot table
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
* `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
* `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
* `std_dev`: OPTIONAL (double) - standard deviation of the observation value
* `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
* `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
* `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
* `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
* `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
* `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`LotObservationProject <simpleschema.html#models.LotObservationProject>`_
***************************************************************************

This table contains lot observation project ACLs and will be mapped to ld_observations_projects.

* `id`: PK/AUTO (bigserial)
* `lotobservation_id`: REQUIRED FOREIGN KEY to LotObservation table (int)
* `project_id`: REQUIRED FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`File <simpleschema.html#models.File>`_
*****************************************

A table for generic entity files and mapped to ld_manageable_file and ld_data_blob.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'extension', 'person', 'project', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
* `key`: REQUIRED (text) - filename of the file
* `extension`: REQUIRED (text) - extension/type of the file
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `project_id`: FOREIGN KEY to Project table
* `blob`: REQUIRED (bytea) - binary blob of file contents
* `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`GenericEntity <simpleschema.html#models.GenericEntity>`_
***********************************************************

This table holds generic entity information and is mapped to ld_generic_entity. Note that `corporate_id` must not match an existing entry in `EntityAlias.alias` or `GenericEntity.corporate_id`.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`; see also "Notes on Hashing" on how to detect if row values have changed)
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'corporate_id', 'file_id', 'person'} fields in the row (see "Notes on Hashing" section)
* `file_id`: OPTIONAL FOREIGN KEY to File table (int)
* `corporate_id`: REQUIRED/UNIQUE (text) - as it says in the tin (will be used for incremental updates unless `customer_key` is available)
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)


`GenericEntityProject <simpleschema.html#models.GenericEntityProject>`_
*************************************************************************

This table contains generic entity project ACLs and is mapped to ld_entities_projects.

* `id`: PK/AUTO (bigserial)
* `generic_entity_id`: FOREIGN KEY to GenericEntity table (int)
* `project_id`: FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`GenericEntityProperty <simpleschema.html#models.GenericEntityProperty>`_
***************************************************************************

This table contains generic entity level properties (database columns; mapped to syn_observation with 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id).

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key`: REQUIRED (text) - name of the property
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `generic_entity_id`: REQUIRED/FOREIGN KEY to GenericEntity table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`GenericEntityObservation <simpleschema.html#models.GenericEntityObservation>`_
*********************************************************************************

This table contains generic entity level observations (mapped to syn_observation).

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
* `generic_entity_id`: REQUIRED FOREIGN KEY to GenericEntity table (int)
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
* `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
* `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
* `std_dev`: OPTIONAL (double) - standard deviation of the observation value
* `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
* `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
* `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
* `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
* `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
* `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`GenericEntityObservationProject <simpleschema.html#models.GenericEntityObservationProject>`_
***********************************************************************************************

This table contains generic entity observation project ACLs (mapped to ld_observations_projects).

* `id`: PK/AUTO (bigserial)
* `generic_entity_observation_id`: FOREIGN KEY to GenericEntityObservation table (int)
* `project_id`: FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`Structure <simpleschema.html#models.Structure>`_
***************************************************

This table is for representing structures for 3D assays (mapped to ld_structure, ld_structure_data, and ld_data_blob). The records here must be referenced by an observation table for the data to show up in LD.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'type', 'format', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
* `key`: REQUIRED (text) - the name of the structure to shows up in the 3D visualizer
* `type`: REQUIRED (text) - the type of the 3D structure; must be one of ('LIGAND', 'PROTEIN', 'OTHER', 'ANIMATION')
* `format`: REQUIRED (text) - extension/type of the file; must be one of ('PSE', 'MAE', 'MAEGZ', 'VIB')
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `blob`: REQUIRED (bytea) - binary blob of file contents
* `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`Pose <simpleschema.html#models.Pose>`_
*****************************************

This table is for representing poses in LiveDesign (mapped to ld_pose). Pose records must be created if you want to create pose-level data in an observation table. Different poses show up as different rows in row-per-pose mode.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'compound', 'generic_entity', 'key', 'person'} fields in the row (see "Notes on Hashing" in Usage section)
* `compound_id`: OPTIONAL FOREIGN KEY to Compound table (int) - one of `compound_id` or `generic_entity_id` must be set
* `generic_entity_id`: OPTIONAL FOREIGN KEY to GenericEntity table (int) - one of `compound_id` or `generice_entity_id` must be set
* `key`: REQUIRED (text) - suffix of full pose ID, such as "1" of "CPD1234#1" or "02" of "GEN1234#02"
* `pose_id_full`: REQUIRED/UNIQUE (text) - the full ID for this pose, such as "CPD1234#1" or "GEN1234#02"
* `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
* `project_id`: OPTIONAL FOREIGN KEY to Project table (int) - the project associated with the pose; no user effect right now
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Note that `key` and `pose_id_full` are not used by DI and are merely used for ensuring unique identification for compound and generic entity poses. If only `key` is provided then the `pose_id_full` will be appended to the parent's corporate_id with a `'#'` separator.

`PoseObservation <simpleschema.html#models.PoseObservation>`_
***************************************************************

This table contains pose level observations (mapped to syn_observation).

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
* `pose_id`: REQUIRED FOREIGN KEY to Pose table
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `structure_id`: OPTIONAL/UNIQUE FOREIGN KEY to Structure table (int) - structure value for the property (only one value should be set)
* `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
* `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
* `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
* `std_dev`: OPTIONAL (double) - standard deviation of the observation value
* `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
* `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
* `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
* `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
* `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
* `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`PoseObservationProject <simpleschema.html#models.PoseObservationProject>`_
*****************************************************************************

This table contains generic entity observation project ACLs (mapped to ld_observations_projects).

* `id`: PK/AUTO (bigserial)
* `pose_observation_id`: FOREIGN KEY to PoseObservation table (int)
* `project_id`: FOREIGN KEY to Project table (int)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

`EntityMetadata <simpleschema.html#models.EntityMetadata>`_
*************************************************************

This table contains names (keys), folder path, and value types for metadata for generic entities, which is strongly
preferred over the GenericEntityProperty table.

* `id`: PK/AUTO (bigserial)
* `key`: REQUIRED/UNIQUE (text) - the name of the metadata
* `folder_path`: OPTIONAL (text) - name of the folder that the metadata should appear under. All entity metadata will appear under "Other Columns/Entity Metadata". An empty string will put the column into "Other Columns/Entity Metadata" tree. Use "/" as delimiter for subfolders.
* `value_type`: REQUIRED (varchar255: `'STRING'`) - value type of the metadata column. Must be one of:  INTEGER, FLOAT, STRING, DATE, DATETIME; defaults to 'STRING'.
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Additional Notes:

* This is new in 22.4. Both ENABLE_GENERIC_ENTITY & ENABLE_GENERIC_ENTITY_LOT must be true in the admin panel properties
* This table can only be used to put metadata value on generic entities, but may also be extended to all entities in the future
* Mapping this table overlaps with mapping syn_observation with assay_type set to DATA_INTEGRATED_DATABASE_COLUMN, as they both create metadata columns that appear under the "Other Columns" tree.
* For small molecules you still must use syn_observation, but for GEs, it is highly recommended that `ld_entity_metadata` is mapped over `syn_observation` for metadata since this table is going to be used for future features implemented for metadata.

`EntityMetadataValue <simpleschema.html#models.EntityMetadataValue>`_
***********************************************************************

This table contains metadata values for a generic entity.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `genericentity_id`: REQUIRED/FOREIGN KEY to GenericEntity table (int)
* `key_id`: REQUIRED/FOREIGN KEY to EntityMetadata table (int)
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Additional Notes:

* This is new in 22.4. Both ENABLE_GENERIC_ENTITY & ENABLE_GENERIC_ENTITY_LOT must be true in the admin panel properties.
* This table can only be used to put metadata value on generic entities, but may also be extended to all entities in the future.
* Only one value can be recorded for a genericentity_id - key_id pair; there is a unique constraint on tuple (genericentity_id, key_id).
* Only one value can be set (but all can be set to null).

`Metadata <simpleschema.html#models.Metadata>`_
*************************************************

This table contains keys for assay or observation metadata.

* `id`: PK/AUTO (bigserial)
* `key`: REQUIRED/UNIQUE (text) - the name of the metadata
* `assay_level`: OPTIONAL (bool: `true`) - boolean field to indicate metadata level for which the key is used; true = ASSAY, false = OBSERVATION.

Additional Notes:

* A name can only be recorded once for a metadata level. In other words, the table enforces unique constraint on tuple (key, assay_level).

`AssayMetadataValue <simpleschema.html#models.AssayMetadataValue>`_
********************************************************************

This table contains metadata values for an assay.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
* `assay_id`: REQUIRED/FOREIGN KEY to Assay table (int)
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Additional Notes:

* The assaymetadatakey.assay_level must be True.
* Only one value can be recorded for an assay_id - key_id pair; there is a unique constraint on tuple (assay_id, key_id).
* Only one value can be set (but all can be set to null).

`ExperimentMetadataValue <simpleschema.html#models.ExperimentMetadataValue>`_
*******************************************************************************

This table contains metadata values for an experiment which will be associated at the assay level (ld_assay_metadata)
if assay_level is True or the observation level (ld_assay_values_metadata) if assay_level is False.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
* `experiment_id`: REQUIRED/FOREIGN KEY to Experiment table (int)
* `assay_level`: OPTIONAL (bool: `false`) - boolean field to indicate metadata level for which the value is used; true = ASSAY, false = OBSERVATION.
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Additional Notes:

* The assaymetadatakey.assay_level must match experimentmetadata.assay_level.
* Only one value can be recorded for an experiment_id - key_id pair; there is a unique constraint on tuple (experiment_id, key_id).
* Only one value can be set (but all can be set to null).

`ObservationMetadataValue <simpleschema.html#models.ObservationMetadataValue>`_
*********************************************************************************

This table contains metadata values for an observation.

* `id`: PK/AUTO (bigserial)
* `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
* `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
* `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
* `compoundobservation_id`: OPTIONAL FOREIGN KEY to CompoundObservation table (int) - only one observation_id should be set
* `lotobservation_id`: OPTIONAL FOREIGN KEY to LotObservation table (int) - only one observation_id should be set
* `genericentityobservation_id`: OPTIONAL FOREIGN KEY to GenericEntityObservation table (int) - only one observation_id should be set
* `poseobservation_id`: OPTIONAL FOREIGN KEY to PoseObservation table (int) - only one observation_id should be set
* `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
* `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
* `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
* `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
* `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

Additional Notes:

* The assaymetadatakey.assay_level must be False.
* One and only one observation_id must be set; there is a check constraint on `num_nonnulls(compoundobservation_id, lotobservation_id, genericentityobservation_id, poseobservation_id) = 1`
* Only one value can be recorded for an observation_id - key_id pair; there is a unique constraint on tuple (key_id, compoundobservation_id, lotobservation_id, genericentityobservation_id, poseobservation_id).
* Only one value can be set (but all can be set to null).

`GenericEntityLink <simpleschema.html#models.GenericEntityLink>`_
*********************************************************************************

A table holding linking type and linking text of a generic entity.

This table is only supported in LD ≥ 2023.3.0. Currently, only expected to work with biologics entities. The
current biologics work flow works like this. After mapping this table, LD will:

1. Send the GE's file to bbchem for processing
2. The returned processed structure should include a canonical hash for the GE structure.
3. The canonical hash is then matched against canonical hashes of virtuals in the system
4. Matching virtuals are automatically linked to the real GE

* `id`: PK/AUTO (bigserial)
* `generic_entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
* `linking_type`: REQUIRED (text: 'REAL') - must be 'REAL'

`EntityRelationshipParent <simpleschema.html#models.EntityRelationshipParent>`_
*********************************************************************************

A table holding linking type and linking text of a generic entity.

This table contains the parents in a multi-component entity.

This table is only supported in LD ≥ 2023.3.0.

* `id`: PK/AUTO (bigserial)
* `entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
* `relationship_type`: REQUIRED (text: 'FORMULATION') - type of relationship

`EntityRelationshipChild <simpleschema.html#models.EntityRelationshipChild>`_
*********************************************************************************

This table contains the children in a multi-component entity.

This table is only supported in LD ≥ 2023.3.0. There are two unique constraints on this table -
(entity_id, parent_id) and (parent_id, child_order).

* `id`: PK/AUTO (bigserial)
* `entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
* `parent(_id)`: REQUIRED FK to EntityRelationshipParent (int) - EntityRelationshipParent.id
* `child_order`: REQUIRED (int) - integer denoting order among various children of a parent

`EntityRelationshipMetadata <simpleschema.html#models.EntityRelationshipMetadata>`_
***********************************************************************************

This table contains metadata for multi-component entities that are registered in the
EntityRelationship(Parent/Child) tables.

This table is only supported in LD ≥ 2023.3.0.

* `id`: PK/AUTO (bigserial)
* `relationship_child(_id)`: REQUIRED FK to EntityRelationshipChild (int) - ID of relationship across which the metadata is recorded (EntityRelationshipChild.id)
* `key`: REQUIRED (text) - Metadata key
* `value`: REQUIRED (text) - Metadata value


ETL/Audit Table Models
########################

Note that the Source, Config, and ETLRun tables are optional and are only used for auditing purposes and particular
ETL implementations.

`Source <simpleschema.html#models.Source>`_
********************************************

This table tracks uploads of data into the SimpleSchema (ETL runs).

* `id`: PK/AUTO (bigserial)
* `key`: REQUIRED/UNIQUE (text) - filename or other reference for data source
* `config_id`: OPTIONAL FK to Config table (int)
* `person`: OPTIONAL (text: `'LiveDesign'`) - name of person who uploaded data source
* `project_id`: OPTIONAL FOREIGN KEY to Project table (int) - project associated to all data uploaded with this source
* `uploaded`: OPTIONAL (timestamp) - timestamp source was uploaded
* `processed`: OPTIONAL (timestamp) - timestamp source was processed
* `purged`: OPTIONAL (timestamp) - timestamp source was purged
* `partial_purge`: OPTIONAL (int2) - whether source was partially (1) or fully purged (0)

`Config <simpleschema.html#models.Config>`_
********************************************

This table holds ETL config information.

* `id`: PK/AUTO (bigserial)
* `config`: OPTIONAL (json) - JSON field to store config settings used for loading/transforming data
* `key`: REQUIRED/UNIQUE (text) - name for configuration settings
* `project_id`: OPTIONAL FOREIGN KEY to Project table (int) - project associated to all data uploaded with this config
* `person`: OPTIONAL (text) - name of person who created/updated config
* `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
* `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
* `archived`: OPTIONAL (int2: `0`) - "soft delete" option; 1 for archived/deleted
* `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'archived', 'config', 'customer_key', 'key', 'person', 'project'} fields in the row (see "Notes on Hashing" in Usage section)

`ETLRun <simpleschema.html#models.ETLRun>`_
*********************************************

This table tracks the start/end times and status of the last ETL run. There is an optional relationship to the Source
table to track config used, filenames or other identifiers, etc.

* `id`: PK/AUTO (bigserial)
* `started`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when ETL run was started/record was created
* `finished`: OPTIONAL (timestamp without timezone) - timestamp of when ETL run was finished
* `status`: OPTIONAL (varchar255: `'CREATED'`) - status of ETL run; suggested labels are CREATED, RUNNING, LOAD_FINISHED, LOAD_FAILED, FINISHED, FAILED
* `source`: OPTIONAL FOREIGN KEY to Source table (int)

Primary Key, `customer_key` and `key` fields
###############################################

All tables have an auto-incrementing big integer primary key field `id`. Primary keys should not be re-used, for example
if data is deleted and reloaded into the schema, otherwise the Data Integrator service may ignore those rows as already
processed. The `id` fields are used in any foreign key relationships between tables (e.g. `Lot.compound_id -> Compound.id`).

Most tables have a `customer_key` field for storing (string) primary keys from the customer's source database. It is
strongly recommended using these values if they are available as they can allow for incremental updates, particularly
of observation, experiment, and/or assay rows. The `customer_key` can also be useful for updating the `key` or other
unique identifiers for an entity, `Compound.corporate_id` for example.

The `key` fields in tables are for storing (string) name/identifiers for the entity. Most `key` fields contain a unique
index and can be used for querying. The exceptions for this are:

* In the Compound table, the `Compound.corporate_id` field is for storing the unique string identifier of the compound (e.g. `'CPD1'`).
* In the Lot table, the `Lot.key` field is used for storing the batch name/identifier (e.g. `'1'`) with a non-unique index and the `Lot.lot_id_full` is for storing the full lot ID (e.g. `'CPD1-1'`) and has a unique index.
* In the Pose table, the `Pose.key` is used for storing the pose name/identifier (e.g. `'1'`) for either a compound or generic entity parent with a non-unique index and the `Pose.pose_id_full` is for storing the full pose ID (e.g. `'CPD1#1'` or `'GEN1#02'`) and has a unique index.
* In the File and Structure tables, the `key` field is used for storing the filename or name of the structure but does not have a unique index.

Compound and Generic Entity corporate IDs and aliases integrity
##################################################################

`Compound` and `GenericEntity` parent entities share a common `EntityAlias` table. In order to ensure identity integrity
across these parent entities the following must be observed:

* A `compound.corporate_id` should not be registered that matches an existing `genericentity.corporate_id`
* A `genericentity.corporate_id` should not be registered that matches an existing `compound.corporate_id`
* An `entityalias.alias` Aliases should not be registered that matches an existing `compound.corporate_id` or `genericentity.corporate_id`

The simpleschema python API has checks for these in the `prep_and_validate_values()` and/or `register()` methods each of
these table models. Direct SQL users should do their own integrity checks before registering or updating `corporate_id`
or `alias` values.

Observation endpoint and value(s)
##################################

An observation row's `endpoint` field is the particular type of observation being measured in a given assay (e.g. "Ki",
"IC50", "% Inhibition"). An assay can have more than one endpoint associated with it. The endpoint, along with `unit`,
`conc`, and `conc_unit`, will be used to name the assay column in LiveDesign. All endpoints with the same `Assay.key`
will be grouped under that assay and its folder in the LiveDesign Data and Columns tree.

Only one of `text_value`, `num_value`, `date_value`, or `structure_id` (PoseObservation table only) should be used for
any property or observation. If using the Python API, the `simpleschema.utils.try_cast_as_float() <simpleschema.html#utils.try_cast_as_float>`_ and/or
`simpleschema.utils.parse_operator_and_convert_to_number() <simpleschema.html#utils.parse_operator_and_convert_to_number>`_ helper methods can help automatically parse a property or
observation value.

Note DI will coalesce an observation row's `(experiment.key, experiment.customer_key, experiment.id, '0')` to set the
"primary grouping key" for all endpoints in the same assay+version+experiment+compound/lot. This "primary grouping key"
is used for aligning values from different endpoints for the same compound/lot in the same
assay/version + experiment run, particularly in Row per Experiment mode. Different compounds/lots for the same
experiment run can use the same "primary grouping key" and thus the same experiment row or default `'0'` value. If,
however, there are more than one replicate of the same compound/lot in the experiment run then each replicate for the
same compound/lot should get a unique Experiment set, thus allowing them to have unique "primary grouping key" values.
For example, if CPD1 is run twice in experiment you could name one experiment `Experiment` and the other `Experiment-1`.
Another option would be to concatenate the Box ID or file/row number and register a new experiment for every replicate
in the experiment run. This is particularly useful for loading data from flat files such as SDF or CSV but can cause
excessive data replication in the Experiment table.

Generic Entity and Structure files
####################################

SimpleSchema supports loading files for Generic Entities or (Pose Observation) Structures as binary data into the `blob`
field of the `File` and `Structure` tables, respectively. File name or content/hash uniqueness is not enforced. It is
strongly recommended to check for file uniqueness before registering files (see Note on Hashing section below).

Updates vs. full reloads
##########################

If the data provides a unique key for individual data points or compounds they can optionally store them in the database
with the "customer_key" fields. This may allow for data to be updated incrementally by comparing new values with those
stored previously, which is favorable for LD performance. In cases where updates/inserts can not be simply parsed, it is
often reasonable to clear all assay values and reload from scratch on some regular basis.

Storing canonical smiles and mol_files
########################################

There are separate fields in the Compound class for `canonical_smiles` and `mol_files`. Data Integrator requires a MOL
file to register structures, but MOL files are poorly standardized. The canonical SMILES field is provided as a
convenience to determine if a structure has been updated, and is optional. Note that string comparison of (canonical)
SMILES or MOL/SDF is a slow and inaccurate method of comparing whether two structures are different. A
`Compound.mol_hash` field is also available for quickly checking for differences in the `mol_file` field. See "Notes on
Hashing" section below.

Notes on Hashing
#################

The many of the SimpleSchema table models provide a column for storing a hash of select columns in the row (`rowhash`).
This hash allows for the quick comparison of entities for detecting differences between corresponding SimpleSchema and
source DB rows. In the Python API, example/suggested fields (columns) are provided for each "hashable" model (table)
(`Model.hashable_fields`). These fields and/or the methods to generate the hash can be customized. By default, the
Python API will automatically calculate the `rowhash` when using the Model.register() method, though note that only fields
that are in the `hashable_fields` list AND in the model will be used to generate the (auto)hash. For
example, the LotObservation and CompoundObservation both have `compound` and `lot` in their `hashable_fields` list but
`lot` will only be used for LotObservation and `compound` will only be used for CompoundObservation. Any methods that
update fields in a (hashable) model entity/row should also update the `rowhash`.

Any ETL script utilizing the `rowhash` column for comparisons should ensure that the list of columns/fields, name of keys,
and their order in the dictionary object used to generate/compare the hash value is the same for both the source DB and
the SimpleSchema.

The Compound table model also provides a column for storing a hash of the `mol_file` field. This hash allows for the
quick comparison of the row's `mol_file` for differences. Any ETL script should ensure that this hash is generated
using the same algorithm for new and existing rows. The Python API defaults to using MD5 on the binary encoded
`mol_file` string.

The File and Structure table models also provide columns for storing a hash of the `blob` field. This hash allows for the
quick comparison of the row's `mol_file` for differences and/or duplicates. Any ETL script should ensure that this hash
is generated using the same algorithm for new and existing rows. The Python API defaults to using SHA256, returning a
hexdigest string, for the `blob_hash` fields in these tables.

Notes on Metadata
###################

For entity metadata, LiveDesign and DataIntegrator only support adding metadata onto generic entities; this may be
extended to all entities in the future. Entity metadata is similar to Entity Properties and appears in a similar way in
LiveDesign, under the "Other Columns" of the Data & Columns tree. For Generic Entities, it is highly recommended that
EntityMetadata / EntityMetadataValue is used over GenericEntityProperty for metadata, since these tables are going to
be used for future features implemented for metadata.

For assay metadata, LiveDesign and DataIntegrator only support adding metadata onto the assay or observation level;
experiment-level metadata is not (currently) supported. To add experiment-level metadata in the ExperimentMetadataValue
table a choice must be made whether to associate the metadata to the assay or all observations for that experiment.
This is controlled by the ExperimentMetadataValue.assay_level boolean, where `true` will associate it with the assay in
`experiment.assay_id` and `false` will associate it with all observations that have that `experiment_id` set.

Python API
------------

SimpleSchema Python Package Installation
###########################################

**Requirements**

* Python ≥ 3.8 virtual environment
* All other package requirements are managed by pip

SimpleSchema Setup
*******************

1. If you have not already, create a user and create a database with the user as the owner:

.. code-block:: bash

    psql -h localhost -p 3247 -U postgres -c "CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_pass'"
    psql -h localhost -p 3247 -U postgres -c "CREATE DATABASE example_db WITH OWNER 'simplschema_owner'"

2. Find the `simpleschema release tar.gz file <https://github.com/schrodinger/livedesign-simpleschema/releases>`_ for the version you want to install and download/transfer it to where you want to install the package.

3. Set up a virtualenv (python ≥ 3.8) and install the simpleschema package (in this example, release tag = `v1.2.2`):

.. code-block:: bash

    virtualenv -p `which python3` venv
    source venv/bin/activate
    pip3 install livedesign-simpleschema-1.2.2.tar.gz

If you want extra features, such as AIO or Web API, add them to the egg as a csv with no spaces (on OSX/ZSH you may need to escape the first square bracket):

Ensure AIO requirements are met:

.. code-block:: bash

    pip3 install livedesign-simpleschema-1.2.2.tar.gz/[aio]

Ensure Web API requirements are met:

.. code-block:: bash

    pip3 install livedesign-simpleschema-1.2.2.tar.gz/[web]

Ensure that both AIO and Web API requirements are met:

.. code-block:: bash

    pip3 install livedesign-simpleschema-1.2.2.tar.gz/[aio,web]

4. Create tables (change `example_db`, `example_user`, and `example_pass` appropriately):

.. code-block:: bash

    create_tables --user example_user --password example_pass example_db

    #run 'create_tables -h' for more options

Development Setup
*******************

To install the SimpleSchema in a development environment, first clone the `livedesign-simpleschema git repo <https://github.com/schrodinger/livedesign-simpleschema.git>`_
and checkout a new or existing branch. After creating and activating your virtualenv, run:

.. code-block:: bash

    virtualenv -p `which python3` venv
    source venv/bin/activate
    pip3 install -e livedesign-simpleschema/.

    # Add any optional features in a similar way as above, example:
    pip3 install -e /path/to/livedesign-simpleschema/.[aio]


For development work you can manually start a Postgresql 14 Docker container and create the database for use with the
python API:

.. code-block:: bash

    #This must be run in a virtualenv with the simpleschema package installed and by a user who has docker privs
    PGCONTAINER=$(docker run -d -p 0.0.0.0:3248:5432 -e POSTGRES_USER=simpleschema -e POSTGRES_PASSWORD=simpleschema postgres:14)
    sleep 2
    docker exec $PGCONTAINER psql -U simpleschema -c "CREATE DATABASE example_db"
    create_tables example_db --port 3248

    #to run interactive psql from outside the container:
    PGPASSWORD=simpleschema psql -h localhost -p 3248 -U simpleschema -d example_db

When you are done with the docker container you can stop/remove it with:

.. code-block:: bash

    docker rm -f $PGCONTAINER


Using the Python API
**********************

The SimpleSchema class offers a few utility and class functions which can be used interactively or in your ETL scripts.
See `livedesign-integrations/SDFU/` for examples of customizing the peewee/simpleschema objects and
methods for writing to the SimpleSchema database.

* `simpleschema.models.BaseModel <simpleschema.html#models.BaseModel>`_ class has methods that all Model classes inherit, with the ability to customize these on a per-model basis, such as:

 * `prep_and_validate_values()`: prepare and validate kwargs before register() method is called (most/all `register()` methods should call this on their own)
 * `register()`: get_or_create a model instance with the provided parameters
 * `bulk_prep_and_validate_values()` and `bulk_register()`: similar to `prep_and_validate_values()` and `register()` but uses `insert_many` on a list of rows with upsert capability

* `simpleschema.utils <simpleschema.html#module-utils>`_ has additional static helper methods, such as:

 * `value_to_kwargs()`: try to parse a `value` parameter to a dict with number (with operator), text, or date value
 * `check_num_text_date_values()`: do some validation on the number, text, and date value
 * `generate_hash()`: generate an MD5 hash of the provided string or dict
 * `try_cast_as_float()`: try to cast a provided string value as a float
 * `parse_operator_and_convert_to_number()`: try to strip out allowed operators from a string value and cast the rest as a float
 * `file_full_path_to_kwargs()`: takes a (full/relative) file path, reads the file, and returns a dictionary of filename, extension, and blob

* Compound and GenericEntity table models have `register_alias()`, `register_lot()`, and `switch_primary()` methods
* Compound, Lot, and GenericEntity table models have `register_acl()`, `register_observation()`, and `register_property()` methods

* Assay and/or full data clearing methods (these should be avoided in production):

 * `simpleschema.schemas.SimpleSchema.clear_assay_values() <simpleschema.html#schemas.SimpleSchema.clear_assay_values>`_: method to delete all existing assay data. Used in cases where incremental changes are not available from the source data. It is strongly recommended to not use this method.
 * `simpleschema.schemas.SimpleSchema.clear_all() <simpleschema.html#schemas.SimpleSchema.clear_all>`_: method to truncate all tables and reset all identity sequences. Use sparingly and only in testing. If used in prod, a full re-DI is required each time.

Insert, Update, Delete
***********************

All database values can be inserted, updated, or deleted from the python interpreter. For example, you can quickly update a compound structure or change specific assay values by manipulating the ORM objects. Please see the PeeWee documentation for additional details.

.. code-block:: python

    from simpleschema.schemas import SimpleSchema
    from simpleschema.models import Project, Compound, Lot, LotObservation

    mol = '''some MOL file string'''
    corp_id = 'CPD1234'
    batch_no = 1
    target_schema = SimpleSchema('NAME_OF_DATABASE')

    with target_schema.db.atomic():
        global_project = Project.register(key='Global', is_restricted=0)
        compound = Compound.register(project=global_project, mol_file=mol, corporate_id=corp_id)
        lot = Lot.register(compound=compound, key=batch_no)
        assay_result = lot.register_observation(assay_name='Foo', endpoint='Bar', num_value=23)
        # or
        assay_result2 = LotObservation.register(lot=lot, assay_name='Foo', endpoint='Bar', num_value=42)

These objects can be queried and updated, and once saved will be updated immediately in LD.

.. code-block:: python

    from simpleschema.models import Compound

    cmpd = Compound.get(key='CPD1234')
    cmpd.mol_file = '''some new MOL file string'''
    cmpd.save()

prep_and_validate_values(), register(), register_or_update(), and upsert()
**************************************************************************

The `prep_and_validate_values()` method will, after any Model-specific overrides, strip out any arguments that do not
match fields in the model class. In addition, if any of the arguments refer to another model (e.g. `compound=foo`) and
the value of that argument is not a Model class (e.g. `CompoundProject.register(compound='CPD1')`) the
`prep_and_validate_values()` will attempt to get the model instance based on the `Model.lookup_field_name` (e.g.
`compound=Compound.get(corporate_id='CPD1')`). If this model entity does not exist (e.g. a compound with 'CPD1'
corporate ID has not been registered yet) then a `peewee.DoesNotExist` exception will be raised. If multiple models
exist with the provided kwargs (e.g. `Assay.get(key='Foo')` where there are multiple assays with name 'Foo' and
different versions) then only one will be returned. Note that subsequent gets with the same query may return a different
entity.

The `register()` method on all table models will use the peewee `get_or_create()` method on provided kwargs, passing
them to `prep_and_validate_values()`. If the model has a unique constraint on any of the fields
(e.g. `Compound.corporate_id`) and the kwargs only matches this field and is trying to register a different value for
another field then an IntegrityError will be raised. For example: a compound has already been registered with
`Compound.corporate_id == 'CPD1'` and `Compound.person == None`. A user attempts to register
`Compound.register(corporate_id='CPD1', person='Bob Dobbs')`; this will raise the IntegrityError exception.

It is strongly recommended registering all entities with explicit keyword arguments and/or checking to see if the entity
has already been registered with the `locate()` method. This is particularly important for entities involved in FK
relationships and with unique constraints. For example, when registering observations, the `Assay`, `Experiment`,
`Document`, and `Page` entities should be registered first and then passed to the observation's `register()` method.

The `register_or_update()` method can be used if you are OK with registering a new entity if one can not be located or,
if one is located, then updating the existing registered entity with your provided kwargs (including any explicit
`None` values). See the next section for more details on using `locate()` and the `update_entity()` methods and the
`bulk_register()` section below for similar upsert behavior as `register_or_update()`.

An `upsert()` method is also available on all model classes that will attempt to insert a new row with the provided
kwargs; if there are any conflicts due to an existing entity it will update selected fields/columns for that entity.
See the section below on "bulk_register() and bulk_prep_and_validate_values()" for further details and examples of this
method's behavior.

locate() and update_entity()
*****************************

If you would like to check to see if an entity has already been registered you can use the `locate()` method. This
method is similar to the `find_one()` method, but unlike `find_one()` it can be provided multiple kwargs. Only one of
three possible identity fields – `id`, `customer_key`, or the `Model.lookup_field_name` – will be iteratively passed, if the
field exists and the value is set, to `find_one()` to see if that entity exists. For example, the `Compound` table
model has both `id` and `customer_key` fields and the `lookup_field_name` is `corporate_id`. If `Compound.locate()` is run
with just `corporate_id=CPD1` set in the kwargs and not `id` or `customer_key` explicitly set then only
`Compound.find_one(corporate_id='CPD1')` will be run, returning the entity with that `corporate_id` if it has already
been registered. If `Compound.locate()` is run with both `corporate_id='CPD1'` and `customer_key='123'` set, then first
`Compound.find_one(customer_key='123')` will be run, and if nothing is found then
`Compound.find_one(corporate_id='CPD1')` will be run. This can be useful in cases where the `corporate_id` has changed
for a compound with the provided `customer_key`.

If you would like to update an entity found using the `locate()` or other methods (such as `find_one()` or
`get_or_none()`) then the `update_entity()` method can be used. Any provided kwargs that are different from what is
currently set on the entity will get updated. If the entity has a `modified_at` field this will automatically get
updated to `utc_now()`. Note that any attributes/fields explicitly set to `None` in the provided kwargs will be used
for the update. The number of fields modified will be returned.

The `register_or_update()` method (see previous section) combines the `register()`, `locate()`, and `update_entity()`
into a single method and allows a quick method to either register a new entity, update an existing entity with any new
values, or simply return the previously registered entity if all the fields match.

bulk_register() and bulk_prep_and_validate_values()
****************************************************

The `bulk_register()` method will, after running the list of rows through `bulk_prep_and_validate_values()`, will
attempt to bulk insert all rows provided in the list of keyword arg dictionaries. If there are any integrity error
conflicts due to existing rows with a matching value in the `Model.lookup_field_name`, then the existing rows will be
updated with the new values; the `id`, lookup field, and `created_at` fields will not be updated. For example, if the
following is run:

.. code-block:: python

    from simpleschema.models import Compound

    Compound.bulk_register([{'corporate_id': 'CPD1', 'mol_file': 'one'},
                            {'corporate_id': 'CPD2', 'mol_file': 'two'}])

and then the bulk register is run again with different/additional values:

.. code-block:: python

    from simpleschema.models import Compound

    Compound.bulk_register([{'corporate_id': 'CPD1', 'mol_file': 'one', 'person': 'Test'},
                            {'corporate_id': 'CPD2', 'mol_file': 'notone', 'person': 'Test'},
                            {'corporate_id': 'CPD3', 'mol_file': 'three', 'person': 'Test'}])

The following results will happen:

* The `id` and `created_at` fields for `CPD1` and `CPD2` will not change; `created_at` will match
* `CPD1` will have its `person` and `modified_at` fields updated
* `CPD2` will have its `mol_file`, `person`, and `modified_at` fields updated
* `CPD3` will be inserted with its `created_at` and `modified_at` time matching the `modified_at` of `CPD1` and `CPD2`


Transactions
**************

Peewee will autocommit on individual operations, so it's often best to wrap procedures in a database transaction. In the
event of an error, no changes will be written to the database and the transaction is rolled back. For this, you can use
the SimpleSchema.db.atomic() context wrapper.

Example:

.. code-block:: python

    from simpleschema.schemas import SimpleSchema
    from simpleschema.models import Project

    target_schema = SimpleSchema('NAME_OF_DATABASE')
    with target_schema.db.atomic():
        project = Project.register(key='Test', is_restricted=1)

Asynchronous IO (AIO) Features
-------------------------------

**NOTE: SimpleSchema AIO features are currently not being further developed as of v1.2.1**

To utilize AIO features in the SimpleSchema python API just use the schema and models from `simpleschema.aio` and add an
`await` before any async method. Example:

.. code-block:: python

    from simpleschema.aio.schemas import SimpleSchemaAsync
    from simpleschema.aio.models import Project

    target_schema = SimpleSchemaAsync('NAME_OF_DATABASE')
    project = await Project.register(key='Test', is_restricted=1)

Customizing Schemas, Table Models, Utilities, and Helper Methods
#################################################################

SimpleSchema is provided as a package that can be installed using pip. Any customizations to any part of the
simpleschema package can be done by either creating a custom branch for your changes or merely adding files to the
livedesign-simpleschema/simpleschema directory structure without adding them to git (master). This will allow you to
inherit and override any classes or methods while still pulling updates/bug fixes from the master repo. An example
`simpleschema/custom.py`:

.. code-block:: python

    """
    Example file for creating your own custom Schema class, Model class, or other functions/overrides. Create a
    custom.py file in the simpleschema package directory (tracked in your branch but not in master). You would call this
    file 'from simpleschema.custom import MySchema'.
    """

    from simpleschema.schemas import SimpleSchema
    from simpleschema import models

    class Foo(models.Project):
        """Some overrides"""

    class MySchema(SimpleSchema):
        """Some overrides and using other custom classes like the Foo model class above"""

WebAPI
-------

Note that the SimpleSchema WebAPI is still under development and should not be used in a production environment.

**Requirements**

* Python ≥ 3.8 virtual environment
* simpleschema package installed with `web` optional features included (e.g. `pip3 install livedesign-simpleschema-release-v1.2.2.tar.gz\[web]`)
* SimpleSchema database and all tables created

WebAPI Setup
#############

Within the virtualenv, set any of the following environment variables if the shown defaults are not desired:

.. code-block:: bash

    export DATABASE=simpleschema
    export DB_HOST=localhost
    export DB_PORT=3247
    export DB_USER=simpleschema
    export DB_PASS=simpleschema
    export SECRET_KEY=$(python -c 'import secrets; print(secrets.token_hex())') #used for securely signing the session cookie; can be any string
    export API_PORT=8870
    export API_TIMEOUT=172800
    export API_WORKERS=2


While still in the virtualenv, run gunicorn:

.. code-block:: bash

    gunicorn -b 127.0.0.1:${API_PORT} --timeout ${API_TIMEOUT} --workers ${API_WORKERS} simpleschema.webapi:app

Development Setup
###################

By default, the WebAPI will use the LiveDesign session/cookies to verify that the user has LD Admin role. In a
development/testing environment you can skip this check by setting the following environment variable to any value:

.. code-block:: bash

    export SIMPLESCHEMA_DEBUG=1

Using the Web API
##################

The Web API has the following routes defined:

* /livedesign/simpleschema/api/find/project
* /livedesign/simpleschema/api/find/compound
* /livedesign/simpleschema/api/find/lot
* /livedesign/simpleschema/api/register/project
* /livedesign/simpleschema/api/register/compound
* /livedesign/simpleschema/api/register/lot

All API endpoints will accept GET (query parameters; e.g `?key=Foo`) or POST (`content-type: application/json` header
and JSON body) requests. If a related table model/foreign key needs referencing (e.g. `Compound.project` or
`Lot.compound`) then it should be provided in the query args/dict as `model_id` with the PK of that model entity. For
example: `/livedesign/simpleschema/api/register/lot?compound_id=1&key=23`

SQL API
---------

**Requirements**

* Postgresql ≥ 10
* DBA access

SimpleSchema Setup
###################

Download/transfer the `simpleschema release tar.gz file <https://github.com/schrodinger/livedesign-simpleschema/releases>`_ for the version you want to install to your database instance.
For this example, the release tag is `v1.2.2` for version `1.2.2`:

.. code-block:: bash

    tar xzf livedesign-simpleschema-1.2.2.tar.gz livedesign-simpleschema-1.2.2/example_schema/simpleschema.sql

This file will create all tables and relations; it will not create the database or set ownership or any other
ACL's/permissions.

Be sure the user and database exists before loading the SQL file.

.. code-block:: bash

    psql -h localhost -p 3247 -U postgres -c "CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_pass'"

Load the SQL dump file using psql and a DBA user.

.. code-block:: bash

    psql -h localhost -p 3247 -U postgres -f livedesign-simpleschema-1.2.2/example_schema/simpleschema.sql

Create a DB User and Grant Access
##################################

Connect to the database as a DBA user, for example:

.. code-block:: bash

    psql -h localhost -p 3247 -U postgres -d example_db

Grant all privileges:

.. code-block:: sql

    CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_pass';
    GRANT ALL PRIVILEGES ON DATABASE example_db to example_user;


Grant limited privileges:

.. code-block:: sql

    CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_password';
    REVOKE ALL ON DATABASE example_db FROM example_user;
    GRANT CONNECT ON DATABASE example_db TO example_user;
    GRANT SELECT,INSERT,DELETE,UPDATE ON ALL TABLES IN SCHEMA public TO example_user;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO example_user;
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO example_user;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO example_user;

Using the SQL API
##################

Inserting new entries should be done in parent to child order (e.g Compound then Lot). Updating existing entities or
inserting new child entities should look up one of the (parent) entity' unique field (e.g. `customer_key`, `key`,
`corporate_id`) or combination of fields (e.g. `assay.key + assay.version`). Using the `customer_key` fields when
inserting new rows and querying for rows is strongly preferred.

Example registrations:

.. code-block:: sql

    INSERT INTO project(key,is_restricted) VALUES ('Global', 0);

    INSERT INTO project(key,is_restricted) VALUES ('Default Restricted Project', 1);

    INSERT INTO compound(corporate_id,mol_file) VALUES ('CPD1', E'your mol file string here');

    INSERT INTO compoundproject(compound_id,project_id,"primary")
    SELECT c.id,p.id,true
    FROM compound c, project p
    WHERE c.corporate_id = 'CPD1' AND p.key = 'Global';

    INSERT INTO lot(compound_id,key,lot_id_full)
    SELECT c.id,'1',CONCAT(c.corporate_id,'-1')
    FROM compound c
    WHERE c.corporate_id = 'CPD1';

    INSERT INTO compoundproperty(compound_id,key,num_value)
    SELECT c.id, 'Some Property', 1.23
    FROM compound c
    WHERE c.corporate_id = 'CPD1';

    INSERT INTO assay(key,version) VALUES ('Assay1', 'Version1');

    INSERT INTO compoundobservation(customer_key, compound_id, assay_id, endpoint, text_value)
    SELECT 1, c.id, a.id, 'Some Endpoint', 'Some text value'
    FROM compound c, assay a
    WHERE c.corporate_id = 'CPD1' AND (a.key = 'Assay1' AND a.version = 'Version1');

    INSERT INTO compoundobservationproject(compound_observation_id,project_id)
    SELECT co.id,p.id
    FROM compoundobservation co, project p
    WHERE co.customer_key = 1 AND p.key = 'Global';

Google CloudSQL
----------------

SimpleSchema can be used with a Postgresql Google CloudSQL instance with some minor adjustments.

Ensure IAM Role for Connecting to the SQL Instance
####################################################

The person setting up SimpleSchema and any users/service accounts that need to connect to the CloudSQL instance and the
SimpleSchema database will need to have the `cloudsql.instances.connect` role granted to them and should set up and
confirm that the `Cloud SQL Proxy <https://cloud.google.com/sql/docs/mysql/connect-auth-proxy>`_ works for them.

The person setting up SimpleSchema in the CloudSQL instance should have the psql client installed and the
cloud-sql-proxy running locally on their machine for the following steps. Example command (where
`INSTANCE_CONNECTION_NAME` can be found on the Overview page for your CloudSQL instance in the Google Cloud console):

.. code-block:: bash

    /path/to/cloud-sql-proxy --address 0.0.0.0 --port 3247 INSTANCE_CONNECTION_NAME

Database and User creation
###########################

**Via Google Cloud Web Console**

Navigate to the Databases tab for your CloudSQL instance in the Google Cloud web console and click the `CREATE DATABASE` button to create a new database:
https://console.cloud.google.com/sql/instances/instance-name/databases?project=project-name (replace instance-name and project-name).

Navigate to the Users tab for your CloudSQL instance in the Google Cloud web console and click the `ADD USER ACCOUNT` button to create a new user:
https://console.cloud.google.com/sql/instances/instance-name/users?project=project-name (replace instance-name and project-name).

You may want to create two (or more) users:

 (1) a (non-postgres) DBA account for the person setting up to use with a password they manage
 (2) a simpleschema "owner" account with full privileges
 (3) one or more additional users with limited privileges (e.g. read only)

WARNING: Database users created from the Google Cloud web console with "Built-in" authentication method will automatically get the `cloudsqlsuperuser` role. See below for revoking this.

**Via Cloud SQL Proxy**

With the Cloud SQL Proxy running, connect to the CloudSQL instance as a user with the `cloudsqlsuperuser` role. Example using the port specified in the example command above:

.. code-block:: bash

    psql -h localhost -p 3247 -U postgres

Run your `CREATE DATABASE` and `CREATE USER` SQL commands as usual.

.. code-block:: sql

    CREATE USER simpleschema_owner WITH ENCRYPTED PASSWORD 'example_password';
    CREATE USER example_user WITH ENCRYPTED PASSWORD 'example_password';
    CREATE DATABASE example_db WITH OWNER simpleschema_owner;
    REVOKE ALL ON DATABASE example_db FROM example_user;

Grant and Adjust Roles
########################

With the Cloud SQL Proxy running, connect to the CloudSQL instance as a user with the `cloudsqlsuperuser` role. Example,
if we created an `sadba` account and the `example_db` database for simpleschema and are using the port specified in the
example command above:

.. code-block:: bash

    psql -h localhost -p 3247 -U sadba -d example_db

For each non-DBA accounts you created, revoke the `cloudsqlsuperuser` role.

.. code-block:: sql

    REVOKE cloudsqlsuperuser FROM example_user;

For each database you do not want the simpleschema user(s) connecting to, ensure that `CONNECT` is revoked from
the special `public` role.

.. code-block:: sql

    REVOKE CONNECT ON DATABASE databasename FROM public;

For each new user you don't want to have access, also revoke all privileges from each database.

.. code-block:: sql

    REVOKE ALL ON DATABASE databasename FROM example_user;

Then add your grants as usual.

.. code-block:: sql

    REVOKE ALL ON DATABASE example_db FROM example_user;
    GRANT CONNECT ON DATABASE example_db TO example_user;
    GRANT SELECT,INSERT,DELETE,UPDATE ON ALL TABLES IN SCHEMA public TO example_user;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO example_user;
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO example_user;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO example_user;

Connecting to SimpleSchema Database in CloudSQL Instance
#########################################################

First set up the `Cloud SQL Proxy <https://cloud.google.com/sql/docs/mysql/connect-auth-proxy>`_ with the proper IAM
credentials. For automated or continuous integrations, you may want to set up `the proxy as a system service <https://gist.github.com/goodwill/a981c2912ae6a83761a624f657f34d9f>`_.

After the Cloud SQL Proxy is running, to connect to the SimpleSchema database on the same machine running the proxy:

* use `localhost` as the host
* use the port specified when setting up/running the Cloud SQL proxy
* use the database user and password set up for the simpleschema owner/user
