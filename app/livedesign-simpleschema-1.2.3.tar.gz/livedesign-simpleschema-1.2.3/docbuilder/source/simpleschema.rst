API
====

.. toctree::
   :maxdepth: 1

Models
---------

.. automodule:: models

   .. autoclass:: BaseModel
         :members: bulk_prep_and_validate_values, bulk_register, deregister, find, find_dependents, find_one, get_fields_and_columns, get_table_name, locate, prep_and_validate_values, property_model, register, register_or_update, update_entity

   .. autoclass:: ArchivableModel
      :members: archive, customer_keys, prep_and_validate_values, unarchive
   
   .. autoclass:: HashableModel
      :members: generate_rowhash, list_diffs, register, update_rowhash
   
   .. autoclass:: DateFieldModel

   .. autoclass:: AclsMixin
      :members: get_acls
   
   .. autoclass:: PropertyModel
      :members: prep_and_validate_values, register

   .. autoclass:: ObservationModel
      :members: prep_and_validate_values, register

   .. autoclass:: Config
      :members: register

   .. autoclass:: Source
      :members: purge, register

   .. autoclass:: ETLRun

   .. autoclass:: Project
      :members: register, restrict, unrestrict, update_description
   
   .. autoclass:: Compound
      :members: prep_and_validate_values, register, register_acl, register_alias, register_lot, register_observation, register_pose, register_property, switch_primary
   
   .. autoclass:: CompoundProject
      :members: prep_and_validate_values, register

   .. autoclass:: Document
      :members: register

   .. autoclass:: Page
      :members: register
   
   .. autoclass:: Lot
      :members: bulk_register, prep_and_validate_values, project_acls, register, register_acl, register_observation, register_property
   
   .. autoclass:: LotProject
      :members: register
   
   .. autoclass:: Assay
      :members: bulk_register, prep_and_validate_values, register, register_metadata

   .. autoclass:: Experiment
      :members: bulk_prep_and_validate_values, bulk_register, register, register_metadata
   
   .. autoclass:: CompoundProperty
      :members: register
      
   .. autoclass:: LotProperty
      :members: register

   .. autoclass:: LotObservation
      :members: project_acls, register_acl, register_metadata, register

   .. autoclass:: LotObservationProject
      :members: register

   .. autoclass:: CompoundObservation
      :members: project_acls, register_acl, register_metadata, register

   .. autoclass:: CompoundObservationProject
      :members: register

   .. autoclass:: File
      :members: prep_and_validate_values, register

   .. autoclass:: GenericEntity
      :members: prep_and_validate_values, register, register_acl, register_alias, register_metadata, register_observation, register_pose, register_property

   .. autoclass:: GenericEntityProject
      :members: register
   
   .. autoclass:: EntityAlias
      :members: prep_and_validate_values, register
   
   .. autoclass:: GenericEntityLot
      :members: bulk_register, prep_and_validate_values, project_acls, register, register_acl, register_observation, register_property

   .. autoclass:: GenericEntityLotProject
      :members: register

   .. autoclass:: GenericEntityProperty
      :members: register

   .. autoclass:: GenericEntityObservation
      :members: register_acl, register_metadata, register

   .. autoclass:: GenericEntityObservationProject
      :members: register

   .. autoclass:: GenericEntityLotProperty
      :members: register

   .. autoclass:: GenericEntityLotObservation
      :members: register_acl, register_metadata, register

   .. autoclass:: GenericEntityLotObservationProject
      :members: register
   
   .. autoclass:: Structure
      :members: prep_and_validate_values, register
   
   .. autoclass:: Pose
      :members: prep_and_validate_values, register_observation, register
   
   .. autoclass:: PoseObservation
      :members: register_acl, register_metadata, register

   .. autoclass:: PoseObservationProject
      :members: register

   .. autoclass:: EntityMetadata
      :members: prep_and_validate_values, register
   
   .. autoclass:: EntityMetadataValue
      :members: bulk_register, get_value_type, prep_and_validate_values, register
   
   .. autoclass:: Metadata
      :members: bulk_register, prep_and_validate_values, register

   .. autoclass:: AssayMetadataValue
      :members: bulk_register, prep_and_validate_values, register
   
   .. autoclass:: ExperimentMetadataValue
      :members: bulk_register, prep_and_validate_values, register
   
   .. autoclass:: ObservationMetadataValue
      :members: bulk_register, prep_and_validate_values, register
   
   .. autoclass:: GenericEntityLink
      :members: register
   
   .. autoclass:: EntityRelationshipParent
      :members: register

   .. autoclass:: EntityRelationshipChild
      :members: bulk_register, register
   
   .. autoclass:: EntityRelationshipMetadata
      :members: register
   
Schemas
----------

.. automodule:: schemas
   :members:

Utilities
------------

.. automodule:: utils
   :members:

