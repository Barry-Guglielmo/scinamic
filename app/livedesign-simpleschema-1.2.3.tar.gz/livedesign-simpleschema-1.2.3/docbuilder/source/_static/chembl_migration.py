import asyncio
import psycopg2 as pg
import paramiko,json,time,sys
from sshtunnel import SSHTunnelForwarder
from datetime import datetime
from simpleschema.schemas import SimpleSchema
from simpleschema.models import *
from simpleschema.utils import try_cast_as_float

class ChEMBLRegister:
    def __init__(self,host,port,user,password,database,remote=False,ssh_address=None,ssh_user=None, private_key_path=None,pkey_pass=None):
        if remote:
            pkey = paramiko.RSAKey.from_private_key_file(private_key_path,password=pkey_pass)
            self.ssh_tunnel = SSHTunnelForwarder(
                (ssh_address),
                ssh_username=ssh_user,
                ssh_pkey=pkey,
                ssh_private_key_password=pkey_pass,
                remote_bind_address=(host,port),
                local_bind_address=(host,port)
            )
            self.ssh_tunnel.start()
        self.conn = pg.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database
        )
        self.cur = self.conn.cursor()
        self.ss = SimpleSchema(database,user,password)
        self.acronyms = {
            "mw":"molecular weight",
            "hba":"Hydrogen bond acceptor",
            "hbd":"Hydrogen bond donor",
            "psa":"polar surface area",
            "rtb":"Rotatable bonds",
            "ro3":"rule of three",
            "apka":"acidic pKa",
            "bpka":"basic pKa",
            "mwt":"molecular weight",
            "qed":"quantitave estimation of drug-likeness",
            "ro5":"rule of five"
        }

    def deregister_all(self):
        clear_time = time.time()
        print("Clearing tables...")
        tables = self.ss.all_tables
        for table in tables:
            print(f"Clearing table {table.get_table_name()}")
            for elem in table:
                elem.deregister()
        print(f"Everything cleared: {time.time() - clear_time}")
    def clear_tables(self):
        self.ss.clear_all()
    def get_assay_type(self,str):
        if str=='B':
            return "Binding"
        elif str=='F':
            return "Functional"
        elif str=='A':
            return "ADMET"
        elif str=='T':
            return "Toxicity"
        elif str=='P':
            return "Physiochemical"
        elif str=='U':
            return "Unclassified"
        else:
            return "NA"
    def close_connection(self):
        self.conn.close()
        self.ssh_tunnel.close()
    def update_all_rowhash(self):
        start_time = time.time()
        print("Updating rowhashes")
        for table in self.ss.all_tables:
            if issubclass(table, HashableModel):
                print(f"Rowhashing table{table}")
                table_time=time.time()
                for x in table.select():
                    if(isinstance(x.rowhash,type(None))):
                        x.update_rowhash()
                print(f"Table {table} finished: {time.time()-table_time}")
        print(f"Update rowhash complete {time.time()-start_time}")

    def update_rowhash(table):
        if issubclass(table,HashableModel):
            for x in table.select():
                if(isinstance(x.rowhash,type(None))):
                    x.update_rowhash()

    def batch_prop_list(self,prop_list,query,compound=False,generic=False):
        '''
        The first column in the query needs to be either compound_id or genericentity_id.
        Everything after that should be props.
        '''
        props=",".join(prop_list)
        self.cur.execute(query)
        properties=[]
        if compound and generic:
            raise Exception("Cannot be both Compound and Genericentity")
        if not compound and not generic:
            raise Exception("Needs to be either Compound or genericentity")
        if compound:
            key = "compound_id"
        if generic:
            key = "generic_entity_id"
        for row in self.cur.fetchall():
            i=1
            for prop in prop_list:
                value = row[i]
                if value is not None:
                    prop = self.format_text(prop)
                    properties.append({key:row[0],"key":prop})
                    value_up = self.num_text_val(value)
                    properties[-1].update(value_up)
                i+=1
        return properties

    def remove_acro(self,text):
        string=text
        for ac in self.acronyms.keys():
            if ac in text:
                index = text.index(ac)
                string = text[:index]+self.acronyms[ac]+text[index+len(ac):]
                text = string
        return string

    def format_text(self,text,acro=True):
        if acro:
            text = self.remove_acro(text)
        temp = text.replace("_"," ")
        temp = temp.capitalize()
        text_list = list(temp)
        for i in range(len(text_list)):
            if text_list[i] == " ":
                if i+1<len(text_list):
                    char = text_list[i+1].upper()
                    text_list[i+1] = char
        newtext = "".join(text_list)
        newtext.replace("_"," ")
        return newtext

    def list_num_text_fix(self,list_dict):
        for i in range(len(list_dict)):
            value = list_dict[i].pop('value',None)
            value_kwargs = {"num_value":None,"text_value":None}
            if value is not None:
                num_val = try_cast_as_float(value)
                if num_val is not None:
                    value_kwargs["num_value"]=num_val
                else:
                    value_kwargs["text_value"]=value
            list_dict[i].update(value_kwargs)
        return list_dict
    def num_text_val(self,value):
        if value is None:
            value_kwargs = {"num_value":None,"text_value":None}
            return value_kwargs
        if isinstance(value,str):
            value_kwargs = {"text_value":value,"num_value":None}
        else:
            value_kwargs = {"num_value":value,"text_value":None}
        return value_kwargs

    def register_project(self):
        self.cur.execute("select key from public.project")
        rows = self.cur.fetchall()
        exists = False
        if len(rows)>0:
            for row in rows:
                if row == "ChEMBL":
                    exists=True
        if not exists:
            Project.register(key="ChEMBL", is_restricted=0)

    def register_entity_project(self,dict_list,entityTable,projectTable,elemType,primary=True):
        project_list = []
        project_id = Project.get(key="ChEMBL").get_id()
        for elem in dict_list:
            elem_id = entityTable.get(corporate_id=elem["corporate_id"]).get_id()
            if primary:
                project_list.append({elemType:elem_id,"project_id":project_id,"primary":True})
            else:
                project_list.append({elemType:elem_id,"project_id":project_id})
        projectTable.bulk_register(project_list)
    def register_observation_project(self,dict_list, obsTable,projectTable,obsType):
        project_list=[]
        project_id = Project.get(key="ChEMBL").get_id()
        for elem in dict_list:
            elem_id = obsTable.get(customer_key=elem["customer_key"]).get_id()
            project_list.append({obsType:elem_id,"project_id":project_id})
        projectTable.bulk_register(project_list)
  
    def batch_register_compounds(self,batch,limit=None):
        start_time = time.time()
        print("Compound registration started")
        query_core="from chembl.molecule_dictionary md join chembl.compound_properties cp on cp.molregno = md.molregno join chembl.compound_structures cs on cp.molregno=cs.molregno where cp.mw_freebase<1000 and md.chembl_id not in (select corporate_id from compound)"
        len_query =f"select count(*) {query_core}"
        comp_query=f"select md.chembl_id, cs.molfile {query_core} limit {batch}"
        self.cur.execute(len_query)
        length = self.cur.fetchall()[0][0]
        if limit is not None:
            self.cur.execute("select count(*) from compound")
            count = self.cur.fetchall()[0][0]
            if count>=limit:
                length = 0
        while length>0:
            comp_list=[]
            self.cur.execute(comp_query)
            for row in self.cur.fetchall():
                corp_id = row[0]
                mol_file = row[1]
                comp_list.append({"corporate_id":corp_id,"mol_file":mol_file,"person":"Chembl"})
            Compound.bulk_register(comp_list)
            self.register_entity_project(comp_list,Compound,CompoundProject,"compound_id")
            #update_rowhash(Compound)
            self.cur.execute(len_query)
            length = self.cur.fetchall()[0][0]
            if limit is not None:
                self.cur.execute("select count(*) from compound")
                count = self.cur.fetchall()[0][0]
                if count>=limit:
                    length = 0
        print(f"Compound registration finished: {time.time()-start_time}")

    def batch_register_generic_entities(self,batch,limit=None):
        start_time = time.time()
        project_id = Project.get(key="ChEMBL").get_id()
        print("Generic entities registration started")
        query_cores=[" from chembl.molecule_dictionary md join chembl.compound_properties cp on cp.molregno = md.molregno join chembl.compound_structures cs on cp.molregno = cs.molregno where cp.mw_freebase>=1000 and md.chembl_id not in (select corporate_id from genericentity) and md.chembl_id not in (select corporate_id from compound)",
        " from chembl.bio_component_sequences bcs join chembl.biotherapeutic_components bc on bcs.component_id = bc.component_id join chembl.molecule_dictionary md on bc.molregno = md.molregno where md.chembl_id not in (select corporate_id from genericentity) and md.chembl_id not in (select corporate_id from compound) and md.molregno not in (select molregno from chembl.compound_structures cs) group by md.chembl_id, bcs.sequence ",
        " from chembl.component_sequences cs join chembl.target_components tc on cs.component_id = tc.component_id join chembl.target_dictionary td on tc.tid = td.tid where td.target_type = 'SINGLE PROTEIN' and td.chembl_id not in (select corporate_id from genericentity) and td.chembl_id not in (select corporate_id from compound) group by td.chembl_id, cs.sequence" 
        ]
        props=[
            "md.chembl_id, cs.molfile",
            "md.chembl_id, bcs.sequence",
            "td.chembl_id, cs.sequence"
        ]
        for i in range(len(query_cores)):
            self.cur.execute(f"select count(*) {query_cores[i]}")
            length = self.cur.fetchall()[0][0]
            if limit is not None:
                self.cur.execute("select count(*) from genericentity")
                count = self.cur.fetchall()[0][0]
                if count>=limit:
                    length = 0
            while length>0:
                self.cur.execute(f"select {props[i]+query_cores[i]} limit {batch}")
                file_list=[]
                gen_list=[]
                corp_ids = []
                count = 1
                for row in self.cur.fetchall():
                    if row[0] not in corp_ids:
                        corp_id = row[0]
                        corp_ids.append(corp_id)
                        count = 1
                    elif row[0] in corp_ids:
                        corp_id = row[0] + '-' + str(count)
                        corp_ids.append(corp_id)
                        count +=1
                    seq = row[1]
                    g_corps = [sub['corporate_id'] for sub in gen_list]
                    if corp_id not in g_corps:
                        file_list.append({"key":corp_id,"blob":seq.encode('utf-8'),"project_id":project_id})
                        gen_list.append({"corporate_id":corp_id,"file":"temp","person":"Chembl"})
                File.bulk_register(file_list)
                for l in range(len(gen_list)):
                    gen_list[l]["file"]=File.get(key=gen_list[l]["corporate_id"])
                GenericEntity.bulk_register(gen_list)
                self.register_entity_project(gen_list,GenericEntity,GenericEntityProject,"generic_entity_id",False)
                #update_rowhash(GenericEntity)
                self.cur.execute(f"select count(*) from (select {props[i]+query_cores[i]}) q")
                length = self.cur.fetchall()[0][0]
                if limit is not None:
                    self.cur.execute("select count(*) from genericentity")
                    count = self.cur.fetchall()[0][0]
                    if count>=limit:
                        length = 0
        print(f"Files and Generic entitites are registered: {time.time()-start_time}")

    def batch_register_properties(self,batch):
        start_time = time.time()
        print("Properties registration begins")
        list_of_properties=[
            ["mw_freebase","full_molformula","molecular_species","alogp","hba","hbd","psa","rtb","ro3_pass","cx_most_apka","cx_most_bpka","cx_logp","cx_logd","full_mwt","aromatic_rings","heavy_atoms","qed_weighted","mw_monoisotopic","hba_lipinski","hbd_lipinski","num_lipinski_ro5_violations"],
            ["accession","pref_name","organism"],
            ["component_type","description","organism","tax_id"]
        ]
        self.batch_register_molecule_properties(batch,list_of_properties,"compound")
        self.batch_register_molecule_properties(batch,list_of_properties,"genericentity")
        #batch_register_generic_properties(limit,list_of_properties,limit)
        print(f"Properties are registered: {time.time()-start_time}")

    def batch_register_molecule_properties(self,batch,list_of_props,molecule_type):
        start_time = time.time()
        table_name = molecule_type+"property"
        MT_id = molecule_type
        print(f"{table_name} registration started")
        comp = True
        generic = False
        if molecule_type=="genericentity":
            MT_id ="generic_entity"
            comp = False
            generic = True
        propertyTable=None
        for table in self.ss.property_tables:
            if table.get_table_name()==table_name:
                propertyTable=table
        if propertyTable is None:
            print(f"Unable to find table with name: {table_name}")
            
        core_queries=[
            f"from chembl.molecule_dictionary md join {molecule_type} c on md.chembl_id = c.corporate_id join chembl.compound_properties cp on cp.molregno = md.molregno where c.id not in (select distinct {MT_id}_id from {table_name})",
            f"from chembl.component_sequences cs join chembl.target_components tc on cs.component_id = tc.component_id join chembl.target_dictionary td on tc.tid = td.tid join {molecule_type} c on c.corporate_id = td.chembl_id where td.target_type='SINGLE PROTEIN' and c.id not in (select distinct {MT_id}_id from {table_name})",
            f"from chembl.bio_component_sequences bcs join chembl.biotherapeutic_components bc on bcs.component_id = bc.component_id join chembl.molecule_dictionary md on bc.molregno = md.molregno join {molecule_type} c on md.chembl_id = c.corporate_id where md.molregno not in (select cs.molregno from chembl.compound_structures cs) and c.id not in (select distinct {MT_id}_id from {table_name})"
        ]
        prop_queries=[f"{','.join(list_of_props[0])}",
                    "cs.accession, td.pref_name,td.organism",
                    "bcs.component_type,bcs.description, bcs.organism, bcs.tax_id"]
        
        for i in range(len(core_queries)):
            self.cur.execute(f"select count(*) {core_queries[i]}")
            length = self.cur.fetchall()[0][0]
            query = f"select c.id, {prop_queries[i]} {core_queries[i]} limit {batch}"
            while length>0:
                properties = self.batch_prop_list(list_of_props[i],query,compound=comp,generic=generic)
                propertyTable.bulk_register(properties)
                #update_rowhash(CompoundProperty)
                self.cur.execute(f"select count(*) {core_queries[i]}")
                length = self.cur.fetchall()[0][0]
        print(f"{table_name} registered: {time.time()-start_time}")

    def batch_register_assays(self,batch,limit=None):
        start_time = time.time()
        print("Assay registration started")
        core_query = "from chembl.assays a join chembl.target_dictionary td on a.tid = td.tid where a.assay_id not in (select customer_key::integer from assay)"
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]
        if limit is not None:
            self.cur.execute(f"select count(*) from assay")
            count = self.cur.fetchall()[0][0]
            if count>=limit:
                length = 0
        while length>0:
            assay_list=[]
            self.cur.execute(f"select a.assay_id, td.pref_name, a.assay_type, a.chembl_id {core_query} limit {batch}")
            for row in self.cur.fetchall():
                ckey = row[0]
                key = row[1]+" "+self.get_assay_type(row[2])
                version = row[3]
                assay_list.append({"customer_key":ckey,"key":key,"version":version})
            Assay.bulk_register(assay_list)
            #update_rowhash(Assay)
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]
            if limit is not None:
                self.cur.execute(f"select count(*) from assay")
                count = self.cur.fetchall()[0][0]
                if count>=limit:
                    length = 0
        print(f"Assays registered: {time.time()-start_time}")

    def batch_register_experiments(self,batch, limit=None):
        '''
        Register experiments. In order to avoid duplicates in the first query, assay_id is gotten later using activity_id and the first one that is returned is used.
        One experiment can have many assays and because of on conflict constraints, duplicate rows are not an option (I think)
        '''
        start_time = time.time()
        print("Experiment registration started")
        f = '%Y-%m-%d %H:%M:%S'
        core_query = "from chembl.activities act join chembl.docs d on act.doc_id = d.doc_id where act.assay_id in (select customer_key::integer from assay where assay.id not in (select assay_id from experiment)) and d.chembl_id not in (select key from experiment)"
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]
        if limit is not None:
            self.cur.execute(f"select count(*) from experiment")
            count = self.cur.fetchall()[0][0]
            if count>=limit:
                length = 0
        while length>0:
            ckeys=[]
            experiment_list = []
            self.cur.execute(f"select distinct act.doc_id, d.chembl_id, act.activity_id, d.year {core_query} limit {batch}")
            for row in self.cur.fetchall():
                ckey=row[0]
                key=row[1]
                year=row[3]
                if year is None:
                    date = datetime.now()
                else:
                    time_stamp=time.mktime(datetime.strptime(f"{str(year)}-01-01 0:0:0",f).timetuple())
                    date = datetime.fromtimestamp(time_stamp)
                self.cur.execute(f"select id from assay a where a.customer_key::integer = (select assay_id from chembl.activities act where act.activity_id ={row[2]})")
                assay_key = self.cur.fetchall()[0][0]
                if ckey in ckeys:
                    continue
                experiment_list.append({"customer_key":ckey,"key":key,"assay":Assay.get(assay_key),"created_at":date})
                ckeys.append(ckey)
            Experiment.bulk_register(experiment_list)
            #update_rowhash(Experiment)
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]
            if limit is not None:
                self.cur.execute(f"select count(*) from experiment")
                count = self.cur.fetchall()[0][0]
                if count>=limit:
                    length = 0
        print(f"Experiments registered: {time.time()-start_time}")

    def batch_register_observations(self,batch):
        start_time = time.time()
        print("Observation registration started")
        query_columns=["select distinct act.activity_id, c.id, act.standard_relation,act.standard_value, act.standard_units, act.standard_type, a.id, e.id","select distinct act.activity_id, g.id, act.standard_relation, act.standard_value, act.standard_units, act.standard_type, a.id, e.id"]
        query_cores=["from chembl.activities act join chembl.molecule_dictionary md on act.molregno = md.molregno join assay a on act.assay_id = a.customer_key::integer join experiment e on e.assay_id = a.id join compound c on md.chembl_id = c.corporate_id where act.standard_value is not null and act.activity_id not in (select customer_key::integer from compoundobservation)",
        "from chembl.activities act join chembl.molecule_dictionary md on act.molregno = md.molregno join assay a on act.assay_id = a.customer_key::integer join experiment e on e.assay_id = a.id join genericentity g on md.chembl_id = g.corporate_id where act.standard_value is not null and act.activity_id not in (select customer_key::integer from genericentityobservation)"
        ]
        tables =[CompoundObservation,GenericEntityObservation]
        project_tables=[CompoundObservationProject,GenericEntityObservationProject]
        obs_names = ["compound_observation_id","generic_entity_observation_id"]
        for i in range(len(query_cores)):
            index_time = time.time()
            self.cur.execute(f"select count(*) {query_cores[i]}")
            query=f"{query_columns[i]} {query_cores[i]} limit {batch}"
            length = self.cur.fetchall()[0][0]
            while length>0:
                if(i<1):
                    obs_list = self.get_observation_list(query,compound=True)
                else:
                    obs_list= self.get_observation_list(query,generic=True)
                tables[i].bulk_register(obs_list)
                self.register_observation_project(obs_list,tables[i],project_tables[i],obs_names[i])
                #update_rowhash(tables[i])
                self.cur.execute(f"select count(*) {query_cores[i]}")
                length = self.cur.fetchall()[0][0]
            print(f"Index {i} finished: {time.time()-index_time}")
        print(f"Observations registered: {time.time()-start_time}")
        
    def get_observation_list(self,query,compound=False, generic=False):
        items = []
        self.cur.execute(query)
        if (compound and generic) or (not compound and not generic):
            raise Exception("Needs to be either compound or generic. Cannot be both or neither.")
        if compound:
            key = "compound_id"
        if generic:
            key="generic_entity_id"
        for row in self.cur.fetchall():
            if row[0] in [sub["customer_key"] for sub in items]:
                continue
            items.append({
                "customer_key":row[0],
                key:row[1],
                "value_operator":row[2],
                "num_value":row[3],
                "unit":row[4],
                "endpoint":row[5],
                "assay":Assay.get(row[6]),
                "experiment":Experiment.get(row[7])
            })
        return items

    def batch_register_metadata(self, batch):
        start_time = time.time()
        print("Metadata registration started")
        
        keylists = [["Test Type","Category","Organism","Strain","Tissue","Cell Type","Target ID"],
                ["DOI","Pubmed ID","Patent ID"]]
        key_dicts = []
        
        for i in range(len(keylists)):
            assay_level = True
            if i != 0:
                assay_level = False
            for k in keylists[i]:            
                key_dicts.append({"key":k, "assay_level":assay_level})      
        
        Metadata.bulk_register(key_dicts)

        tables = [AssayMetadataValue, ExperimentMetadataValue]
        core_queries = [f"from assay a join chembl.assays ca on a.customer_key::integer = ca.assay_id join chembl.target_dictionary td on ca.tid = td.tid where a.id not in (select assay_id from assaymetadatavalue)",
                        f"from experiment e join chembl.docs d on e.customer_key::integer = d.doc_id where e.id not in (select experiment_id from experimentmetadatavalue) and (doi is not null or pubmed_id is not null or patent_id is not null)"]
        key_queries=[
            f"select a.id, ca.assay_test_type, ca.assay_category, ca.assay_organism, ca.assay_strain, ca.assay_tissue, ca.assay_cell_type, td.chembl_id",
                    f"select e.id, d.doi, d.pubmed_id, d.patent_id"]
        
        for i in range(len(tables)):
                print('Begin ' + str(tables[i]) + ' registration')
                self.cur.execute(f"select count(*) {core_queries[i]}")
                length = self.cur.fetchall()[0][0]

                while length>0:
                        list_dict=[]
                        self.cur.execute(f"{key_queries[i]} {core_queries[i]} limit {batch}")
        
                        for row in self.cur.fetchall():
                                row_id = row[0]
                                if i == 0:
                                        for key in range(len(row) - 1):
                                                list_dict.append({"assay_id":row_id, "key":keylists[i][key], "text_value":str(row[key + 1])})
                                elif i == 1:
                                        for key in range(len(row) - 1):
                                                list_dict.append({"experiment_id":row_id, "key":keylists[i][key], "text_value":str(row[key + 1]), "assay_level":False})
                        
                        tables[i].bulk_register(list_dict)
                        self.cur.execute(f"select count(*) {core_queries[i]}")
                        length = self.cur.fetchall()[0][0]
                
                print(str(tables[i]) + ' registration complete')

        print(f"Metadata registration finished: {time.time()-start_time}")
   
    def batch_register(self,batch_size=10000,limit=None):
        start = time.time()
        self.register_project()
        self.batch_register_compounds(batch_size,limit)
        self.batch_register_generic_entities(batch_size,limit)
        self.batch_register_properties(batch_size)
        self.batch_register_assays(batch_size,limit)
        self.batch_register_experiments(batch_size,limit)
        self.batch_register_observations(batch_size)
        self.batch_register_metadata(batch_size)
        print(f"Process finished: {time.time()-start}")
