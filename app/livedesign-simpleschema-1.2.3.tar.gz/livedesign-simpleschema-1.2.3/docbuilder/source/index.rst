SimpleSchema Documentation
===========================

.. toctree::
    :maxdepth: 3
    
    readme
    simpleschema
    chembl

