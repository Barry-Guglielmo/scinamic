Example ETL - ChEMBL
========================================

This page provides an example ETL for data in an external database to a SimpleSchema database. 
The chembl_migration script can be used as a guide for how to employ the SimpleSchema API to migrate source data to SimpleSchema tables, so that it can be processed by DI and 
viewed/analyzed in LiveDesign. 

For the purposes of this example, the ChEMBL database will serve as the external data source. 

Set up ChEMBL database
-----------------------

1. Create a postgres database, then download the most recent `ChEMBL postgresql dump file <https://ftp.ebi.ac.uk/pub/databases/chembl/ChEMBLdb/latest>`_ from their website.

  .. code-block:: bash
    
      psql -h localhost -p 3247 -U postgres -c "CREATE DATABASE target_database"

  Once you have the tar file in the directory you want it to be, run the following command to expand the tar file:

  .. code-block:: bash

      tar xzf chembl_33_postgresql.tar.gz

  You should now have a directory titled chembl_33. Inside that directory will be a README and a dump file. Feel free to take a look in the README as it contains information about installation.  
  Run the following to restore the dmp file to the target database:

  .. code-block:: bash

      pg_restore --no-owner -h host -p port -U user -d target_database chembl_33_postgresql.dmp

  Note: if the source data already exists in a postgres database, this step would be skipped.

2. Once the database has been restored, create a new schema called chembl and move the tables over by running the following in a **postgresql environment**:

  .. code-block:: bash

      create schema chembl;
      DO LANGUAGE plpgsql
      $body$
      DECLARE
        l_old_schema NAME = 'public';
        l_new_schema NAME = 'chembl';
        l_sql TEXT;
      BEGIN
        FOR l_sql IN
          SELECT
              format('ALTER TABLE %I.%I SET SCHEMA %I', n.nspname, c.relname, l_new_schema)
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE
              n.nspname = l_old_schema AND
              c.relkind = 'r'
        LOOP
          RAISE NOTICE 'appliying %', l_sql;
          EXECUTE l_sql;
        END LOOP;
      END;
      $body$;

Set up SimpleSchema environment
--------------------------------

1. Clone the livedesign-simpleschema git repository and checkout branch SADEV_2090. Create a virtual environment in that directory:

  .. code-block:: bash

      virtualenv -p 'which python3' venv

2. Activate the venv and install SimpleSchema:

  .. code-block:: bash

      source venv/bin/activate
      pip3 install -e livedesign-simpleschema/

3. Run the create tables command to set up the SimpleSchema tables:

  .. code-block:: bash

      create_tables --host host --port port --user user --password password database

Migrate the data
-----------------

Now that the database has been properly set up, data can be migrated from ChEMBL into SimpleSchema. 

1. Download the attached :download:`chembl_migration script </_static/chembl_migration.py>`.

2. The script contains two classes: ChEMBLRegister and ChEMBLRegisterAsync. Initialize an object of one of these classes with the specifics of the target database.

  Note: for the purposes of this example, we will deal exclusively with ChEMBLRegister. To use the ChEMBLRegister class, the script must run locally relative to the target database.

  .. code-block:: python

      from chembl_migration import ChEMBLRegister
      chemblRegister = ChEMBLRegister(host, port, user, password, database)

3. Once the class object has been initialized, call the batch_register() method:

  .. code-block:: python
    
      chemblRegister.batch_register(batch_size, limit)

  This method can take two parameters, `batch_size`` and `limit`. The `batch_size` is required and is used to determine the number of rows to be registered at a time. The default batch_size is 10000, but this can be increased or decreased according to the available memory. 
  The `limit` parameter is optional and is primarily for testing purposes as it limits the number of compounds, generic entities, assays and experiments that can be registered. Properties, observations, and metadata are not limited to ensure that all the properties of a registered compound or generic entity are also registered. 

  Note: depending on the size of the source database and compute power, data migration could take several hours if not days. 
  Be sure to call `batch_register` in a manner such that the process would not be interupped by continued use of the machine on which it is running, or changes in network connectivity.

Using SimpleSchema registration methods
########################################

The following code has been copied from the chembl_migration script, but has added comments to highlight the use of the SimpleSchema methods. More details about these methods
can be found in the `SimpleSchema API <simpleschema.html#api>`_. Some of the code in the script, which is helpful for troubleshooting but is not required 
for the registrations to be executed succesfully, has been removed below.

.. code-block:: python

    #Register projects
    
    def register_project(self):
        
        self.cur.execute("select key from public.project")
        rows = self.cur.fetchall()
        exists = False
        
        if len(rows) > 0:
            for row in rows:
                if row == "ChEMBL":
                    exists=True
        
        if not exists:
            #SimpleSchema Project.register()
            Project.register(key="ChEMBL", is_restricted=0)

    
    #Register the project of a generic entity
    
    def register_entity_project(self, dict_list, entityTable, projectTable, elemType, primary=True):
        
        project_list = []
        project_id = Project.get(key="ChEMBL").get_id()
        
        for elem in dict_list:
            elem_id = entityTable.get(corporate_id=elem["corporate_id"]).get_id()
            
            if primary:
                project_list.append({elemType: elem_id, "project_id": project_id, "primary": True})
            
            else:
                project_list.append({elemType: elem_id, "project_id": project_id})
        
        #SimpleSchema TableModel.bulk_register() method
        projectTable.bulk_register(project_list)
    
    
    #Register the project of an observation
    
    def register_observation_project(self, dict_list, obsTable, projectTable, obsType):
          
        project_list=[]
        project_id = Project.get(key="ChEMBL").get_id()
        
        for elem in dict_list:
            elem_id = obsTable.get(customer_key=elem["customer_key"]).get_id()
            project_list.append({obsType: elem_id, "project_id": project_id})
        
        #SimpleSchema TableModel.bulk_register() method
        projectTable.bulk_register(project_list)

    
    #Register compounds
    
    def batch_register_compounds(self, batch, limit=None):
          
        query_core = ("from chembl.molecule_dictionary md " 
                      "join chembl.compound_properties cp " 
                      "on cp.molregno = md.molregno " 
                      "join chembl.compound_structures cs " 
                      "on cp.molregno = cs.molregno " 
                      "where cp.mw_freebase < 1000 " 
                      "and md.chembl_id not in (select corporate_id from compound)")
        
        len_query = f"select count(*) {query_core}"
        
        comp_query = f"select md.chembl_id, cs.molfile {query_core} limit {batch}"
        
        self.cur.execute(len_query)
        length = self.cur.fetchall()[0][0]
        
        if limit is not None:
            self.cur.execute("select count(*) from compound")
            count = self.cur.fetchall()[0][0]
            
            if count >= limit:
                length = 0
        
        while length > 0:
            comp_list = []
            self.cur.execute(comp_query)
            
            for row in self.cur.fetchall():
                corp_id = row[0]
                mol_file = row[1]
                comp_list.append({"corporate_id": corp_id, "mol_file": mol_file, "person": "Chembl"})
            
            #SimpleSchema Compound.bulk_register()
            Compound.bulk_register(comp_list)
            self.register_entity_project(comp_list, Compound, CompoundProject, "compound_id")
            
            self.cur.execute(len_query)
            length = self.cur.fetchall()[0][0]
            
            if limit is not None:
                self.cur.execute("select count(*) from compound")
                count = self.cur.fetchall()[0][0]
                
                if count >= limit:
                    length = 0

    
    #Register generic entities      
    
    def batch_register_generic_entities(self, batch, limit=None):
          
        project_id = Project.get(key="ChEMBL").get_id()
        
        query_cores = [("from chembl.molecule_dictionary md " 
                        "join chembl.compound_properties cp " 
                        "on cp.molregno = md.molregno " 
                        "join chembl.compound_structures cs " 
                        "on cp.molregno = cs.molregno " 
                        "where cp.mw_freebase>=1000 " 
                        "and md.chembl_id not in (select corporate_id from genericentity) " 
                        "and md.chembl_id not in (select corporate_id from compound)"),

                      ("from chembl.bio_component_sequences bcs " 
                        "join chembl.biotherapeutic_components bc " 
                        "on bcs.component_id = bc.component_id " 
                        "join chembl.molecule_dictionary md " 
                        "on bc.molregno = md.molregno " 
                        "where md.chembl_id not in (select corporate_id from genericentity) " 
                        "and md.chembl_id not in (select corporate_id from compound) " 
                        "and md.molregno not in (select molregno from chembl.compound_structures cs) " 
                        "group by md.chembl_id, bcs.sequence"),

                      ("from chembl.component_sequences cs " 
                        "join chembl.target_components tc " 
                        "on cs.component_id = tc.component_id " 
                        "join chembl.target_dictionary td " 
                        "on tc.tid = td.tid " 
                        "where td.target_type = 'SINGLE PROTEIN' " 
                        "and td.chembl_id not in (select corporate_id from genericentity) " 
                        "and td.chembl_id not in (select corporate_id from compound) " 
                        "group by td.chembl_id, cs.sequence")]
        
        props = ["md.chembl_id, cs.molfile",
                "md.chembl_id, bcs.sequence",
                "td.chembl_id, cs.sequence"]
        
        for i in range(len(query_cores)):
            self.cur.execute(f"select count(*) {query_cores[i]}")
            length = self.cur.fetchall()[0][0]
            
            if limit is not None:
                self.cur.execute("select count(*) from genericentity")
                count = self.cur.fetchall()[0][0]
                
                if count >= limit:
                    length = 0
            
            while length > 0:
                self.cur.execute(f"select {props[i]} {query_cores[i]} limit {batch}")
                file_list = []
                gen_list = []
                corp_ids = []
                count = 1
                
                for row in self.cur.fetchall():
                    if row[0] not in corp_ids:
                        corp_id = row[0]
                        corp_ids.append(corp_id)
                        count = 1
                    
                    elif row[0] in corp_ids:
                        corp_id = row[0] + '-' + str(count)
                        corp_ids.append(corp_id)
                        count += 1
                    
                    seq = row[1]
                    g_corps = [sub['corporate_id'] for sub in gen_list]
                    
                    if corp_id not in g_corps:
                        file_list.append({"key": corp_id, "blob": seq.encode('utf-8'), "project_id": project_id})
                        gen_list.append({"corporate_id": corp_id, "file": "temp", "person": "Chembl"})
                
                #Register the generic entity files - SimpleSchema File.bulk_register()
                File.bulk_register(file_list)

                for l in range(len(gen_list)):
                    gen_list[l]["file"] = File.get(key=gen_list[l]["corporate_id"])
                
                #SimpleSchema GenericEntity.bulk_register()
                GenericEntity.bulk_register(gen_list)
                self.register_entity_project(gen_list,GenericEntity,GenericEntityProject,"generic_entity_id",False)
                
                self.cur.execute(f"select count(*) from (select {props[i]} {query_cores[i]}) q")
                length = self.cur.fetchall()[0][0]
                
                if limit is not None:
                    self.cur.execute("select count(*) from genericentity")
                    count = self.cur.fetchall()[0][0]
                    
                    if count >= limit:
                        length = 0

    
    #Register compound and generic entity properties
    
    def batch_register_molecule_properties(self, batch, list_of_props, molecule_type):
        
        table_name = molecule_type + "property"
        MT_id = molecule_type
        
        comp = True
        generic = False
        
        if molecule_type == "genericentity":
            MT_id = "generic_entity"
            comp = False
            generic = True
        
        propertyTable = None
        
        for table in self.ss.property_tables:
            
            if table.get_table_name() == table_name:
                propertyTable = table
        
        if propertyTable is None:
            print(f"Unable to find table with name: {table_name}")
            
        core_queries = [(f"from chembl.molecule_dictionary md " 
                        f"join {molecule_type} c " 
                        f"on md.chembl_id = c.corporate_id " 
                        f"join chembl.compound_properties cp " 
                        f"on cp.molregno = md.molregno " 
                        f"where c.id not in (select distinct {MT_id}_id from {table_name})"),

                        (f"from chembl.component_sequences cs " 
                        f"join chembl.target_components tc " 
                        f"on cs.component_id = tc.component_id " 
                          f"join chembl.target_dictionary td " 
                          f"on tc.tid = td.tid " 
                          f"join {molecule_type} c " 
                          f"on c.corporate_id = td.chembl_id " 
                          f"where td.target_type = 'SINGLE PROTEIN' " 
                          f"and c.id not in (select distinct {MT_id}_id from {table_name})"),

                        (f"from chembl.bio_component_sequences bcs " 
                        f"join chembl.biotherapeutic_components bc " 
                        f"on bcs.component_id = bc.component_id " 
                        f"join chembl.molecule_dictionary md " 
                        f"on bc.molregno = md.molregno " 
                        f"join {molecule_type} c " 
                        f"on md.chembl_id = c.corporate_id " 
                        f"where md.molregno not in (select cs.molregno from chembl.compound_structures cs) " 
                        f"and c.id not in (select distinct {MT_id}_id from {table_name})")]
        
        prop_queries = [f"{','.join(list_of_props[0])}",
                        f"cs.accession, td.pref_name,td.organism",
                        f"bcs.component_type,bcs.description, bcs.organism, bcs.tax_id"]
        
        for i in range(len(core_queries)):
            self.cur.execute(f"select count(*) {core_queries[i]}")
            length = self.cur.fetchall()[0][0]
            query = f"select c.id, {prop_queries[i]} {core_queries[i]} limit {batch}"
            
            while length > 0:
                properties = self.batch_prop_list(list_of_props[i], query,compound=comp, generic=generic)
                
                #SimpleSchema PropertyTableModel.bulk_register()
                propertyTable.bulk_register(properties)
                self.cur.execute(f"select count(*) {core_queries[i]}")
                length = self.cur.fetchall()[0][0]

    
    #Register assays      
    
    def batch_register_assays(self, batch, limit=None):
          
        core_query = ("from chembl.assays a " 
                      "join chembl.target_dictionary td " 
                      "on a.tid = td.tid " 
                      "where a.assay_id not in (select customer_key::integer from assay)")
        
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]
        
        if limit is not None:
            self.cur.execute(f"select count(*) from assay")
            count = self.cur.fetchall()[0][0]
            
            if count >= limit:
                length = 0
        
        while length > 0:
            assay_list = []
            self.cur.execute(f"select a.assay_id, td.pref_name, a.assay_type, a.chembl_id {core_query} limit {batch}")
            
            for row in self.cur.fetchall():
                ckey = row[0]
                key = row[1] + " " + self.get_assay_type(row[2])
                version = row[3]
                assay_list.append({"customer_key": ckey, "key": key, "version": version})

            #SimpleSchema Assay.bulk_register()
            Assay.bulk_register(assay_list)
            
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]
            
            if limit is not None:
                self.cur.execute(f"select count(*) from assay")
                count = self.cur.fetchall()[0][0]
                
                if count >= limit:
                    length = 0
    
    
    #Register experiments
    
    def batch_register_experiments(self,batch, limit=None):
       
        f = '%Y-%m-%d %H:%M:%S'
        
        core_query = ("from chembl.activities act " 
                      "join chembl.docs d " 
                      "on act.doc_id = d.doc_id " 
                      "where act.assay_id in (select customer_key::integer from assay where assay.id not in (select assay_id from experiment)) " 
                      "and d.chembl_id not in (select key from experiment)")
        
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]
        
        if limit is not None:
            self.cur.execute(f"select count(*) from experiment")
            count = self.cur.fetchall()[0][0]
            
            if count >= limit:
                length = 0
      
        while length > 0:
            ckeys = []
            experiment_list = []
            self.cur.execute(f"select distinct act.doc_id, d.chembl_id, act.activity_id, d.year {core_query} limit {batch}")
            
            for row in self.cur.fetchall():
                ckey = row[0]
                key = row[1]
                year = row[3]
                
                if year is None:
                    date = datetime.now()
                
                else:
                    time_stamp = time.mktime(datetime.strptime(f"{str(year)}-01-01 0:0:0",f).timetuple())
                    date = datetime.fromtimestamp(time_stamp)
                
                self.cur.execute(f"select id from assay a where a.customer_key::integer = (select assay_id from chembl.activities act where act.activity_id ={row[2]})")
                assay_key = self.cur.fetchall()[0][0]
                
                if ckey in ckeys:
                    continue
                
                experiment_list.append({"customer_key": ckey, "key": key, "assay": Assay.get(assay_key), "created_at": date})
                ckeys.append(ckey)
            
            #SimpleSchema Experiment.bulk_register()
            Experiment.bulk_register(experiment_list)
            
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]
            
            if limit is not None:
                self.cur.execute(f"select count(*) from experiment")
                count = self.cur.fetchall()[0][0]
                
                if count >= limit:
                    length = 0

    
    #Register compound and generic entity observations
    
    def batch_register_observations(self, batch):
          
        query_columns = ["select distinct act.activity_id, c.id, act.standard_relation, act.standard_value, act.standard_units, act.standard_type, a.id, e.id",
                        "select distinct act.activity_id, g.id, act.standard_relation, act.standard_value, act.standard_units, act.standard_type, a.id, e.id"]
        
        query_cores = [("from chembl.activities act " 
                        "join chembl.molecule_dictionary md " 
                        "on act.molregno = md.molregno " 
                        "join assay a " 
                        "on act.assay_id = a.customer_key::integer " 
                        "join experiment e " 
                        "on e.assay_id = a.id " 
                        "join compound c " 
                        "on md.chembl_id = c.corporate_id " 
                        "where act.standard_value is not null " 
                        "and act.activity_id not in (select customer_key::integer from compoundobservation)"),
                        
                        ("from chembl.activities act " 
                        "join chembl.molecule_dictionary md " 
                        "on act.molregno = md.molregno " 
                        "join assay a " 
                        "on act.assay_id = a.customer_key::integer " 
                        "join experiment e " 
                        "on e.assay_id = a.id " 
                        "join genericentity g " 
                        "on md.chembl_id = g.corporate_id " 
                        "where act.standard_value is not null " 
                        "and act.activity_id not in (select customer_key::integer from genericentityobservation)")]
        
        tables = [CompoundObservation, GenericEntityObservation]
        project_tables = [CompoundObservationProject, GenericEntityObservationProject]
        obs_names = ["compound_observation_id", "generic_entity_observation_id"]

        for i in range(len(query_cores)):
            index_time = time.time()
            self.cur.execute(f"select count(*) {query_cores[i]}")
            query = f"{query_columns[i]} {query_cores[i]} limit {batch}"
            length = self.cur.fetchall()[0][0]
            
            while length > 0:
                if i < 1:
                    obs_list = self.get_observation_list(query, compound=True)
                
                else:
                    obs_list = self.get_observation_list(query, generic=True)

                #SimpleSchema ObservationTableModel.bulk_register()
                tables[i].bulk_register(obs_list)
                self.register_observation_project(obs_list, tables[i], project_tables[i], obs_names[i])
                
                self.cur.execute(f"select count(*) {query_cores[i]}")
                length = self.cur.fetchall()[0][0]

    
    #Register assay metadata
    
    def batch_register_assay_metadata(self, batch):
        
        keylist = ["Test Type", "Category", "Organism", "Strain", "Tissue", "Cell Type", "Target ID"]
        key_dict = []
        
        for k in keylist:
            key_dict.append({"key": k, "assay_level": True})      
        
        #SimpleSchema Metadata.bulk_register()
        metadatakeys = Metadata.bulk_register(key_dict)
        keymap = {metadata.key: metadata for metadata in metadatakeys}

        core_query = (f"from assay a " 
                      "join chembl.assays ca " 
                      "on a.customer_key::integer = ca.assay_id " 
                      "join chembl.target_dictionary td " 
                      "on ca.tid = td.tid " 
                      "where a.id not in (select assay_id from assaymetadatavalue)")
        
        key_query = f"select a.id, ca.assay_test_type, ca.assay_category, ca.assay_organism, ca.assay_strain, ca.assay_tissue, ca.assay_cell_type, td.chembl_id"
        
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]
        
        while length > 0:
            list_dict=[]
            self.cur.execute(f"{key_query} {core_query} limit {batch}")
        
            for row in self.cur.fetchall():                
                for key_idx in range(len(row) - 1):
                    key_str = keylist[key_idx]
                    list_dict.append({"assay_id": row[0], "key": keymap[key_str], "text_value": str(row[key_idx + 1])})

            #SimpleSchema AssayMetadataValue.bulk_register()                    
            AssayMetadataValue.bulk_register(list_dict)
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]

    
    #Register experiment metadata
    
    def batch_register_experiment_metadata(self, batch):
        
        keylist = ["DOI", "Pubmed ID", "Patent ID"]
        key_dict = []
        
        for k in keylist:
            key_dict.append({"key": k, "assay_level": False})      
        
        #SimpleSchema Metadata.bulk_register()
        metadatakeys = Metadata.bulk_register(key_dict)
        keymap = {metadata.key: metadata for metadata in metadatakeys}
        
        core_query = (f"from experiment e " 
                      "join chembl.docs d " 
                      "on e.key = d.chembl_id " 
                      "where e.id not in (select experiment_id from experimentmetadatavalue) " 
                      "and (doi is not null or pubmed_id is not null or patent_id is not null)")
        
        key_query = f"select e.id::varchar(50), d.doi, d.pubmed_id, d.patent_id"
        
        self.cur.execute(f"select count(*) {core_query}")
        length = self.cur.fetchall()[0][0]

        while length > 0:
            list_dict = []
            self.cur.execute(f"{key_query} {core_query} limit {batch}")
        
            for row in self.cur.fetchall():
                for key_idx in range(len(row) - 1):
                    key_str = keylist[key_idx]
                    list_dict.append({"experiment_id": row[0], "key": keymap[key_str], "text_value": str(row[key_idx + 1]), "assay_level": False})
                        
            #SimpleSchema ExperimentMetadataValue.bulk_register()
            ExperimentMetadataValue.bulk_register(list_dict)
            self.cur.execute(f"select count(*) {core_query}")
            length = self.cur.fetchall()[0][0]
    
    
    #Register generic entity metadata
    
    def batch_register_generic_entity_metadata(self, batch):
        
        keylists = [["Molecular Weight Freebase", "Full Molecular Formula", "Full Molecular Weight", "Monoisotopic Molecular Weight"], 
                    ["Accession", "Preferred Name", "Organism"], 
                    ["Component Type", "Description", "Taxonomy ID", "Organism"]]
        keys = []
        key_dict = []
        
        for key_list in keylists:
            for key in key_list:
                if key not in keys:
                    key_dict.append({"key": key, "value_type": 'STRING'})
                    keys.append(key)      
        
        #SimpleSchema EntityMetadata.bulk_register()
        EntityMetadata.bulk_register(key_dict)
        
        core_queries = [(f"from chembl.molecule_dictionary md "
                         "join genericentity ge " 
                         "on md.chembl_id = ge.corporate_id " 
                         "join chembl.compound_properties cp " 
                         "on cp.molregno = md.molregno " 
                         "where ge.id not in (select distinct genericentity_id from entitymetadatavalue)"),

                        (f"from chembl.component_sequences cs " 
                        "join chembl.target_components tc " 
                        "on cs.component_id = tc.component_id " 
                        "join chembl.target_dictionary td " 
                        "on tc.tid = td.tid " 
                        "join genericentity ge " 
                        "on ge.corporate_id = td.chembl_id " 
                        "where td.target_type = 'SINGLE PROTEIN' " 
                        "and ge.id not in (select distinct genericentity_id from entitymetadatavalue)"), 
                         
                         (f"from chembl.bio_component_sequences bcs " 
                         "join chembl.biotherapeutic_components bc " 
                         "on bcs.component_id = bc.component_id " 
                         "join chembl.molecule_dictionary md " 
                         "on bc.molregno = md.molregno " 
                         "join genericentity ge " 
                         "on md.chembl_id = ge.corporate_id " 
                         "where md.molregno not in (select cs.molregno from chembl.compound_structures cs) " 
                         "and ge.id not in (select distinct genericentity_id from entitymetadatavalue)")]
        
        key_queries = [f"ge.id, cp.mw_freebase, cp.full_molformula, cp.full_mwt, cp.mw_monoisotopic",
                       f"ge.id, cs.accession, td.pref_name, td.organism",
                       f"ge.id, bcs.component_type, bcs.description, bcs.tax_id, bcs.organism"]

        for i in range(len(keylists)):
            pk_list = []
            self.cur.execute(f"select count(*) {core_queries[i]}")
            length = self.cur.fetchall()[0][0]

            while length > 0:
                list_dict = []
                self.cur.execute(f"select distinct {key_queries[i]} {core_queries[i]} limit {batch}")
            
                for row in self.cur.fetchall():
                    ge_id = row[0]
                    
                    for key_idx in range(len(row) - 1):
                            key_id = keylists[i][key_idx]

                            if (ge_id, key_id) not in pk_list:
                                list_dict.append({"genericentity_id": ge_id, "key": key_id, "text_value": str(row[key_idx + 1]), "archived": 0})
                                pk_list.append((ge_id, key_id))

                #SimpleSchema EntityMetadataValue.bulk_register()            
                EntityMetadataValue.bulk_register(list_dict)
                self.cur.execute(f"select count(*) {core_queries[i]}")
                length = self.cur.fetchall()[0][0]

Save migrated data
--------------------

Once the `batch_register` method finishes, the SimpleSchema tables will be populated with the ChEMBL data.
At this point, DI can be run to make the data available for use in LiveDesign.

To create a dump file of SimpleSchema with the ChEMBL data, run the following command:

.. code-block:: bash

    pg_dump -h localhost -U postgres -d target_database -n public -f chembl_ss.dmp
