from typing import List, Dict, Type, Union, Optional

from simpleschema.models import (
    BaseModel, HashableModel, Compound, ObservationModel, Source, File, Structure, GenericEntity, Assay, Experiment,
    Metadata, AssayMetadataValue, ExperimentMetadataValue, ObservationMetadataValue)
from vroom.helpers import async_spawn

# NOTE: to monkey-patch simpleschema models appropriately, we create unbound class methods
# and override the relevant base class's register classmethod.
# NOTE: super(type, object) is used to call the parent's bound register method, which
# in our case for register_hashable and register_compound will always be the monkey-patched
# method (register_extended and register_hashable, respectively)
# NOTE: also see the * import at the end of this module


@classmethod
async def register_extended(cls: Type[BaseModel], **kwargs) -> BaseModel:

    @async_spawn(async_ctx_mgr=cls._meta.database.atomic_async())
    def f():
        if not kwargs:
            # NOTE: get_or_create will return last object if no query is specified
            return cls.create()
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated', True)
        try:
            entity, _ = cls.get_or_create(**validated_kwargs)
        except (IndexError, cls.DoesNotExist, IntegrityError):
            msg = "Entity already exists and updates are not allowed. Try the register_or_update() or update_entity()" \
                  " methods."
            raise IntegrityError(msg)
        return entity

    return await f()


@classmethod
async def get(cls: Type[BaseModel], **kwargs) -> BaseModel:

    @async_spawn(async_ctx_mgr=cls._meta.database.atomic_async())
    def f():
        return cls.get(**kwargs)

    return await f()


@classmethod
async def find(cls: Type[BaseModel], **kwargs) -> Union[List[BaseModel], None]:
    """
    Returns all matches of given query
    """

    @async_spawn(async_ctx_mgr=cls._meta.database.atomic_async())
    def f():
        return super(BaseModel, cls).find(**kwargs)

    return await f()


@classmethod
async def find_one(cls: Type[BaseModel], **kwargs) -> Union[BaseModel, None]:
    """
    WARNING: If there are multiple matches, only the last one will be returned
    """

    @async_spawn(async_ctx_mgr=cls._meta.database.atomic_async())
    def f():
        if not kwargs:
            try:
                return cls.select().order_by(cls.id.desc()).get()
            except cls.DoesNotExist:
                return None
        return cls.get_or_none(**kwargs)

    return await f()


@classmethod
async def register_hashable(cls: Type[HashableModel], **kwargs):

    entity: HashableModel = await super(HashableModel, cls).register(**cls.prep_and_validate_values(kwargs))
    if cls.autohash and entity is not None:
        entity.update_rowhash()

    return entity


@classmethod
async def register_compound(cls: Type[Compound], **kwargs) -> Compound:

    # NOTE: project is a hybrid_property and cannot be registered directly
    project = kwargs.pop("project", None)
    entity = await super(Compound, cls).register(**cls.prep_and_validate_values(kwargs))
    if cls.autohash and entity is not None:
        entity.molhash = generate_hash(entity.mol_file)
        entity.save()
    if project:
        await CompoundProject.register(primary=True, compound=entity, project=project)
    return entity


@classmethod
async def bulk_register_extended(cls: Type[BaseModel], rows: List[Dict]) -> List[BaseModel]:

    @async_spawn(async_ctx_mgr=cls._meta.database.atomic_async())
    def f():
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        lookup_field = fields.get(cls.lookup_field_name)
        keep = ['id'] if lookup_field.name == 'id' else ['id', lookup_field.name]  # don't update PK or lookup_field
        keep += ['created_at'] if 'created_at' in fields else []  # don't update 'created_at' (if it exists)
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(
                # The column to use for identifying row conflicts to update.
                # Uses cls.lookup_field_name attribute if it is set for the class, else will use cls.id
                conflict_target=[lookup_field],
                # The fields to update with the values of interest.
                # Note that EXCLUDED is a special temporary table that represents all rows that
                # conflicted -- see https://www.postgresql.org/docs/current/sql-insert.html as
                # well as http://docs.peewee-orm.com/en/latest/peewee/querying.html#bulk-inserts
                #
                # Here's what this field looks like in practice:--
                # {Compound.mol_file: EXCLUDED.mol_file, Compound.person: EXCLUDED.person, ...}
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                # if there is a condition on the unique constraint of the target lookup_field we need to provide that
                conflict_where=cls.lookup_unique_condition
            ))

    return await f()


async def switch_primary(self, project, deregister_current=False):
    """
    Switch out the current primary project with a new primary project.
    :arg project: The new project to use as primary. Can be the name of a
        project, or a Project instance.
    :param project: :class:`str` or :class:`Project`
    :arg deregister_current: Whether or not to also deregister the current
        primary, after adding a new one.
    :param deregister_current: :class:`bool`
    """
    self.project  # first do integrity checks on the existing primary project
    current_primary = list(CompoundProject.select().where(
        CompoundProject.primary == True,
        CompoundProject.compound == self.id,
    ))[0]
    if project in (current_primary.project, current_primary.project.key):
        return current_primary.project
    new_primary = await CompoundProject.register(compound=self, project=project, primary=False)
    current_primary.primary = False
    current_primary.save()
    new_primary.primary = True
    new_primary.save()
    if deregister_current:
        current_primary.deregister()
    return new_primary


async def deregister(self: BaseModel, deep=True, purge=False):

    @async_spawn(async_ctx_mgr=self._meta.database.atomic_async())
    def f():
        self.delete_instance(recursive=deep, delete_nullable=purge)

    return await f()


@classmethod
async def register_observation(cls,
                               assay: Union[str, Assay],
                               experiment: Optional[Union[str, Experiment]] = None,
                               **kwargs) -> ObservationModel:
    if isinstance(assay, str):
        assay: Assay = await Assay.register(key=assay)
    if isinstance(experiment, str):
        experiment: Experiment = await Experiment.register(assay=assay, key=None)
    kwargs['assay'] = assay
    kwargs['experiment'] = experiment
    entity: ObservationModel = await super(ObservationModel, cls).register(**kwargs)
    if cls.autohash and entity is not None:
        entity.update_rowhash()
    
    return entity


@classmethod
async def register_assay_metadata(cls,
                                  key: Union[str, Metadata],
                                  **kwargs) -> AssayMetadataValue:
    if isinstance(key, str):
        key: Metadata = await Metadata.register(key=key, assay_level=True)
        kwargs['key'] = key
    metadatavalue: AssayMetadataValue = await super(AssayMetadataValue, cls).register(**kwargs)
    return metadatavalue


@classmethod
async def register_experiment_metadata(cls,
                                       key: Union[str, Metadata],
                                       assay_level=False,
                                       **kwargs) -> ExperimentMetadataValue:
    if isinstance(key, str):
        key: Metadata = await Metadata.register(key=key, assay_level=assay_level)
        kwargs['key'] = key
    metadatavalue: ExperimentMetadataValue = await super(ExperimentMetadataValue, cls).register(**kwargs)
    return metadatavalue


@classmethod
async def register_observation_metadata(cls,
                                        key: Union[str, Metadata],
                                        **kwargs) -> ObservationMetadataValue:
    if isinstance(key, str):
        key: Metadata = await Metadata.register(key=key, assay_level=False)
        kwargs['key'] = key
    metadatavalue: ObservationMetadataValue = await super(ObservationMetadataValue, cls).register(**kwargs)
    return metadatavalue


@classmethod
async def register_file(cls, **kwargs) -> File:
    file = await super(File, cls).register(**cls.prep_and_validate_values(kwargs))
    if cls.autohash and file is not None:
        file.blobdigest = generate_hash(file.blob, use_sha256=True)
        file.save()
    return file


@classmethod
async def register_structure(cls, **kwargs) -> Structure:
    structure = await super(Structure, cls).register(**cls.prep_and_validate_values(kwargs))
    if cls.autohash and structure is not None:
        structure.blobdigest = generate_hash(structure.blob, use_sha256=True)
        structure.save()
    return structure


@classmethod
async def register_generic_entity(cls, corporate_id: str, file: Optional[File], **kwargs) -> GenericEntity:
    kwargs['file'] = file
    kwargs['corporate_id'] = corporate_id
    project = kwargs.pop('project', None)
    generic_entity = await super(GenericEntity, cls).register(**cls.prep_and_validate_values(kwargs))
    if project is not None:
        await GenericEntityProject.register(generic_entity=generic_entity,
                                            project=project,
                                            source=kwargs.get('source'))
    return generic_entity


async def purge(self: Source) -> Dict:
    purge_report = dict()
    purge_report['partial'] = 0
    conflicting_sources = set()
    for backref in self.CHILDREFS:
        short_backref = backref.replace('_by_source', '')
        purge_report[f'{short_backref}_deleted'] = 0
        purge_report[f'{short_backref}_skipped'] = 0
        select_query = getattr(self, backref)
        for ety in select_query.iterator():
            children, all_child_sources = ety.find_dependents()
            if children:
                purge_report['partial'] = 1
                for src_id in all_child_sources:
                    if src_id != self.id:
                        conflicting_sources.add(src_id)
            else:
                await ety.deregister()
                purge_report[f'{short_backref}_deleted'] += 1
    purge_report['conflicting_sources'] = list(conflicting_sources)
    return purge_report


BaseModel.find = find
BaseModel.find_one = find_one
BaseModel.register = register_extended
BaseModel.bulk_register = bulk_register_extended
HashableModel.register = register_hashable
Compound.register = register_compound
Compound.switch_primary = switch_primary
BaseModel.deregister = deregister
ObservationModel.register = register_observation
Source.purge = purge
File.register = register_file
GenericEntity.register = register_generic_entity
Structure.register = register_structure
AssayMetadataValue.register = register_assay_metadata
ExperimentMetadataValue.register = register_experiment_metadata
ObservationMetadataValue.register = register_observation_metadata

# NOTE: propagate the monkey-patch to all child classes. this will override
# `register` for all models in simpleschema that inherit from
# BaseModel and HashableModel, and it will also override `register`
# for Compound.
# also note that all simpleschema `register_*` convenience methods, e.g.
# register_acl and register_observation, will make use of these
# monkey-patched `register` methods, so ALL registration methods in
# aiosimpleschema.models are awaitable (:
from simpleschema.models import *  # noqa: F403
