import os.path

from flask import Flask

DOCS_STATIC_FOLDER = os.path.join('docs', 'html')

app = Flask(__name__, static_url_path='', static_folder=DOCS_STATIC_FOLDER)
app.config['DOCS_STATIC_FOLDER'] = DOCS_STATIC_FOLDER


@app.route('/')
def root():
    return app.send_static_file('index.html')


@app.route('/<path:file>')
def serve_file(file):
    return app.send_static_file(file)


def main():
    app.run('0.0.0.0', 8880)
    print()


if __name__ == '__main__':
    main()
