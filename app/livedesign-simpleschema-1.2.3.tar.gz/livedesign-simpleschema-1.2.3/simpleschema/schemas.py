from typing import Optional, List, Type, TypeVar

from simpleschema.models import (BaseModel, Project, Compound, EntityAlias, CompoundProject, Lot, LotProject, Assay,
                                 Experiment, Document, Page, CompoundProperty, LotProperty, LotObservation,
                                 CompoundObservation, LotObservationProject, CompoundObservationProject, ETLRun,
                                 Config, Source, File, GenericEntity, GenericEntityProject, GenericEntityProperty,
                                 GenericEntityObservation, GenericEntityObservationProject, GenericEntityLot,
                                 GenericEntityLotObservation, GenericEntityLotProject, GenericEntityLotProperty,
                                 Structure, Pose, GenericEntityLotObservationProject, PoseObservation, PoseObservationProject,
                                 EntityMetadata, EntityMetadataValue, Metadata, AssayMetadataValue, ExperimentMetadataValue,
                                 ObservationMetadataValue, GenericEntityLink, EntityRelationshipParent, EntityRelationshipChild, EntityRelationshipMetadata)
from peewee import ProgrammingError
from playhouse.postgres_ext import PostgresqlExtDatabase

ModelType = TypeVar('ModelType', bound=BaseModel)


# singleton
class SimpleSchema(object):
    """
    The SimpleSchema schema instance.

    :param all_tables: Table models to include in the SimpleSchema instance
    :param ensure_projects: A list of dictionaries of Project model instances to ensure exist when initializing SimpleSchema object
    """
    global_project = None
    default_restricted_project = None
    all_tables = [
        Project,
        Compound,
        EntityAlias,
        CompoundProject,
        Lot,
        LotProject,
        Assay,
        Experiment,
        Document,
        Page,
        CompoundProperty,
        LotProperty,
        LotObservation,
        LotObservationProject,
        CompoundObservation,
        CompoundObservationProject,
        ETLRun,
        Config,
        Source,
        File,
        GenericEntity,
        GenericEntityProject,
        GenericEntityProperty,
        GenericEntityObservation,
        GenericEntityObservationProject,
        GenericEntityLot,
        GenericEntityLotProject,
        GenericEntityLotProperty,
        GenericEntityLotObservation,
        GenericEntityLotObservationProject,
        Structure,
        Pose,
        PoseObservation,
        PoseObservationProject,
        EntityMetadata,
        EntityMetadataValue,
        Metadata,
        AssayMetadataValue,
        ExperimentMetadataValue,
        ObservationMetadataValue,
        GenericEntityLink,
        EntityRelationshipChild,
        EntityRelationshipParent,
        EntityRelationshipMetadata
    ]
    assay_tables = [
        PoseObservation,
        PoseObservationProject,
        LotObservation,
        LotObservationProject,
        CompoundObservation,
        CompoundObservationProject,
        GenericEntityObservation,
        GenericEntityObservationProject,
        GenericEntityLotObservation,
        GenericEntityLotObservationProject,
        Experiment,
        Assay,
        Metadata,
        AssayMetadataValue,
        ExperimentMetadataValue,
        ObservationMetadataValue
    ]
    property_tables = [
        LotProperty,
        CompoundProperty,
        GenericEntityProperty,
        GenericEntityLotProperty,
        EntityMetadata,
        EntityMetadataValue
    ]
    db: PostgresqlExtDatabase = None

    # Helper/utility methods
    def clear_all(self):
        """
        Nuclear option - completely clear DB and start over; can not be rolled back; should only be used for testing

        WARNING: a full re-DI is required after running this function
        """
        table_names = [table.get_table_name() for table in self.all_tables]
        if not table_names:
            return None
        sql = f'TRUNCATE {", ".join(table_names)} RESTART IDENTITY CASCADE'
        self.db.execute_sql(sql)

    @classmethod
    def clear_assay_values(cls, include_properties=False):
        """
        Clear assays/properties - Best way to keep consistency with unstructured data sources.
        Use with care. Updating values via customer_key or hash matching is strongly preferred.

        :param include_properties: set to True to also clear all Property tables, defaults to False
        :type include_properties: bool
        """
        for table in cls.assay_tables + (cls.property_tables if include_properties else []):
            for row in table.select():
                row.delete_instance()

    def create_tables(self, tables: Optional[List[Type['ModelType']]] = None):
        """
        Create all tables specified in the provided list of simpleschema table models. If `tables` is not set then
        the SimpleSchema object's `all_tables` list will be used.

        :param tables: list of simpleschema table models to create, defaults to None
        :type tables: list of table model instances
        """
        try:
            self.db.create_tables(tables if tables else self.all_tables)
        except ProgrammingError:
            # tables already exist
            self.db.rollback()

    def restore_default_projects(self, include_global: bool, default_restricted: str):
        """
        Ensure the default projects are registered in the simpleschema database.

        :param include_global: set to True to include the unrestricted "Global" project
        :type include_global: bool
        :param default_restricted: name of the default restricted project
        :type default_restricted: string
        """
        if Project.table_exists():
            if include_global:
                self.global_project = Project.register(key='Global', is_restricted=0)
            else:
                self.global_project = None
            if default_restricted:
                self.default_restricted_project = Project.register(key=default_restricted, is_restricted=1)
            else:
                self.default_restricted_project = None

    def __init__(self,
                 database_name,
                 user='simpleschema',
                 password='simpleschema',
                 host='localhost',
                 port=3247,
                 all_tables: List[Type['ModelType']] = None,
                 create_missing_tables=False,
                 include_global_project=False,
                 default_restricted_project='Default Restricted Project',
                 restore_projects=False,
                 ensure_projects: List[dict] = None):

        self.db = PostgresqlExtDatabase(database_name, user=user, password=password, host=host, port=port)
        self.db.connect()
        if all_tables:
            self.all_tables = all_tables
        self.db.bind(self.all_tables)
        if create_missing_tables:
            missing_tables = [t for t in self.all_tables if not t.table_exists()]
            self.create_tables(missing_tables)
        if ensure_projects:
            for proj_kwargs in ensure_projects:
                if proj_kwargs:
                    Project.get_or_create(**proj_kwargs)
        if restore_projects:
            self.restore_default_projects(include_global_project, default_restricted_project)

    def __del__(self):
        """NOTE: always close database connection on object destruction"""
        return self.db and self.db.close()
