from collections import defaultdict
from datetime import datetime
from typing import Dict, Generator, List, Optional, Set, Union, Tuple, Type, TypeVar

from simpleschema import EMPTY_MOL_FILE
from simpleschema.exceptions import *  # noqa: F403
from simpleschema.utils import (generate_hash, value_to_kwargs, validate_values, make_legacy_table_name, defaults,
                                file_full_path_to_kwargs)

from peewee import (Field, BooleanField, Model, ForeignKeyField, DeferredForeignKey, SmallIntegerField, DoubleField,
                    BigAutoField, BlobField, CharField, DateTimeField, TextField, Check, EXCLUDED)
from playhouse.shortcuts import model_to_dict
from playhouse.postgres_ext import PostgresqlExtDatabase, JSONField
from playhouse.hybrid import hybrid_property

ALLOWED_OPERATORS = ('=', '<', '>', '>=', '<=', '+', '++')
ALLOWED_VALUE_TYPES = ('INTEGER', 'FLOAT', 'STRING', 'DATE', 'DATETIME')


# Base model classes
class BaseModel(Model):
    """The base model class for all SimpleSchema table models that other models inherit from. Sets the primary key for
    all tables as auto-incrementing bigint.

    Lookup field name: `id`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)

    """

    lookup_field_name = 'id'  # each table model should set this if there is a unique key (e.g. Compound.corporate_id)

    class Meta:
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields

    @classmethod
    def bulk_prep_and_validate_values(cls, rows: List[Dict]) -> List[Dict]:
        """Bulk prepare and validate all row values for the **bulk_register()** method. All rows must have the same
        fields. This method will iterate over each row and run the **prep_and_validate_values()** method for this class
        and return a list of all prepared and validated rows.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A prepared and validated version of the input list of dictionaries
        :rtype: list of dictionaries
        """
        fields = rows[0].keys()
        if any(_.keys() != fields for _ in rows):
            raise ValueError('Not all rows have the same fields!')
        prepared_rows = [_ if _.get('validated') else cls.prep_and_validate_values(_) for _ in rows]
        return [_ if _.pop('validated', False) else {} for _ in prepared_rows]

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['BaseModel']:
        """Bulk register a list of row values. All rows must have the same fields and will be passed to
        the **bulk_prep_and_validate_values()** for this class. This operation is effectively an upsert and will use the
        class's `lookup_field` and any partial constraints set to resolve conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        lookup_field = fields.get(cls.lookup_field_name)
        keep = ['id'] if lookup_field.name == 'id' else ['id', lookup_field.name]  # don't update PK or lookup_field
        keep += ['created_at'] if 'created_at' in fields else []  # don't update 'created_at' (if it exists)
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(
                # The column to use for identifying row conflicts to update.
                # Uses cls.lookup_field_name attribute if it is set for the class, else will use cls.id
                conflict_target=[lookup_field],
                # The fields to update with the values of interest.
                # Note that EXCLUDED is a special temporary table that represents all rows that
                # conflicted -- see https://www.postgresql.org/docs/current/sql-insert.html as
                # well as http://docs.peewee-orm.com/en/latest/peewee/querying.html#bulk-inserts
                #
                # Here's what this field looks like in practice:--
                # {Compound.mol_file: EXCLUDED.mol_file, Compound.person: EXCLUDED.person, ...}
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                # if there is a condition on the unique constraint of the target lookup_field we need to provide that
                conflict_where=cls.lookup_unique_condition
            ))

    def deregister(self, deep: bool = True, purge: bool = False):
        """De-registers a model or model object.

        :param deep: Whether to recursively delete all child entities, defaults to True
        :type deep: bool
        :param purge: Whether to delete all entities that reference this entity, defaults to False
        :type purge: bool
        """
        self.delete_instance(recursive=deep, delete_nullable=purge)

    @classmethod
    def find(cls, **kwargs) -> Optional[List[Type['ModelType']]]:
        """Finds and returns all entities based on provided keyword arguments (kwargs). If there are no kwargs provided,
        all entities will be returned (ordered by id, descending). The provided kwargs will be run through the
        **prep_and_validate_values()** method of the class (cls) first, so some values may get transformed and/or set
        to their default values. If any provided values remain None after being processed by the class's
        **prep_and_validate_values()** method, they will be added to the WHERE condition as IS NULL.

        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A list of matching model objects if kwargs provided, all objects (ordered by id, descending) otherwise
        :rtype: list
        """
        if not kwargs:
            try:
                return list(cls.select().order_by(cls.id.desc()))
            except cls.DoesNotExist:
                return None
        # NOTE: we need to translate kwargs to equality tests, e.g.:
        #   {'corporate_id': '1', 'source_id': None} => [Compound.corporate_id == 1, Compound.source.is_null()]
        # List of args will be implicitly combined with AND operator
        args = []
        fields_and_cols = cls.get_fields_and_columns()
        for kwarg in list(cls.prep_and_validate_values(kwargs)):
            if kwarg in fields_and_cols:
                if kwargs[kwarg] is None:
                    # if the kwarg is still explicitly set to None after prep_and_validate then add it to the condition
                    kwargs.pop(kwarg)
                    args.append(fields_and_cols[kwarg].is_null())
                else:
                    args.append(getattr(cls, kwarg) == kwargs.pop(kwarg))
        # NOTE: any leftover kwargs will still (rightfully) throw a TypeError if they are for fields not in
        #   cls.get_fields_and_columns()
        return list(cls.select().where(*args, **kwargs))

    def find_dependents(self) -> Tuple[int, Set[int]]:
        """Return the number of children and their sources for the model or model object. This is primarily used by the
        `Source.purge() <simpleschema.html#models.Source.purge>`_ method.

        :return: A tuple containing an integer number of children and a set with each child.source.id
        :rtype: tuple
        """
        count = 0
        sources = set()

        def process_query(qry, cnt, srcs):
            # global count, sources
            q_count = qry.count()
            if q_count:
                cnt += q_count
                children = [child for child in qry]
                for child in children:
                    if child and child.source:
                        srcs.add(child.source.id)
            return cnt, srcs

        for child_ref in self.CHILDREFS:
            model_query = getattr(self, child_ref)
            count, sources = process_query(model_query, count, sources)
        return count, sources

    @classmethod
    def find_one(cls, **kwargs) -> Optional[Type['ModelType']]:
        """Find and return a single entity based on provided keyword arguments. If there are multiple matches, only the
        last one will be returned.

        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A single model object matching the search conditions
        :rtype: model class object
        """
        if not kwargs:
            try:
                return cls.select().order_by(cls.id.desc()).get()
            except cls.DoesNotExist:
                return None
        return cls.get_or_none(**kwargs)

    @classmethod
    def get_fields_and_columns(cls) -> Dict[str, Field]:
        """Creates a dictionary of model field or database column names mapped to the corresponding fields from the
        table model class.

        :return: A dictionary of field/column attribute names mapped to matching model fields
        :rtype: dictionary
        """
        return {**cls._meta.fields, **cls._meta.columns}

    @classmethod
    def get_table_name(cls) -> str:
        """Retrieves the database table name for the given table model class.

        :return: The database table name for the table model class
        :rtype: string
        """
        return cls._meta.table_name

    @classmethod
    def locate(cls, **kwargs) -> Optional[Type['ModelType']]:
        """Similar to **find_one()** but will only look up an entity by its `lookup_field_name`, falling back to
        `customer_key` or `id`, if set in the keyword arguments (kwargs). Returns `None` if no kwargs are provided or
        if none of `lookup_field_name`, `customer_key` or `id` are included in the search condition kwargs. Any other
        kwargs are ignored for the search.

        :param kwargs: Keyword arguments to be used as the search conditions, with at least one being the model class's
            lookup_field_name, customer_key or id
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: A single model object matching the search conditions
        :rtype: model class object
        """
        if not kwargs:
            return None
        lookup_order = set()
        for lookup_field_name in ['id', 'customer_key', cls.lookup_field_name]:
            if lookup_field_name in cls.get_fields_and_columns():
                lookup_order.add(lookup_field_name)
        for field in lookup_order:
            val = kwargs.get(field)
            if val:
                lookup = {field: val}
                entity = cls.find_one(**lookup)
                if entity:
                    return entity
        return None

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate keyword arguments (kwargs) for the **register()** and **bulk_register()** methods. This
        base method will check to see if any of the specified kwargs are supposed to be a model object, such as a
        ForeignKeyField, but the value is not set to an instance/object of that model class. This method will attempt to
        find a matching model object by searching with the model class's `lookup_field_name`.

        **Example:**

        When registering a `Lot`, a foreign key relationship back to `Compound` is required in the
        `Lot.compound` field. The `Compound.lookup_field_name` is `corporate_id`. If a compound has been registered with
        `Compound.id` = 1 and `Compound.corporate_id` = 'CPD-1234', then passing kwargs of
        ``{'compound': 'CPD-1234'}`` to this method will return updated kwargs of ``{'compound': <Compound: 1>}``.

        All BaseModel subclasses should override this method with their own docstring information relevant to that class
        as well as additional overrides to do any preparation and/or validation of the provided arguments for that
        specific model class, particularly if not overriding that class's **register()** method.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        for k in kwargs:
            if kwargs[k] is None:
                continue
            # if field is an object model but an object was not specified...
            model = cls.property_model(k)
            if model is not None and not isinstance(kwargs[k], model):
                # ...do query to get object model instance from database
                kwargs[k] = model.get(**{model.lookup_field_name: kwargs[k]})
        kwargs['validated'] = True
        return kwargs

    lookup_unique_condition = None  # True if a table model has a unique constraint with (cls.archived == 0) condition
    CHILDREFS = []  # each table model should set this to any children with FK refs back to this parent model

    @classmethod
    def property_model(cls, prop) -> Optional['BaseModel']:
        """Check to see if the given property/argument is supposed to be a related table model and return that model
        class. For example, ``Lot.property_model('compound')`` will return ``Compound``.

        See `BaseModel.prep_and_validate_values() <simpleschema.html#models.BaseModel.prep_and_validate_values>`_ for
        more details.

        :param prop: Property/argument to search for to see if it is a related table model
        :type prop: string
        :return: The table model class related to prop or None if one is not found
        :rtype: a table model class instance
        """
        return cls.__dict__[prop].__dict__.get('rel_model') if prop in cls.__dict__ else None

    @classmethod
    def register(cls, **kwargs) -> 'BaseModel':
        """Register a new entity. If there are no unique constraints on the table then
        this operation is effectively an upsert, otherwise an IntegrityError will be thrown. To update an existing
        entity with table constraints, use the **locate()** and **update_entity()** functions or the
        **register_or_update()** function.

        Either override this method or **prep_and_validate_values()**.

        All BaseModel subclasses should override this method with their own docstring information relevant to that
        model class as well as additional overrides for that specific model class but should still call
        ``super().register(kwargs)`` to get the entire chain of methods.

        Example registration with minimum required fields:

        .. code-block:: python

            BaseModel.register()

        :param kwargs: Keyword arguments to be used to register a new entity or as search conditions for an existing
            entity
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found model entity exactly matching the search conditions
        :rtype: model class object
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated', True)
        try:
            entity, _ = cls.get_or_create(**validated_kwargs)
        except (IndexError, cls.DoesNotExist, IntegrityError):
            msg = "Entity already exists and updates are not allowed. Try the register_or_update() or update_entity()" \
                  " methods."
            raise IntegrityError(msg)
        return entity

    @classmethod
    def register_or_update(cls, **kwargs) -> 'BaseModel':
        """Will attempt to register a new or upsert an existing entity. If the entity exists and provided kwargs do not
        match exactly, leading to an IntegrityError, then the matching entity will be updated.

        :param kwargs: Keyword arguments to be used to register a new entity or update an existing entity found using
            **locate()**
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or updated model entity
        :rtype: model class object
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        try:
            entity = cls.register(**validated_kwargs)
        except IntegrityError:
            entity = cls.locate(**validated_kwargs)
            if entity:
                entity.update_entity(**validated_kwargs)
        return entity

    def update_entity(self, **kwargs) -> int:
        """Update an existing entity with the provided keyword arguments (kwargs). Note, if None values are explicitly
        set in the provided kwargs, those attributes will be set to None.

        :param kwargs: Keyword arguments to be used to update the given model entity
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: Updated model entity
        :rtype: model class object
        """
        validated_kwargs = self.prep_and_validate_values(kwargs)
        num_changed_values = 0
        for k in validated_kwargs:
            old_value = getattr(self, k)
            new_value = validated_kwargs[k]
            if old_value != new_value:
                num_changed_values += 1
                setattr(self, k, validated_kwargs[k])
        if num_changed_values:
            if 'modified_at' in self.get_fields_and_columns() and not validated_kwargs.get('modified_at'):
                self.update()
                self.modified_at = datetime.utcnow()  # noqa
            self.save()
        return num_changed_values

    @classmethod
    def upsert(cls, **kwargs) -> 'BaseModel':
        """
        Insert a new entity or, if there are conflicts found, update an existing entity with the provided kwargs. Note
        if None values are explicitly set in the provided kwargs then those attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        lookup_field = fields.get(cls.lookup_field_name)
        keep = ['id'] if lookup_field.name == 'id' else ['id', lookup_field.name]  # don't update PK or lookup_field
        keep += ['created_at'] if 'created_at' in fields else []  # don't update 'created_at' (if it exists)
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                # The column to use for identifying row conflicts to update.
                # Uses cls.lookup_field_name attribute if it is set for the class, else will use cls.id
                conflict_target=[lookup_field],
                # The fields to update with the values of interest.
                # Note that EXCLUDED is a special temporary table that represents all rows that
                # conflicted -- see https://www.postgresql.org/docs/current/sql-insert.html as
                # well as http://docs.peewee-orm.com/en/latest/peewee/querying.html#bulk-inserts
                #
                # Here's what this field looks like in practice:--
                # {Compound.mol_file: EXCLUDED.mol_file, Compound.person: EXCLUDED.person, ...}
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                # if there is a condition on the unique constraint of the target lookup_field we need to provide that
                conflict_where=cls.lookup_unique_condition
            ))

    id = BigAutoField()


# Type hinting
ModelType = TypeVar('ModelType', bound=BaseModel)


class ArchivableModel(BaseModel):
    """A BaseModel subclass that adds `archived` and `customer_key` fields.

    Lookup field name: `customer_key`

    Fields in this model:
    
    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted

    Example registration with minimum required fields:
        
    .. code-block:: python

        ArchivableModel.register()
    
    :param unarchive_match: Whether to unarchive an ArchivableModel instance when a matching instance is found
    :type unarchive_match: bool, defaults to True
    :param args: Any additional positional arguments
    :type args: list
    :param kwargs: Any additional named keyword arguments
    :type kwargs: comma separated keyword arguments, field/column name = value
    """  # noqa: E501

    lookup_field_name = 'customer_key'

    def __init__(self, unarchive_match=True, *args, **kwargs):
        # FIXME: add test for unarchive_match
        super().__init__(*args, **kwargs)
        if unarchive_match and self.archived == 1:
            self.unarchive()

    def archive(self):
        """Set archived = 1 for the current model entity.
        """
        self.archived = 1
        self.save()

    @classmethod
    def customer_keys(cls) -> Generator[str, None, None]:
        """Generator to fetch all customer_keys in the given model class.

        :return: All customer_keys in the given model class
        :rtype: tuple
        """
        return (_.customer_key for _ in cls.select(cls.customer_key).where(cls.customer_key.is_null(False)))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate keyword arguments (kwargs) for the **register()** and **bulk_register()** methods. This
        method will ensure that `customer_key` in kwargs is cast to string before calling
        `BaseModel.prep_and_validate_values() <simpleschema.html#models.BaseModel.prep_and_validate_values>`_.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        customer_key = kwargs.get('customer_key', None)
        if isinstance(customer_key, int):
            kwargs['customer_key'] = str(customer_key)
        return super().prep_and_validate_values(kwargs)

    def unarchive(self):
        """Set archived = 0 for the current model entity.
        """
        self.archived = 0
        self.save()

    archived = SmallIntegerField(**defaults(0))  # DI mappings should include WHERE archived = 0
    customer_key = TextField(null=True, unique=True)  # used for reference and/or diff checking


class HashableModel(ArchivableModel):
    """An ArchivableModel subclass that adds an optional `rowhash` field. Registration methods will automatically hash
    a row during registration based on a dictionary of the class's `hashable_fields`.

    If auto-hashing is undesirable, set the `autohash` property on your child class to False:
    
    .. code-block:: python

        from simpleschema.models import Lot
        Lot.autohash = False
    
    Lookup field name: `customer_key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived'} for the row

    """  # noqa: E501
    hashable_fields = {'customer_key', 'archived'}  # can override this list in implementing models
    autohash: bool = True

    @classmethod
    def generate_rowhash(cls, model_dict, use_sha256=False):
        """Will return a rowhash for a provided model_dict but only if the key appears in the class's `hashable_fields`
        and/or will set missing or unset fields to their default values.

        :param model_dict: A dictionary with the given model's field names as the keys and field values as the values
        :type model_dict: dictionary, fieldname: value
        :param use_sha256: Specifies whether to use md5 (False) or sha256 (True) for hashing, defaults to False
        :type use_sha256: bool
        :return: Rowhash strings
        :rtype: string
        """
        hashable_fields_defaults = {
            k: f.default for k, f in cls.get_fields_and_columns().items() if k in cls.hashable_fields
        }
        hashable_dict = dict()
        for k in hashable_fields_defaults:
            val = model_dict.get(k)
            hashable_dict[k] = val if val is not None else hashable_fields_defaults[k]
        return generate_hash(model_dict, use_sha256=use_sha256)

    @classmethod
    def list_diffs(cls,
                   new_entities: Dict[Union[str, int], Dict[str, object]]
                   ) -> Dict[str, Dict[Union[str, int], Dict[str, object]]]:
        """Using the `customer_key` and `rowhash` values, compare a dictionary of new entities keyed by the PK value in
        the remote system (`customer_key`) and return whether each item in the new_entities dictionary are updates to
        existing entities (`rowhash` does not match), deletion of existing entities (`customer_key` not found in
        `new_entities`), or truly new entities (`customer_key` not found in existing entities). Note that
        `customer_key` must be set for this method to work. As `customer_key` should now be a string (TEXT field), this
        value will be cast to str before any comparisons but will retain the format/type of the keys in `new_entities`
        when returning the processed dictionary.

        :param new_entities: A dictionary of new entities to compare to existing entities where customer keys are the
            keys and entity dictionaries are the values
        :type new_entities: dictionary, customer_key: entity dictionary
        :return: A dictionary of updates, deletions and insertions, keyed on customer_key
        :rtype: dictionary, customer_key: processed entity dictionary
        """
        new_entities_use_int = isinstance(list(new_entities.keys())[0], int)  # if the first key is int set to True

        def format_pk(pk: Union[str, int]) -> Union[str, int]:
            """Cast customer_pk as int if new_entities dict is using that format for its first key.
            """
            return int(pk) if new_entities_use_int else pk

        known_entities = {ent.customer_key: ent.rowhash
                          for ent in cls.select(cls.customer_key, cls.rowhash).where(cls.customer_key.is_null(False))}
        processed = defaultdict(dict)

        # updates
        for customer_pk in known_entities:
            formatted_pk = format_pk(customer_pk)  # ensure we are reading/writing pk in right format for new_entities
            try:
                ent_details = new_entities.pop(formatted_pk)  # catch deletion KeyErrors here
                if ent_details['rowhash'] != known_entities[customer_pk]:
                    processed['updates'][formatted_pk] = ent_details

            # deletes
            except KeyError:
                processed['deletes'][formatted_pk] = {}

        # inserts
        for formatted_pk, ent_details in new_entities.items():
            processed['inserts'][formatted_pk] = ent_details

        return processed

    @classmethod
    def register(cls, **kwargs) -> 'HashableModel':
        """
        Register a new HashableModel entity. If `autohash` is enabled for the class then generate and update the
        `rowhash` for that entity instance.

        Example registration with minimum required fields:

        .. code-block:: python

            HashableModel.register()

        :param kwargs: Keyword arguments to be used to register a new entity or as search conditions for an existing
            entity
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found model entity exactly matching the search conditions
        """
        model = super().register(**kwargs)
        if cls.autohash and isinstance(model, HashableModel):
            model.update_rowhash()
        return model

    def update_rowhash(self):
        """Update the `rowhash` for the model entity instance. Will only use the values in the `hashable_fields`
        attribute.
        """
        dct = model_to_dict(self, recurse=False)
        for k in list(dct.keys()):
            # Exclude kwarg for model_to_dict seems to not work in all cases so let's manually pop them out:
            if k not in self.hashable_fields:
                dct.pop(k)
                continue
        self.rowhash = generate_hash(dct)
        self.save()

    rowhash = CharField(index=True, null=True)  # can be set to custom row/dict hash


class DateFieldModel(HashableModel):
    """A HashableModel subclass that adds the optional `created_at` and `modified_at` fields. Note that any update 
    methods for subclasses should ensure that `created_at` is not updated unless explictly set.

    Lookup field name: `customer_key`

    Fields in this model:
    
    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived'} for the row
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified

    Example registration with minimum required fields:
        
    .. code-block:: python

        DateFieldModel.register()

    """  # noqa: E501

    created_at = DateTimeField(null=True, **defaults(datetime.utcnow))
    modified_at = DateTimeField(null=True, **defaults(datetime.utcnow))


class AclsMixin:
    """Mixin class for adding common method(s) for Model classes with "project_acls" backrefs.
    """
    project_acls = []

    def get_acls(self) -> List['Project']:
        """Gets a list of all ACLs for the current model entity.
        """
        return [_.project for _ in self.project_acls]


class PropertyModel(ArchivableModel):
    """An ArchivableModel subclass for Compound, Lot, and GenericEntity property tables. The `key` field will appear in
    LiveDesign as a column name in the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE
    of `num_value`, `text_value`, or `date_value` fields should be set.

    Lookup field name: `customer_key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key`: REQUIRED (text) - name of the property
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    """  # noqa: E501
    allowed_value_kwargs = ['num_value', 'text_value', 'date_value']

    # compound or lot AS observed_item_id
    key = TextField()  # AS protocol_id
    num_value = DoubleField(null=True)  # AS quantity
    text_value = TextField(null=True)  # AS cat_obs_phenomenon
    date_value = DateTimeField(null=True)  # AS date_value

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate keyword arguments (kwargs) for the property's **register()** and **bulk_register()**
        methods. This method will ensure that only one value is set in kwargs calling
        `BaseModel.prep_and_validate_values() <simpleschema.html#models.BaseModel.prep_and_validate_values>`_.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        value_kwargs = {k: kwargs.get(k) for k in cls.allowed_value_kwargs}
        validated_value_kwargs = validate_values(**value_kwargs)
        kwargs.update(validated_value_kwargs)
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'PropertyModel':
        """Register a new property for the related entity. The `key` field will appear in LiveDesign as a column name in
        the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            PropertyModel.register(key='Some Property', num_value=42)

        :param kwargs: Keyword arguments to be used to register a new property or as search conditions for an existing
            property
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found property model entity exactly matching the search conditions
        """
        prop = super().register(**kwargs)
        return prop


class ObservationModel(DateFieldModel, AclsMixin):
    """A DateFieldModel subclass with AclsMixin for Compound, Lot, GenericEntity, and Pose observation tables. Depending 
    on the aggregation mode and column foldering rules, the columns will appear in the Experimental Assays section of 
    the LiveDesign Data & Columns tree and all endpoints sharing the same Assay will be collected in a folder of 
    `Assay.key`. For ASSAY_NAME_TYPE aggregation, the column names will appear like `Assay.name (Observation.endpoint)`; 
    for example, 'Binding at Foo (IC50)'. Concentration, units, and other column aggregation modes may change how the 
    column appears in LiveDesign. Note that ONLY ONE of `num_value`, `text_value`, or `date_value` fields should be set.

    Lookup field name: `customer_key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'archived', 'assay', 'conc', 'conc_unit', 'customer_key', 'date_value', 'document', 'endpoint', 'experiment', 'lot', 'num_value', 'page', 'std_dev', 'structure', 'text_value', 'unit', 'value_operator'} for the row
    * `assay(_id)`: REQUIRED FK to Assay table; provides assay/protocol name and version
    * `experiment(_id)`: REQUIRED FK to Experiment table; provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
    * `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo")
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
    * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
    * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as `concentration` in hover-over tooltips
    * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
    * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
    * `page(_id)`: OPTIONAL FK to Page table; if unset then document_page will be set to `'0'`
    * `document(_id)`: OPTIONAL FK to Document table
    """  # noqa: E501
    hashable_fields = {'archived', 'assay', 'conc', 'conc_unit', 'customer_key', 'date_value', 'document', 'endpoint',
                       'experiment', 'lot', 'num_value', 'page', 'std_dev', 'structure', 'text_value', 'unit',
                       'value_operator'}
    allowed_value_kwargs = ['num_value', 'text_value', 'date_value']
    CHILDREFS = ['project_acls']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate keyword arguments for the observation's **register()** and **bulk_register()** methods.
        This method will ensure that only one value is set in kwargs calling
        `BaseModel.prep_and_validate_values() <simpleschema.html#models.BaseModel.prep_and_validate_values>`_.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        value_kwargs = {k: kwargs.get(k) for k in cls.allowed_value_kwargs}
        validated_value_kwargs = validate_values(**value_kwargs)
        kwargs.update(validated_value_kwargs)
        assay = kwargs.get('assay')
        experiment = kwargs.get('experiment')
        if 'value_operator' in kwargs and kwargs['value_operator'] not in ALLOWED_OPERATORS:
            kwargs['value_operator'] = None
        if not assay:
            if not isinstance(experiment, Experiment):
                raise ValueError("assay (name or Model) or experiment (Model) must be set")
            else:
                assay = experiment.assay
                kwargs['assay'] = assay
        if isinstance(assay, str):
            assay = Assay.register(key=assay, version='1')
            kwargs['assay'] = assay
        if isinstance(experiment, str):
            experiment = Experiment.register(assay=assay, key=None)
            kwargs['experiment'] = experiment

        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'ObservationModel':
        """Register a new observation for the related entity. Depending on the aggregation mode and column foldering
        rules, the columns will appear in the Experimental Assays section of the LiveDesign Data & Columns tree and all
        endpoints sharing the same Assay will be collected in a folder of `Assay.key`. For ASSAY_NAME_TYPE aggregation,
        the column names will appear like `Assay.name (Observation.endpoint)`; for example, 'Binding at Foo (IC50)'.
        Concentration, units, and other column aggregation modes may change how the column appears in LiveDesign. Note
        that ONLY ONE of `num_value`, `text_value`, or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            ObservationModel.register(assay=Assay.register(assay_kwargs),
                                      experiment=Experiment.register(experiment_kwargs),
                                      endpoint='Some Endpoint',
                                      num_value=42)

        :param kwargs: Keyword arguments to be used to register a new observation or as search conditions for an
            existing observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found observation model entity exactly matching the search conditions
        """
        observation = super().register(**kwargs)
        return observation

    # consensus fields
    endpoint = TextField()  # AS type_id (use surrogate_key)
    unit = CharField(null=True)  # AS unit_id (use surrogate_key)
    text_value = TextField(null=True)  # AS cat_obs_phenomenon
    num_value = DoubleField(null=True)  # AS quantity
    date_value = DateTimeField(null=True)  # AS date_value
    std_dev = DoubleField(null=True)  # AS quantity_std_dev
    value_operator = CharField(null=True)  # AS obs_operator (=,<,>,>=,<=,+,++)
    conc = DoubleField(null=True)  # AS quantity_conc
    conc_unit = CharField(null=True)  # AS quantity_conc_unit (use unit_id surrogate_key)

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value) = 1", name="only_one_observation_value"),
            Check(f"value_operator IN {ALLOWED_OPERATORS}", name="observation_allowed_operators")
        ]


# SimpleSchema models that are not used by Data Integrator but are useful for ETL implementations of SimpleSchema
class Config(DateFieldModel):
    """This table holds ETL config information. The actual config used can be stored as a JSON object in the `config`
    field. You can optionally associate a Config with a project and a person.

    Lookup field name: `key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'archived', 'config', 'customer_key', 'key', 'person', 'project'} for the row
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `config`: OPTIONAL (json) - JSON field to store config settings used for loading/transforming data
    * `key`: REQUIRED/UNIQUE (text) - name for configuration settings
    * `project(_id)`: OPTIONAL FK to Project table - project associated to all data uploaded with this config
    * `person`: OPTIONAL (text) - name of person who created/updated config
    """  # noqa: E501

    lookup_field_name = 'key'
    hashable_fields = {'archived', 'config', 'customer_key', 'key', 'person', 'project'}

    @classmethod
    def register(cls, **kwargs) -> 'Config':
        """Register a new config used by the ETL into SimpleSchema. The actual config used can be stored as a JSON
        object in the `config` field. You can optionally associate a Config with a project and a person.

        Example registration with minimum required fields:

        .. code-block:: python

            Config.register(key='unique config name')

        :param kwargs: Keyword arguments to be used to register a new config or as search conditions for an existing
            config
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found config entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    key = TextField(unique=True)
    person = TextField(null=True)
    project = DeferredForeignKey('Project', null=True)
    config = JSONField(null=True)


class Source(BaseModel):
    """This table tracks uploads of data into the SimpleSchema (ETL runs), such as from a particular file, using a
    particular config, and/or done at a particular time. The Source id can be optionally associated in other table
    models' `source(_id)` field for auditing purposes or to purge all entities from a particular source.

    Lookup field name: `key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `key`: REQUIRED/UNIQUE (text) - filename or other reference for data source
    * `config_id`: OPTIONAL FK to Config table
    * `person`: OPTIONAL (text: `'LiveDesign'`) - name of person who uploaded data source
    * `project_id`: OPTIONAL FK to Project table - project associated to all data uploaded with this source
    * `uploaded`: OPTIONAL (timestamp) - timestamp source was uploaded
    * `processed`: OPTIONAL (timestamp) - timestamp source was processed
    * `purged`: OPTIONAL (timestamp) - timestamp source was purged
    * `partial_purge`: OPTIONAL (int2) - whether source was partially (1) or fully purged (0)

    """
    lookup_field_name = 'key'

    CHILDREFS = [
        'poses', 'structures', 'lot_observation_acls', 'lot_observations', 'lot_properties', 'lot_acls', 'lots',
        'generic_entity_observation_acls', 'generic_entity_observations', 'generic_entity_properties',
        'compound_observations', 'compound_properties', 'documents', 'experiments', 'assays', 'compound_acls',
        'entity_aliases', 'compounds', 'generic_entity_files', 'generic_entity_acls', 'generic_entities',
        'generic_entity_observations', 'ge_lots', 'ge_lot_acls', 'ge_lot_properties', 'ge_lot_observations',
        'ge_lot_observation_acls'
    ]

    def purge(self) -> Dict[str, Union[int, list]]:
        """Purge all entities that are in a FK relationship to this source. If an entity can't be deleted because there
        are other children from a different source then those entities will be skipped and logged in the returned purge
        report.

        Must be called under ``with target_schema.db.atomic()``:

        Example:

        .. code-block:: python

            src = find_source(query)
            purge_report = defaultdict()

            with target_schema.db.atomic():
                purge_report.update(src.purge())
                src.purged = datetime.utcnow()
                src.partial_purge =  purge_report.get('partial')
                src.save()

        :return: A dictionary with counts of partial purges, deletions and skips, and a list of conflicting sources
        :rtype: dictionary
        """
        purge_report: Dict[str, Union[int, list]] = dict()
        purge_report['partial'] = 0
        conflicting_sources = set()
        for backref in self.CHILDREFS:
            short_backref = backref.replace('_by_source', '')
            purge_report[f'{short_backref}_deleted'] = 0
            purge_report[f'{short_backref}_skipped'] = 0
            select_query = getattr(self, backref)
            for ety in select_query.iterator():
                children, all_child_sources = ety.find_dependents()
                if children:
                    purge_report['partial'] = 1
                    for src_id in all_child_sources:
                        if src_id != self.id:
                            conflicting_sources.add(src_id)
                else:
                    ety.deregister()
                    purge_report[f'{short_backref}_deleted'] += 1
        purge_report['conflicting_sources'] = list(conflicting_sources)
        return purge_report

    @classmethod
    def register(cls, **kwargs) -> 'Source':
        """Register a new source used by the ETL to load data into SimpleSchema, such as from a particular file, using a
        particular config, and/or done at a particular time. The Source id can be optionally associated in other table
        models' `source(_id)` field for auditing purposes or to purge all entities from a particular source.

        Example registration with minimum required fields:

        .. code-block:: python

            Source.register(key='myfile.csv')

        :param kwargs: Keyword arguments to be used to register a new source or as search conditions for an existing
            source
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found source model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    key = TextField(unique=True)
    config = ForeignKeyField(Config, null=True)
    person = TextField(null=True)
    project = DeferredForeignKey('Project', null=True)
    uploaded = DateTimeField(null=True)
    processed = DateTimeField(null=True)
    purged = DateTimeField(null=True)
    partial_purge = SmallIntegerField(null=True)


class ETLRun(BaseModel):
    """This table tracks the start/end times and status of the last ETL run. There is an optional relationship to
    Source table to track configs used, names or other identifiers, etc.

    Lookup field name: `id`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `started`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when ETL run was started/record was created
    * `finished`: OPTIONAL (timestamp without timezone) - timestamp of when ETL run was finished
    * `status`: OPTIONAL (varchar255: `'CREATED'`) - status of ETL run; suggested labels are CREATED, RUNNING, LOAD_FINISHED, LOAD_FAILED, FINISHED, FAILED
    * `source(_id)`: OPTIONAL FK to Source table

    Example registration with minimum required fields:
        
    .. code-block:: python

        ETLRun.register()

    """  # noqa: E501
    started = DateTimeField(**defaults(datetime.utcnow))
    finished = DateTimeField(null=True)
    status = CharField(null=True, **defaults('CREATED'))
    source = ForeignKeyField(Source, null=True)


# Models used by DI (tables, fields, and custom methods)
class Project(ArchivableModel):  # syn_project
    """This table contains project details and is mapped to syn_project.

    There is a conditional unique constraint on `Project.key` WHERE archived=0.

    Lookup field name: `key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for project from customer's source DB, API, etc.
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key`: REQUIRED/UNIQUE (text) - any project name here will be added/created in LD
    * `description`: OPTIONAL (text) - project description
    * `is_restricted`: REQUIRED (int2: `1`) - if set to 1, project/data is restricted to users with explicit access to the project; if set to 0, project/data is unrestricted and any user can access the project

    """  # noqa: E501
    lookup_field_name = 'key'

    @classmethod
    def register(cls, **kwargs) -> 'Project':
        """Register a new project.

        Example registration with minimum required fields:

        .. code-block:: python

            Project.register(key='My Project')

        :param kwargs: Keyword arguments to be used to register a new project or as search conditions for an existing
            project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found project model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def restrict(self):
        """Set is_restricted to 1.
        """
        self.is_restricted = 1
        self.save()

    def unrestrict(self):
        """Set is_restricted to 0.
        """
        self.is_restricted = 0
        self.save()

    def update_description(self, description: str):
        """Update the description field to the provided string.

        :param description: Content with which to update the description field.
        :type description: string
        """
        self.description = description
        self.save()

    key = TextField()  # AS project_name
    description = TextField(null=True)  # AS project_desc
    is_restricted = SmallIntegerField(**defaults(1))  # AS is_restricted
    # CASE WHEN archived = 0 THEN 'N' ELSE 'Y' AS active


Project.add_index(Project.key, unique=True, where=(Project.archived == 0))
Project.lookup_unique_condition = (Project.archived == 0)


class Compound(DateFieldModel, AclsMixin):  # syn_compound
    """This table contains compound/structure information and is mapped to syn_compound. 
    
    Notes:
     - `mol_file` must be in MOL or single SDF format
     - if `project` is set in kwargs for `Compound.register() <simpleschema.html#models.Compound.register>`_ this
       project will be set as the "primary" project and used in the syn_compound.project_id mapping

    There is a conditional unique constraint on `Compound.corporate_id` WHERE `archived = 0`.

    Lookup field name: `corporate_id`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`)
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'person', 'corporate_id', 'mol_file', 'customer_key', 'archived'} for the row
    * `mol_file`: REQUIRED (text: `EMPTY_MOL_FILE_STRING`) - must be in MDL MOL format or single SDF
    * `corporate_id`: REQUIRED/UNIQUE (text) - the corporate identifier for the compound; will be used for incremental updates unless `customer_key` is available
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `mol_hash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of `mol_file`
    * `canonical_smiles`: OPTIONAL (text) - if you have it; only used for reference
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source(_id)`: OPTIONAL FK to Source table

    """  # noqa: E501
    lookup_field_name = 'corporate_id'
    hashable_fields = {'customer_key', 'archived', 'corporate_id', 'person', 'mol_file'}
    CHILDREFS = ['lots', 'properties', 'observations', 'project_acls', 'aliases', 'poses']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate keyword arguments for the **register()** and **bulk_register()** methods. This method 
        will ensure only one Compound or Generic Entity `corporate_id` or `alias` is registered before calling
        `ArchivableModel.prep_and_validate_values() <simpleschema.html#models.ArchivableModel.prep_and_validate_values>`_.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """  # noqa: E501
        corporate_id = kwargs.get('corporate_id')
        if corporate_id:
            if GenericEntity.get_or_none(corporate_id=corporate_id, archived=0):
                raise EntityIntegrityError(f"Generic Entity {corporate_id} has already been registered")
            elif EntityAlias.get_or_none(alias=corporate_id):
                raise AliasIntegrityError(f"Alias {corporate_id} has already been registered")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'Compound':
        """Register a new compound.

        Example registration with minimum required fields:

        .. code-block:: python

            Compound.register(corporate_id='CPD123', mol_file='some mol file string')

        :param kwargs: Keyword arguments to be used to register a new compound or as search conditions for an existing
            compound
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found compound model entity exactly matching the search conditions
        """
        # NOTE: project is a hybrid_property and cannot be registered directly
        # this will return the Compound entity if it already matches the provided kwargs but try to re-register anyway
        project = kwargs.pop("project", None)
        compound = super().register(**kwargs)
        if cls.autohash and compound is not None:
            compound.molhash = generate_hash(compound.mol_file)
            compound.save()
        if project:
            CompoundProject.register(primary=True, compound=compound, project=project)
        return compound

    def register_acl(self, project: 'Project', **kwargs) -> 'CompoundProject':
        """Register an additional project acl. Please use switch_primary if you would like to swap primary
        projects instead.

        :param project: The project acl to the given compound; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A compoundproject model entity for the given compound
        """
        return CompoundProject.register(primary=False, compound=self, project=project, **kwargs)

    def register_alias(self, alias: str, **kwargs) -> 'EntityAlias':
        """Helper method to `EntityAlias.register() <simpleschema.html#models.EntityAlias.register>`_.

        :param alias: Corporate ID alias for the given compound
        :type alias: string
        :param kwargs: Keyword arguments given to EntityAlias.register() to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An entityalias model entity for the given compound
        """
        return EntityAlias.register(compound=self, alias=alias, **kwargs)

    def register_lot(self, lot_name: str = None, allow_update: bool = False, **kwargs) -> 'Lot':
        """Helper method to `Lot.register() <simpleschema.html#models.Lot.register>`_.

        :param lot_name: Lot name for the given compound
        :type lot_name: string, defaults to None
        :param allow_update: Updates existing lot if found (True) or raises IntegrityError (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to Lot.register() that are used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A lot model entity for the given compound
        """
        lot = Lot.register_or_update(compound=self, key=lot_name, **kwargs) if allow_update \
            else Lot.register(compound=self, key=lot_name, **kwargs)
        return lot

    def register_pose(self, allow_update: bool = False, **kwargs) -> 'Pose':
        """Helper method to `Pose.register() <simpleschema.html#models.Pose.register>`_.

        :param allow_update: Updates existing pose if found (True) or raises IntegrityError (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to Pose.register() that are used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A pose model entity for the given compound
        """
        pose = Pose.register_or_update(compound=self, **kwargs) if allow_update \
            else Pose.register(compound=self, **kwargs)
        return pose

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'CompoundObservation':
        """Helper method to `CompoundObservation.register() <simpleschema.html#models.CompoundObservation.register>`_.

        :param assay: Assay object or customer_key
        :type assay: string, defaults to None
        :param endpoint: The observation endpoint, also known as the assay type
        :type endpoint: string, defaults to None
        :param value: Value to assign to the observation being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to CompoundObservation.register() that are used as
            search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A compoundobservation model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value))
        return CompoundObservation.register(compound=self, assay=assay, endpoint=endpoint, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'CompoundProperty':
        """Helper method to `CompoundProperty.register() <simpleschema.html#models.CompoundProperty.register>`_.

        :param prop_name: Name of the property being recorded, corresponds to `key` field in database table
        :type prop_name: string
        :param value: Value to assign to the property being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to CompoundProperty.register() that are used as search conditions
        :return: A compoundproperty model entity for the given compound
        """
        if value:
            value_args = value_to_kwargs(value, is_property=True)
            kwargs.update(value_args)
        return CompoundProperty.register(compound=self, key=prop_name, **kwargs)

    def switch_primary(self,
                       project: Union['Project', str],
                       deregister_current: bool = False) -> Union[Project, ForeignKeyField]:
        """Switches out the current primary project with a new primary project.

        :param project: The project to use as the new primary project; can be a project name or a Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param deregister_current: Whether to deregister the current primary project after adding the new one
        :type deregister_current: bool, defaults to False
        :return: Updated compoundproject model entity for the given compound
        :rtype: compoundproject model object
        """
        # first do integrity checks on the existing primary project (self.project)
        current_primary = list(CompoundProject.select().where(
            CompoundProject.primary == True,  # noqa: E712
            CompoundProject.compound == self.id,
        ))[0]
        if project in (current_primary.project, current_primary.project.key):
            return current_primary.project
        new_primary = CompoundProject.register(compound=self, project=project, primary=False)
        current_primary.primary = False
        current_primary.save()
        new_primary.primary = True
        new_primary.save()
        if deregister_current:
            current_primary.deregister()
        return new_primary.project

    # (...project.key AS project ... JOIN CompoundProject ON primary=t
    # JOIN Project ON project.id = CompoundProject.project_id)
    @hybrid_property
    def project(self) -> Optional['Project']:
        """Hybrid property to set the primary project for a compound in the CompoundProject table.
        """
        primary = list(CompoundProject.select().where(
            CompoundProject.primary == True,  # noqa: E712
            CompoundProject.compound == self.id,
        ))
        if len(primary) == 0:
            return None
        if len(primary) > 1:
            raise PrimaryProjectIntegrityError(f"Compound {self} has more than one primary project.")
        return primary[0].project

    mol_file = TextField(**defaults(EMPTY_MOL_FILE))  # AS cd_structure - MOL or single SDF only
    corporate_id = TextField()  # AS corporate_id
    person = TextField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    molhash = CharField(index=True, null=True)  # MD5 (faster) or SHA256 (less collisions) hash of mol_file
    canonical_smiles = TextField(null=True)  # used mainly for reference
    source = ForeignKeyField(Source, null=True, backref='compounds')


Compound.add_index(Compound.corporate_id, unique=True, where=(Compound.archived == 0))
Compound.lookup_unique_condition = (Compound.archived == 0)


class CompoundProject(BaseModel):  # ld_entities_projects
    """This table contains compound project ACLs and is mapped to ld_entities_projects.

    Notes:
     - if `primary` is True, then mapping will be for `syn_compound.project`
     - else, mapping will be for `ld_compounds_projects.project`

    Lookup field name: `id`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `compound(_id)`: FOREIGN KEY to Compound table
    * `project(_id)`: FOREIGN KEY to Project table
    * `primary`: OPTIONAL (bool: False) - boolean field to indicate if primary project ACL
    * `source(_id)`: OPTIONAL FK to Source table

    """

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Ensure only one primary project is set for a compound.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        if kwargs.get("primary", False):
            primary = CompoundProject.get_or_none(primary=True, compound=kwargs.get("compound"))
            if (primary is not None and "project" in kwargs and
                    kwargs["project"] not in (primary.project, primary.project.key)):
                raise PrimaryProjectIntegrityError(f"Compound {kwargs['compound']}"
                                                   " has already been registered with a primary project."
                                                   " Use Compound.switch_primary() to change its primary project.")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'CompoundProject':
        """Register a new project ACL for a compound.

        Example registration with minimum required fields:

        .. code-block:: python

            CompoundProject.register(compound=<Compound object>, project=<Project object>)

        :param kwargs: Keyword arguments to be used to register a new compound project or as search conditions for
            an existing compound project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found compoundproject entity exactly matching the search conditions
        """
        acl = super().register(**kwargs)
        return acl

    primary = BooleanField(null=False, index=True, **defaults(False))  # join condition for compound
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='project_acls')  # AS entity_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compounds')  # project.id AS project_id
    source = ForeignKeyField(Source, null=True, backref='compound_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create unique constraints on compound + project
            (('compound', 'project'), True),)


class Document(DateFieldModel):  # syn_document (syn_observation.document_id)
    """This table contains document/notebook keys (names/identifiers) and will be mapped to syn_document (referred to by
    observation tables/syn_observation mappings).
    
    Lookup field name: `key`
    
    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for document from customer's source DB
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `key`: REQUIRED (varchar255) - document name/identifier (appears as "Notebook" in the hover-over tooltip) 
    * `source(_id)`: OPTIONAL FK to Source table

    """  # noqa: E501
    CHILDREFS = ['lot_observations', 'compound_observations', 'pages', 'generic_entity_observations',
                 'ge_lot_observations']
    hashable_fields = {'customer_key', 'archived', 'key'}
    lookup_field_name = 'key'

    @classmethod
    def register(cls, **kwargs) -> 'Document':
        """Register a new document.

        Example registration with minimum required fields:

        .. code-block:: python

            Document.register(key='some document name')

        :param kwargs: Keyword arguments to be used to register a new document or as search conditions for an existing
            document
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found document model entity exactly matching the search conditions
        """
        document = super().register(**kwargs)
        return document

    key = CharField()
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='documents')


class Page(DateFieldModel):  # syn_observation.document_page and syn_sample.document_page
    """This table contains document/notebook page keys (names/identifiers) and may be referred to by 
    syn_observation.document_page and syn_sample.document_page mappings. There is an optional FK relationship to the 
    Document table via document_id.

    Lookup field name: `key`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for document page from customer's source DB
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'archived', 'document_id'} fields in the row
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `key`: REQUIRED (text) - document page name/identifier (appears as "Notebook" in the hover-over tooltip)
    * `document_id`: OPTIONAL FK to Document table
    * `source_id`: OPTIONAL FK to Source table

    """  # noqa: E501
    CHILDREFS = ['lots', 'lot_observations', 'compound_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'document_id'}
    lookup_field_name = 'key'

    @classmethod
    def register(cls, **kwargs) -> 'Page':
        """Register a new page.

        Example registration with minimum required fields:

        .. code-block:: python

            Page.register(key='some document name')

        :param kwargs: Keyword arguments to be used to register a new page or as search conditions for an existing page
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found page model entity exactly matching the search conditions
        """
        page = super().register(**kwargs)
        return page

    key = TextField()
    document = ForeignKeyField(Document, null=True, backref='pages')
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pages')


class Lot(DateFieldModel, AclsMixin):  # syn_sample
    """This table contains lot/batch/sample details and is mapped to syn_sample.

    There is a conditional unique constraint on `(Lot.compound, Lot.key)` WHERE archived = 0.

    Lookup field name: `lot_id_full`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot from customer's source DB
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'person', 'compound', 'customer_key', 'salt', 'archived'} fields in the row
    * `key`: REQUIRED (text) - suffix of full lot ID, such as "1" of "CPD1234-1" or "02" of "CPD1234-02"; unique composite key of (`key`, `compound_id`)
    * `compound(_id)`: REQUIRED/FOREIGN KEY to Compound table; unique composite key of (`key`, `compound_id`)
    * `salt`: OPTIONAL (text) - suffix of salt name of full lot+salt ID, such as "S01" of "CPD1234-02-S01"
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `page(_id)`: OPTIONAL FK to Page table - the document/notebook page of the lot; shows up in LD under the `Notebook Page` database column.
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `lot_id_full`: REQUIRED/UNIQUE (text) - the full ID for this lot, such as "CPD1234-02" or "CPD1234-02-S01" (if you want to use the full salt ID)
    * `source(_id)`: OPTIONAL FK to Source table

    """  # noqa: E501
    lookup_field_name = 'lot_id_full'
    hashable_fields = {'customer_key', 'archived', 'compound', 'key', 'salt', 'person'}
    separator = '-'
    CHILDREFS = ['observations', 'properties', 'project_acls']

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['Lot']:
        """Bulk register lots with a list of row values. All rows must have the same fields and will be passed to
        the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        method. This operation is effectively an upsert and will use the `Lot.key` and `Lot.compound` fields and the
        WHERE `archived` = 0 condition on the unique constraint to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing the table model entities of the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'compound', 'key', 'lot_id_full', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[Lot.compound, Lot.key],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Populate lot_id_full if it is not set or, if set, ensure it matches `Compound.corporate_id` + '-' +
        `Lot.key`.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        kwargs = super().prep_and_validate_values(kwargs)
        lot_id_full = kwargs.get('lot_id_full')
        parsed_lot_id = f"{kwargs['compound'].corporate_id}{cls.separator}{kwargs['key']}"
        if lot_id_full:
            if lot_id_full != parsed_lot_id:
                raise LotIntegrityError(f"lot_id_full {kwargs['lot_id_full']} does not match parsed {parsed_lot_id}")
        else:
            kwargs['lot_id_full'] = parsed_lot_id
        return kwargs

    @classmethod
    def register(cls, **kwargs) -> 'Lot':
        """Register a lot/batch/sample for a compound.

         Example registration with minimum required fields:

         .. code-block:: python

            Lot.register(compound=Compound.register(corporate_id=CPD123, key='01'))
            Lot.register(compound=Compound.register(corporate_id=CPD123, key='01', lot_id_full='CPD123-01'))

        :param kwargs: Keyword arguments to be used to register a new lot or as search conditions for an existing lot
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found lot model entity exactly matching the search conditions
        """
        lot = super().register(**kwargs)
        return lot

    def register_acl(self, project: 'Project', **kwargs) -> 'LotProject':
        """Register a project ACL for this lot. See
        `LotProject.register() <simpleschema.html#models.LotProject.register>`_ for more details.

        :param project: The project acl for the given lot; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A lotproject model entity for the given lot
        """
        return LotProject.register(lot=self, project=project, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'LotProperty':
        """Register a property for this lot. See
        `LotProperty.register() <simpleschema.html#models.LotProperty.register>`_ for more details.

        :param prop_name: Name of the property being recorded, corresponds to `key` field in database table
        :type prop_name: string
        :param value: Value to assign to the property being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to LotProperty.register() that are used as search conditions
        :return: A lotproperty model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value, is_property=True))
        return LotProperty.register(lot=self, key=prop_name, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'LotObservation':
        """Register an observation for this lot. See
        `LotObservation.register() <simpleschema.html#models.LotObservation.register>`_ for more details.

        :param assay: Assay model object or customer_key
        :type assay: string, defaults to None
        :param endpoint: The observation endpoint, also known as the assay type
        :type endpoint: string, defaults to None
        :param value: Value to assign to the observation being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to LotObservation.register() that are used as
            search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A lotobservation model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value))
        return LotObservation.register(lot=self, assay=assay, endpoint=endpoint, **kwargs)

    @classmethod
    def upsert(cls, **kwargs) -> 'Lot':
        """
        Insert a new lot or, if there are conflicts found, update an existing lot with the provided kwargs. Note
        if None values are explicitly set in the provided kwargs then those attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'compound', 'key', 'lot_id_full', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[Lot.compound, Lot.key],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    key = TextField(index=True)  # AS lot_id; shouldn't start with V
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='lots')  # AS compound_id
    salt = TextField(null=True)  # AS salt_id (use surrogate_key)
    person = TextField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)
    page = ForeignKeyField(Page, null=True, backref='lots')  # page.key AS document_page

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    lot_id_full = TextField(null=True)
    source = ForeignKeyField(Source, null=True, backref='lots')
    # use LotProject join table if using Lot ACLs to add to ld_compounds_projects

    # The following are (optionally) used by DI but not currently implemented in SimpleSchema:
    # source_id - Shows up under the ‘Lot Source’ column (use surrogate_key).
    # alias_id - The value here shows up in the ‘Lot Alias ID’ database column.
    # data1 - Despite the column name, the value here shows up under the ‘Lot Comment’ database column.
    # amt_prepared - The amount prepared for the lot. Shows up in LD under the ‘Lot Amount’ database column.
    # appearance - The appearance of the lot. Shows up under the ‘Lot Appearance’ database column.
    # date_prepared - Values show up under the ‘Lot Date Prepared’ database column.
    # purity - Values show up in the ‘Lot Purity’ database column.
    # solubility - Shows up under the ‘Lot Solubility’ database column.
    # total_formula - Shows up under the ‘Lot Total Formula’ database column.
    # total_weight - Shows up under the ‘Lot Total Weight’ database column.


Lot.add_index(Lot.compound, Lot.key, unique=True, where=(Lot.archived == 0))
Lot.lookup_unique_condition = (Lot.archived == 0)


class LotProject(BaseModel):  # ld_compounds_projects
    """This table contains lot project ACLs and is mapped via JOIN to Compound tables to ld_compounds_projects.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `lot(_id)`: FOREIGN KEY to Lot table
    * `project(_id)`: FOREIGN KEY to Project table
    * `source(_id)`: OPTIONAL FK to Source table

    Lookup field name: `id`

    """

    @classmethod
    def register(cls, **kwargs) -> 'LotProject':
        """Register a new project ACL for a lot. Note that LiveDesign does not support lot level project ACLs so any
        lot project ACL will be mapped back to its parent compound.

        Example registration with minimum required fields:

        .. code-block:: python

            LotProject.register(compound=<Compound object>, project=<Project object>)

        :param kwargs: Keyword arguments to be used to register a new lot project or as search conditions for an
            existing lot project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found lotproject model entity exactly matching the search conditions
        """
        acl = super().register(**kwargs)
        return acl

    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='project_acls')  # lot.compound.id AS compound_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='lots')  # project.key AS project_id
    source = ForeignKeyField(Source, null=True, backref='lot_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on lot + project
            (('lot', 'project'), True),)


class Assay(DateFieldModel):  # syn_phenomenon_type and syn_observation_protocol (subset of syn_observation)
    """This table holds the assay/protocol key/name (syn_phenomenon_type.name; e.g. "A2A Binding" or
    "Calculated Properties") and version (syn_observation_protocol.version_num; e.g. "1" or "Bob's v1.7"). Depending on
    aggregation mode, one or both of these will be used for naming, aggregating, and foldering of assay columns.

    There is a conditional unique constraint on `(Assay.key, Assay.version)` WHERE `archived` = 0.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for assay/protocol/version from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'version', 'customer_key', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `key`: REQUIRED (text) - assay/protocol name; used for column naming and grouping of assays into folders; all assay endpoints will be grouped under this name
    * `version`: OPTIONAL (text: `'1'`) - assay/protocol version; displays as "Protocol" in hover-over tooltips; may be used for column naming depending on whether PROTOCOL is included in aggregation mode
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `key`

    """  # noqa: E501
    CHILDREFS = ['experiments', 'lot_observations', 'compound_observations', 'generic_entity_observations',
                 'ge_lot_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'version'}
    lookup_field_name = 'key'

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['Assay']:
        """Bulk register assays with a list of row values. All rows must have the same fields and will be passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        method. This operation is effectively an upsert and will use the `Assay.key` and `Assay.version` fields and the
        WHERE `archived` = 0 condition on the unique constraint to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing Assay table model entities corresponding to the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'version', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[Assay.key, Assay.version],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        kwargs['version'] = kwargs.get('version', '1')
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'Assay':
        """Register a new assay. Note that if `version` is unset then it will be set to the default (string) of '1'.

        Example registration with minimum required fields:

        .. code-block:: python

            Assay.register(key='My Assay')
            Assay.register(key='My Assay with explicit version', version='v2')

        :param kwargs: Keyword arguments to be used to register a new assay or as search conditions for an existing
            assay
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found assay model entity exactly matching the search conditions
        """
        assay = super().register(**kwargs)
        return assay

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False, **kwargs) -> 'AssayMetadataValue':
        """Registers an assay metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing assay metadata value if found (True) or raises IntegrityError (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to AssayMetadataValue.register() that are used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An assaymetadatavalue model entity for the given assay and key
        """
        return AssayMetadataValue.register_or_update(assay=self, key=condition, value=value, **kwargs) if allow_update \
            else AssayMetadataValue.register(assay=self, key=condition, value=value, **kwargs)

    @classmethod
    def upsert(cls, **kwargs) -> 'Assay':
        """
        Insert a new assay or, if there are conflicts found, update an existing assay with the provided kwargs. Note
        if None values are explicitly set in the provided kwargs then those attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'version', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                # The column to use for identifying row conflicts to update.
                # Uses cls.lookup_field_name attribute if it is set for the class, else will use cls.id
                conflict_target=[Assay.key, Assay.version],
                # The fields to update with the values of interest.
                # Note that EXCLUDED is a special temporary table that represents all rows that
                # conflicted -- see https://www.postgresql.org/docs/current/sql-insert.html as
                # well as http://docs.peewee-orm.com/en/latest/peewee/querying.html#bulk-inserts
                #
                # Here's what this field looks like in practice:--
                # {Compound.mol_file: EXCLUDED.mol_file, Compound.person: EXCLUDED.person, ...}
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                # if there is a condition on the unique constraint of the target lookup_field we need to provide that
                conflict_where=cls.lookup_unique_condition
            ))

    key = TextField()  # AS syn_observation_protocol.phenomenon_type_id
    version = TextField(**defaults('1'))  # AS syn_observation_protocol.version_num
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='assays')


Assay.add_index(Assay.key, Assay.version, unique=True, where=(Assay.archived == 0))
Assay.lookup_unique_condition = (Assay.archived == 0)


class Experiment(DateFieldModel):  # subset of syn_observation
    """This table contains details of an experiment (collection of observations for a particular assay on a particular
    date).

    Notes:
     - `key` field will be mapped to `primary_groupno` (falling back to `id` field)
     - `timestamp` field will be mapped to `secondary_groupno_date`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for experiment from customer's source DB
    * `assay_id`: REQUIRED FOREIGN KEY to Assay table (int)
    * `key`: OPTIONAL (text) - experiment name/identifier; if set will be used as primary grouping identifier for all observations in this experiment, otherwise will use `customer_key` (if set), otherwise `id`
    * `timestamp`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when experiment was run; will be used as secondary grouping identifier; also what’s used in adv search limited to experimental dates
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'customer_key', 'timestamp', 'archived'} fields in the row (see "Notes on Hashing" in Usage section)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `key`

    """  # noqa: E501
    CHILDREFS = ['lot_observations', 'compound_observations', 'metadata', 'generic_entity_observations',
                 'ge_lot_observations']
    hashable_fields = {'customer_key', 'archived', 'key', 'timestamp'}
    lookup_field_name = 'key'

    @classmethod
    def bulk_prep_and_validate_values(cls, rows: List[Dict]) -> List[Dict]:
        """Bulk prepare and validate all row values for **bulk_register()** method. All rows must have the same fields.
        This method will ensure that the `timestamp` field is set and if not will be set to the same utcnow() timestamp
        before passing to
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        and returning a list of all prepared and validated rows.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A prepared and validated version of the input list of dictionaries
        :rtype: list of dictionaries
        """
        now = datetime.utcnow()
        for row in rows:
            row['timestamp'] = row.get('timestamp', now)
        return super().bulk_prep_and_validate_values(rows)

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['Experiment']:
        """Bulk register experiments with a list of row values. All rows must have the same fields and will be passed to
        `Experiment.bulk_prep_and_validate_values() <simpleschema.html#models.Experiment.bulk_prep_and_validate_values>`_.
        This operation is effectively an upsert and will use the `Experiment.id` to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing Experiment table model entities corresponding to the newly updated/added rows
        """  # noqa: E501
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[Experiment.id],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update}
            ))

    @classmethod
    def register(cls, **kwargs) -> 'Experiment':
        """Register a new experiment. Note that if `key` is unset then it will be set to the default (string) of '0'.
        Observations with the same `Experiment.key` can be grouped together or appear intracell aligned in LiveDesign.
        The `Experiment.timestamp` field will default to `datetime.utcnow()` if unset; this field can also be used for
        grouping observations from the same experiment.

        Example registration with minimum required fields:

        .. code-block:: python

            Experiment.register(assay=42)
            Experiment.register(assay=42, key='My Experiment 1')
            Experiment.register(assay=42,
                                key='My Experiment 1',
                                timestamp=datetime.strptime('02/28/2023', '%m/%d/%Y'))

        :param kwargs: Keyword arguments to be used to register a new experiment or as search conditions for an existing
            experiment
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found experiment model entity exactly matching the search conditions
        """
        assay = super().register(**kwargs)
        return assay

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          assay_level: bool = False,
                          allow_update: bool = False,
                          **kwargs) -> 'ExperimentMetadataValue':
        """Registers an experiment metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param assay_level: Whether the metadata being registered is at the "assay" level (True) or "observation"
            level (False)
        :type assay_level: bool, defaults to False
        :param allow_update: Updates existing experiment metadata value if found (True) or raises IntegrityError (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ExperimentMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An experimentmetadatavalue model entity for the given experiment and key
        """
        em = ExperimentMetadataValue.register_or_update(experiment=self,
                                                        key=condition,
                                                        assay_level=assay_level,
                                                        value=value, **kwargs) \
            if allow_update else \
            ExperimentMetadataValue.register(experiment=self,
                                             key=condition,
                                             assay_level=assay_level,
                                             value=value,
                                             **kwargs)
        return em

    @classmethod
    def upsert(cls, **kwargs) -> 'Experiment':
        """
        Insert a new experiment or, if there are conflicts found, update an existing experiment with the provided
        kwargs. Note if None values are explicitly set in the provided kwargs then those attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[Experiment.id],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='experiments')
    key = TextField(null=True, **defaults('0'))  # COALESCE(key, customer_key) AS primary_groupno
    timestamp = DateTimeField(null=True, **defaults(datetime.utcnow))  # AS secondary_groupno_date
    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='experiments')


class CompoundProperty(PropertyModel):  # syn_observation
    """This table contains compound level properties (database columns) and will be mapped to syn_observation with 1 AS
    `compound_level` and 'DATA_INTEGRATED_DATABASE_COLUMN' AS `type_id`.

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for compound property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key`: REQUIRED (text) - name of the property
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `compound_id`: REQUIRED/FOREIGN KEY to Compound table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """  # noqa: E501
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='properties')  # AS observed_item_id
    source = ForeignKeyField(Source, null=True, backref='compound_properties')
    # 1 AS compound_level
    # 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id

    @classmethod
    def register(cls, **kwargs) -> 'CompoundProperty':
        """Register a new property for a compound. The `key` field will appear in LiveDesign as a column name in
        the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            CompoundProperty.register(compound_id=4, key='molarweight', num_value=42)

        :param kwargs: Keyword arguments to be used to register a new compound property or as search conditions for an
            existing compound property
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found compoundproperty model entity exactly matching the search conditions
        """
        prop = super().register(**kwargs)
        return prop


class LotProperty(PropertyModel):  # syn_observation
    """This table contains lot/batch/sample level properties (database columns) and will be mapped to syn_observation
    with 'DATA_INTEGRATED_DATABASE_COLUMN' AS `type_id`.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key`: REQUIRED (text) - name of the property
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `lot_id`: REQUIRED/FOREIGN KEY to Lot table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """  # noqa: E501
    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='properties')  # AS observed_item_id
    source = ForeignKeyField(Source, null=True, backref='lot_properties')
    # 0 AS compound_level
    # 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id

    @classmethod
    def register(cls, **kwargs) -> 'LotProperty':
        """Register a new property for a lot. The `key` field will appear in LiveDesign as a column name in
        the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            LotProperty.register(lot_id=14, key='molarweight', num_value=22)

        :param kwargs: Keyword arguments to be used to register a new lot property or as search conditions for an
            existing lot property
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found lotproperty model entity exactly matching the search conditions
        """
        prop = super().register(**kwargs)
        return prop


class LotObservation(ObservationModel):  # syn_observation
    """This table contains lot level observations and will be mapped to syn_observation.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'lot', 'text_value', 'assay', 'std_dev', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
    * `lot_id`: REQUIRED FOREIGN KEY to Lot table
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
    * `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
    * `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
    * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
    * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
    * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
    * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
    * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
    * `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
    * `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """  # noqa: E501
    hashable_fields = set(ObservationModel.hashable_fields)
    hashable_fields.add('lot')

    @classmethod
    def register(cls, **kwargs) -> 'LotObservation':
        """Register a new lot observation.

        Example registration with minimum required fields:

        .. code-block:: python

            LotObservation.register(lot_id=1, assay_id=2, experiment_id=3, endpoint='IC50')

        :param kwargs: Keyword arguments to be used to register a new lot observation or as search conditions for an
            existing lot observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found lotobservation model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_acl(self, project: 'Project', **kwargs) -> 'LotObservationProject':
        """Register a project ACL for this lot observation. See
        `LotObservationProject.register() <simpleschema.html#models.LotObservationProject.register>`_ for more details.

        :param project: The project acl for the given lot observation; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A lotobservationproject model entity for the given lot observation
        """
        return LotObservationProject.register(lot_observation=self, project=project, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'ObservationMetadataValue':
        """Registers an observation metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing observation metadata value if found (True) or raises IntegrityError
            (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ObservationMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An observationmetadatavalue model entity for the given observation and key
        """
        return ObservationMetadataValue.register_or_update(lotobservation=self, key=condition, value=value, **kwargs) \
            if allow_update else \
            ObservationMetadataValue.register(lotobservation=self, key=condition, value=value, **kwargs)

    lot = ForeignKeyField(Lot, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='lot_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='lot_observations')
    document = ForeignKeyField(Document, null=True, backref='lot_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='lot_observations')  # page.key AS document_page
    source = ForeignKeyField(Source, null=True, backref='lot_observations')


class LotObservationProject(BaseModel):  # ld_observations_projects
    """This table contains lot observation project ACLs.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `lotobservation_id`: REQUIRED FOREIGN KEY to LotObservation table (int)
    * `project_id`: REQUIRED FOREIGN KEY to Project table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """
    lot_observation = ForeignKeyField(LotObservation, on_delete='CASCADE', backref='project_acls')  # AS observation_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='lot_observation_acls')  # project.key AS project_id
    source = ForeignKeyField(Source, null=True, backref='lot_observation_acls')

    @classmethod
    def register(cls, **kwargs) -> 'LotObservationProject':
        """Register a new lot observation project.

        Example registration with minimum required fields:

        .. code-block:: python

            LotObservationProject.register(lotobservation_id=50, project_id=1)

        :param kwargs: Keyword arguments to be used to register a new lot observation project or as search conditions
            for an existing lot observation project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found lotobservationproject model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on lot observation + project
            (('lot_observation', 'project'), True),)


class CompoundObservation(ObservationModel):  # syn_observation
    """This table contains compound level observations and will be mapped to syn_observation.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for (compound) observation from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
    * `compound_id`: REQUIRED FOREIGN KEY to Compound table (int)
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
    * `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
    * `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
    * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
    * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
    * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
    * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
    * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
    * `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'`
    * `document_id`: OPTIONAL FOREGIN KEY to Document table (int)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    
    """  # noqa: E501
    hashable_fields = set(ObservationModel.hashable_fields)
    hashable_fields.add('compound')

    @classmethod
    def register(cls, **kwargs) -> 'CompoundObservation':
        """Register a new compound observation.

        Example registration with minimum required fields:

        .. code-block:: python

            CompoundObservation.register(compound_id=1, assay_id=2, experiment_id=3, endpoint='IC50')

        :param kwargs: Keyword arguments to be used to register a new compound observation or as search conditions for
            an existing compound observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found compoundobservation model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_acl(self, project: 'Project', **kwargs) -> 'CompoundObservationProject':
        """Register a project ACL for this compound observation. See
        `CompoundObservationProject.register() <simpleschema.html#models.CompoundObservationProject.register>`_
        for more details.

        :param project: The project acl for the given compound observation; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A compoundobservationproject model entity for the given compound observation
        """
        return CompoundObservationProject.register(compound_observation=self, project=project, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'ObservationMetadataValue':
        """Registers an observation metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing observation metadata value if found (True) or raises IntegrityError
            (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ObservationMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An observationmetadatavalue model entity for the given observation and key
        """
        if allow_update:
            return ObservationMetadataValue.register_or_update(compoundobservation=self,
                                                               key=condition,
                                                               value=value,
                                                               **kwargs)
        else:
            return ObservationMetadataValue.register(compoundobservation=self, key=condition, value=value, **kwargs)

    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='compound_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='compound_observations')
    document = ForeignKeyField(Document, null=True, backref='compound_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='compound_observations')  # page.key AS document_page
    source = ForeignKeyField(Source, null=True, backref='compound_observations')


class CompoundObservationProject(BaseModel):  # ld_observations_projects
    """This table contains compound observation project ACLs.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `compoundobservation_id`: REQUIRED FOREIGN KEY to CompoundObservation table (int)
    * `project_id`: REQUIRED FOREIGN KEY to Project table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """
    # compound_observation_id AS observation_id
    compound_observation = ForeignKeyField(CompoundObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compound_observation_acls')
    source = ForeignKeyField(Source, null=True, backref='compound_observation_acls')

    @classmethod
    def register(cls, **kwargs) -> 'CompoundObservationProject':
        """Register a new compound observation project.

        Example registration with minimum required fields:

        .. code-block:: python

            CompoundObservationProject.register(compoundobservation_id=40, project_id=2)

        :param kwargs: Keyword arguments to be used to register a new compound observation project or as search
            conditions for an existing compound observation project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found compoundobservationproject model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on observation + project
            (('compound_observation', 'project'), True),)


class File(DateFieldModel):  # AS ld_manageable_file and ld_data_blob
    """A table for generic entity files and mapped to ld_manageable_file and ld_data_blob.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'extension', 'person', 'project', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
    * `key`: REQUIRED (text) - filename of the file
    * `extension`: REQUIRED (text) - extension/type of the file
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `project_id`: FOREIGN KEY to Project table
    * `blob`: REQUIRED (bytea) - binary blob of file contents
    * `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `customer_key`
    """  # noqa: 501
    hashable_fields = {'customer_key', 'archived', 'key', 'extension', 'person', 'project', 'blob'}

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the File `register()` and `bulk_register()` methods. Will
        ensure `blob` and `filepath` are set and that `blob` is a bytes or memoryview type.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        blob = kwargs.get('blob')
        filepath = kwargs.pop('filepath', None)
        if sum(map(bool, [blob, filepath])) != 1:
            raise ValueError("One and only one of 'blob' or 'filepath' kwargs must be set")
        if filepath:
            file_kwargs = file_full_path_to_kwargs(filepath)
            file_kwargs.update({'key': file_kwargs.pop('filename')})
            kwargs.update(file_kwargs)
        if not isinstance(kwargs['blob'], (bytes, memoryview)):
            raise ValueError(f"blob must be bytes or memoryview type, not {type(kwargs['blob'])}")
        kwargs['extension'] = kwargs.get('extension', '').replace('.', '').upper()
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, blob: Optional[Union[bytes, memoryview]] = None, filepath: Optional[str] = None,
                 **kwargs) -> 'File':
        """Registers a file.

        Example registration with minimum required fields:

        .. code-block:: python

            File.register(key='aspirin.mol', extension='mol', blob=ASPIRIN_MOL.encode('utf-8'))

        :param blob: Contents of file being registered
        :type blob: bytes or memoryview, defaults to None
        :param filepath: Path of the file being registered
        :type filepath: string, defaults to None
        :param kwargs: Keyword arguments to be used to register a new file or as search conditions for an existing file
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found file model entity exactly matching the search conditions
        """
        kwargs.update({'blob': blob, 'filepath': filepath})
        file = super().register(**kwargs)
        if cls.autohash and file is not None:
            file.blobdigest = generate_hash(file.blob, use_sha256=True)
            file.save()
        return file

    key = TextField()  # AS file_name
    extension = TextField()  # AS file_type
    person = TextField(**defaults('LiveDesign'))  # AS registration_scientist_id (use surrogate_key)
    # project AS registration_project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='generic_entity_files')
    blob = BlobField()  # AS data_blob_id
    blobdigest = CharField(null=True)
    source = ForeignKeyField(Source, null=True, backref='generic_entity_files')


class GenericEntity(DateFieldModel, AclsMixin):  # ld_generic_entity
    """This table holds generic entity information and is mapped to ld_generic_entity. Note that `corporate_id` must 
    not match an existing entry in `EntityAlias.alias` or `GenericEntity.corporate_id`. There is a conditional unique 
    constraint on `GenericEntity.corporate_id` WHERE `archived` = 0.

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for compound from customer's source DB (required for incremental updates to include changes to `corporate_id`; see also "Notes on Hashing" on how to detect if row values have changed)
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'corporate_id', 'file_id', 'person'} fields in the row (see "Notes on Hashing" section)
    * `file_id`: OPTIONAL FOREIGN KEY to File table (int)
    * `corporate_id`: REQUIRED/UNIQUE (text) - as it says in the tin (will be used for incremental updates unless `customer_key` is available)
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `corporate_id`

    """  # noqa: 501
    lookup_field_name = 'corporate_id'
    hashable_fields = {'customer_key', 'archived', 'corporate_id', 'file', 'person'}
    CHILDREFS = ['properties', 'observations', 'project_acls', 'aliases', 'poses', 'lots', 'relationship_parents',
                 'relationship_children', 'links']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the GenericEntity `register()` and `bulk_register()` methods. Will
        ensure `corporate_id` is set and has not already been registered as a compound or entityalias.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        corporate_id = kwargs.get('corporate_id')
        if corporate_id:
            if Compound.get_or_none(corporate_id=corporate_id, archived=0):
                raise EntityIntegrityError(f"Compound {corporate_id} has already been registered")
            if EntityAlias.get_or_none(alias=corporate_id):
                raise AliasIntegrityError(f"Alias {corporate_id} has already been registered")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, corporate_id: str, file: Optional[File], **kwargs) -> 'GenericEntity':
        """Registers a generic entity and its corresponding project, if given.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntity.register(corporate_id='GEN30')

        :param corporate_id: Corporate ID associated with the generic entity being registered
        :type corporate_id: string
        :param file: File containing the generic entity being registered
        :type file: file model object
        :param kwargs: Keyword arguments to be used to register a new generic entity or as search conditions
            for an existing generic entity
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentity model entity exactly matching the search condition
        """
        kwargs['file'] = file
        kwargs['corporate_id'] = corporate_id
        project = kwargs.pop('project', None)
        generic_entity = super().register(**kwargs)
        if project is not None:
            GenericEntityProject.register(generic_entity=generic_entity, project=project, source=kwargs.get('source'))
        return generic_entity

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityProject':
        """Register a project acl for a generic entity.

        :param project: The project acl for the given generic entity; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentityproject model entity for the given generic entity
        """
        return GenericEntityProject.register(generic_entity=self, project=project, **kwargs)

    def register_alias(self, alias: str, **kwargs) -> 'EntityAlias':
        """Helper method to `EntityAlias.register() <simpleschema.html#models.EntityAlias.register>`_.

        :param alias: Corporate ID alias for the given generic entity
        :type alias: string
        :param kwargs: Keyword arguments given to EntityAlias.register() to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An entityalias model entity for the given generic entity
        """
        return EntityAlias.register(generic_entity=self, alias=alias, **kwargs)

    def register_pose(self, **kwargs) -> 'Pose':
        """Helper method to `Pose.register() <simpleschema.html#models.Pose.register>`_.

        :param kwargs: Keyword arguments given to Pose.register() that are used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A pose model entity for the given generic entity
        """
        return Pose.register(generic_entity=self, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'GenericEntityObservation':
        """Helper method to
        `GenericEntityObservation.register() <simpleschema.html#models.GenericEntityObservation.register>`_.

        :param assay: Assay model entity or customer_key
        :type assay: assay model object or string, defaults to None
        :param endpoint: The observation endpoint, also known as the assay type
        :type endpoint: string, defaults to None
        :param value: Value to assign to the observation being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to GenericEntityObservation.register() that are used as
            search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentityobservation model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value))
        return GenericEntityObservation.register(generic_entity=self, assay=assay, endpoint=endpoint, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'GenericEntityProperty':
        """Helper method to
        `GenericEntityProperty.register() <simpleschema.html#models.GenericEntityProperty.register>`_.

        :param prop_name: Name of the property being recorded, corresponds to 'key' field in database table
        :type prop_name: string
        :param value: Value to assign to the property being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to GenericEntityProperty.register() that are used as search conditions
        :return: A genericentityproperty model entity for the given generic entity
        """
        if value:
            value_args = value_to_kwargs(value, is_property=True)
            kwargs.update(value_args)
        return GenericEntityProperty.register(generic_entity=self, key=prop_name, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'EntityMetadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'EntityMetadataValue':
        """Registers a generic entity metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or EntityMetadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing entity metadata value if found (True) or raises IntegrityError (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to EntityMetadataValue.register() that are used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An entitymetadatavalue model entity for the given generic entity and key
        """
        emv = EntityMetadataValue.register_or_update(genericentity=self, key=condition, value=value, **kwargs) \
            if allow_update else EntityMetadataValue.register(genericentity=self, key=condition, value=value, **kwargs)
        return emv

    corporate_id = TextField()  # AS corporate_id
    person = TextField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)
    file = ForeignKeyField(File, on_delete='CASCADE', null=True)  # AS manageable_file_id

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entities')


GenericEntity.add_index(GenericEntity.corporate_id, unique=True, where=(GenericEntity.archived == 0))
GenericEntity.lookup_unique_condition = (GenericEntity.archived == 0)


class GenericEntityProject(BaseModel):  # ld_entities_projects
    """This table contains generic entity project ACLs and is mapped to ld_entities_projects.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `generic_entity(_id)`: FOREIGN KEY to Generic Entity table
    * `project(_id)`: FOREIGN KEY to Project table
    * `source(_id)`: OPTIONAL FK to Source table

    Lookup field name: `id`

    """

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityProject':
        """Register a new project ACL for a generic entity.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityProject.register(genericentity=<GenericEntity object>, project=<Project object>)

        :param kwargs: Keyword arguments to be used to register a new generic entity project or as search conditions
            for an existing generic entity project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentityproject model entity exactly matching the search conditions
        """
        acl = super().register(**kwargs)
        return acl

    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='project_acls')  # AS entity_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='compounds')  # project.id AS project_id
    source = ForeignKeyField(Source, null=True, backref='generic_entity_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create unique constraints on compound + project
            (('generic_entity', 'project'), True),)


class EntityAlias(BaseModel):  # ld_entity_alias
    """This table contains generic and compound entity aliases (mapped to ld_entity_alias).

    Fields in this model:

    * `alias`: PK/UNIQUE (text) - string alias of compound
    * `compound_id`: FOREIGN KEY to Compound table (int) - either compound_id or generic_entity_id should be set
    * `generic_entity_id`: FOREIGN KEY to GenericEntity table (int) - either compound_id or generic_entity_id should be set
    * `source_id`: OPTIONAL FOREIGN KEY to Source table

    Lookup field name: `alias`

    """  # noqa: 501
    lookup_field_name = 'alias'

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the EntityAlias `register()` and `bulk_register()` methods. Will
        ensure `alias` is set and has not already been registered as a `compound.corporate_id` or
        `genericentity.corporate_id`.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        alias = kwargs.get('alias')
        if alias:
            if Compound.get_or_none(corporate_id=alias, archived=0):
                raise EntityIntegrityError(f"Compound {alias} has already been registered")
            if GenericEntity.get_or_none(corporate_id=alias, archived=0):
                raise EntityIntegrityError(f"Generic Entity {alias} has already been registered")
        return super().prep_and_validate_values(kwargs)

    alias = TextField(unique=True)  # AS alias
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='aliases', null=True)  # AS entity_id
    compound = ForeignKeyField(Compound, on_delete='CASCADE', backref='aliases', null=True)  # AS entity_id
    source = ForeignKeyField(Source, null=True, backref='entity_aliases')

    @classmethod
    def register(cls, **kwargs) -> 'EntityAlias':
        """Register a new entity alias.

        Example registration with minimum required fields:

        .. code-block:: python

            EntityAlias.register(compound_id=1)
            #or
            EntityAlias.register(generic_entity_id=3)

        :param kwargs: Keyword arguments to be used to register a new entity alias or as search conditions for an
            existing entity alias
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entity alias model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [Check("num_nonnulls(generic_entity_id, compound_id) = 1", name="only_one_parent_set")]


class GenericEntityProperty(PropertyModel):  # syn_observation
    """This table contains generic entity level properties (database columns; mapped to syn_observation with
    'DATA_INTEGRATED_DATABASE_COLUMN' AS `type_id`).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key`: REQUIRED (text) - name of the property
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `generic_entity_id`: REQUIRED/FOREIGN KEY to GenericEntity table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: 501
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='properties')  # AS observed_item_id

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_properties')

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityProperty':
        """Register a new property for a generic entity. The `key` field will appear in LiveDesign as a column name in
        the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityProperty.register(generic_entity_id=6, key='molarweight', num_value=32)

        :param kwargs: Keyword arguments to be used to register a new generic entity property or as search conditions
            for an existing generic entity property
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentityproperty model entity exactly matching the search conditions
        """
        prop = super().register(**kwargs)
        return prop


class GenericEntityObservation(ObservationModel):  # syn_observation
    """This table contains generic entity level observations (mapped to syn_observation).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
    * `generic_entity_id`: REQUIRED FOREIGN KEY to GenericEntity table (int)
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
    * `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
    * `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
    * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
    * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
    * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
    * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
    * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
    * `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'` 
    * `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """  # noqa: 501
    hashable_fields = set(ObservationModel.hashable_fields)
    hashable_fields.add('generic_entity')

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityObservation':
        """Register a new generic entity observation.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityObservation.register(generic_entity_id=1, assay_id=2, experiment_id=3, endpoint='IC50')

        :param kwargs: Keyword arguments to be used to register a new generic entity observation or as search
            conditions for an existing generic entity observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentityobservation model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityObservationProject':
        """Register a project acl for a generic entity observation.

        :param project: The project acl for the given generic entity observation; can be a project name or
            Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentityobservationproject model entity for the given generic entity observation
        """
        return GenericEntityObservationProject.register(generic_entity_observation=self, project=project, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'ObservationMetadataValue':
        """Registers a generic entity observation metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing observation metadata value if found (True) or raises IntegrityError
            (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ObservationMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An observationmetadatavalue model entity for the given generic entity observation and key
        """
        return ObservationMetadataValue.register_or_update(genericentityobservation=self,
                                                           key=condition,
                                                           value=value,
                                                           **kwargs) \
            if allow_update else \
            ObservationMetadataValue.register(genericentityobservation=self, key=condition, value=value, **kwargs)

    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='generic_entity_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='generic_entity_observations')
    document = ForeignKeyField(Document, null=True, backref='generic_entity_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='generic_entity_observations')  # page.key AS document_page
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_observations')


class GenericEntityObservationProject(BaseModel):  # ld_observations_projects
    """This table contains generic entity observation project ACLs (mapped to ld_observations_projects).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `generic_entity_observation_id`: FOREIGN KEY to GenericEntityObservation table (int)
    * `project_id`: FOREIGN KEY to Project table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityObservationProject':
        """Register a new generic entity observation project.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityObservationProject.register(generic_entity_observation_id=40, project_id=2)

        :param kwargs: Keyword arguments to be used to register a new generic entity observation project or as search
            conditions for an existing generic entity observation project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentityobservationproject model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    # generic_entity_observation_id AS observation_id
    generic_entity_observation = ForeignKeyField(GenericEntityObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='generic_entity_observation_acls')
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='generic_entity_observation_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on observation + project
            (('generic_entity_observation', 'project'), True),)


class GenericEntityLot(DateFieldModel, AclsMixin):  # ld_generic_entity_lot
    """This table contains lot/batch/sample details for generic entities and is mapped to ld_generic_entity_lot. 
    GEs are not required to have lots.

    There is a conditional unique constraint on `(GenericEntityLot.generic_entity, GenericEntityLot.key)` 
    WHERE archived = 0.

    Lookup field name: `lot_id_full`

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (text) - string PK for lot from customer's source DB
    * `archived`: OPTIONAL (int2: 0) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'key', 'person', 'generic_entity', 'customer_key', 'archived'} fields in the row
    * `key`: REQUIRED (text) - suffix of full lot ID, such as "1" of "CPD1234-1" or "02" of "CPD1234-02"; unique composite key of (`key`, `generic_entity_id`)
    * `generic_entity(_id)`: REQUIRED/FOREIGN KEY to GenericEntity table; unique composite key of (`key`, `generic_entity_id`)
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `lot_id_full`: REQUIRED/UNIQUE (text) - the full ID for this lot, such as "CPD1234-02"
    * `source(_id)`: OPTIONAL FK to Source table

    """  # noqa: E501
    lookup_field_name = 'lot_id_full'
    hashable_fields = {'customer_key', 'archived', 'generic_entity', 'key', 'person'}
    separator = '-'
    CHILDREFS = ['observations', 'properties', 'project_acls']

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['GenericEntityLot']:
        """Bulk register lots with a list of row values. All rows must have the same fields and will be passed to
        the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        method. This operation is effectively an upsert and will use the `GenericEntityLot.key` and
        `GenericEntityLot.generic_entity` fields and the WHERE `archived` = 0 condition on the unique constraint
        to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing the table model entities of the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'generic_entity', 'key', 'lot_id_full', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[GenericEntityLot.generic_entity, GenericEntityLot.key],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Populate lot_id_full if it is not set or, if set, ensure it matches `GenericEntity.corporate_id` + '-' +
        `GenericEntityLot.key`.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        kwargs = super().prep_and_validate_values(kwargs)
        lot_id_full = kwargs.get('lot_id_full')
        parsed_lot_id = f"{kwargs['generic_entity'].corporate_id}{cls.separator}{kwargs['key']}"
        if lot_id_full:
            if lot_id_full != parsed_lot_id:
                raise LotIntegrityError(f"lot_id_full {kwargs['lot_id_full']} does not match parsed {parsed_lot_id}")
        else:
            kwargs['lot_id_full'] = parsed_lot_id
        return kwargs

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLot':
        """Register a lot/batch/sample for a generic entity.

         Example registration with minimum required fields:

         .. code-block:: python

            GenericEntityLot.register(generic_entity=GenericEntity.register(corporate_id='GE38'),
                                      key='1',
                                      lot_id_full='GE38-1')
            GenericEntityLot.register(generic_entity=GenericEntity.register(corporate_id='GE38'), key='2')

        :param kwargs: Keyword arguments to be used to register a new generic entity lot or as search conditions for an
            existing lot
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found generic entity lot model entity exactly matching the search conditions
        """
        generic_entity_lot = super().register(**kwargs)
        return generic_entity_lot

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityLotProject':
        """Register a project ACL for this lot. See
        `GenericEntityLotProject.register() <simpleschema.html#models.GenericEntityLotProject.register>`_
        for more details.

        :param project: The project acl for the given lot; can be a project name or Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentitylotproject model entity for the given lot
        """
        return GenericEntityLotProject.register(lot=self, project=project, **kwargs)

    def register_property(self,
                          prop_name: str,
                          value: Union[str, int, float, 'datetime'] = None,
                          **kwargs) -> 'GenericEntityLotProperty':
        """Register a property for this lot. See
        GenericEntityLotProperty.register() <simpleschema.html#models.GenericEntityLotProperty.register>`_
        for more details.

        :param prop_name: Name of the property being recorded, corresponds to `key` field in database table
        :type prop_name: string
        :param value: Value to assign to the property being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to GenericEntityLotProperty.register() that are used as search conditions
        :return: A genericentitylotproperty model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value, is_property=True))
        return GenericEntityLotProperty.register(lot=self, key=prop_name, **kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime']] = None,
                             **kwargs) -> 'GenericEntityLotObservation':
        """Register an observation for this lot. See
        `GenericEntityLotObservation.register() <simpleschema.html#models.GenericEntityLotObservation.register>`_
        for more details.

        :param assay: Assay model object or customer_key
        :type assay: string, defaults to None
        :param endpoint: The observation endpoint, also known as the assay type
        :type endpoint: string, defaults to None
        :param value: Value to assign to the observation being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float or datetime object; defaults to None
        :param kwargs: Keyword arguments given to GenericEntityLotObservation.register() that are used as
            search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentitylotobservation model entity for the given compound
        """
        if value:
            kwargs.update(value_to_kwargs(value))
        return GenericEntityLotObservation.register(lot=self, assay=assay, endpoint=endpoint, **kwargs)

    @classmethod
    def upsert(cls, **kwargs) -> 'GenericEntityLot':
        """
        Insert a new lot or, if there are conflicts found, update an existing lot with the provided
        kwargs. Note if None values are explicitly set in the provided kwargs then those attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'generic_entity', 'key', 'lot_id_full', 'created_at']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[GenericEntityLot.generic_entity, GenericEntityLot.key],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    key = TextField(index=True)  # AS lot_id; shouldn't start with V
    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='lots')  # AS generic_entity_id
    person = TextField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    lot_id_full = TextField(null=True)
    source = ForeignKeyField(Source, null=True, backref='ge_lots')


GenericEntityLot.add_index(GenericEntityLot.generic_entity, GenericEntityLot.key,
                           unique=True,
                           where=(GenericEntityLot.archived == 0))
GenericEntityLot.lookup_unique_condition = (GenericEntityLot.archived == 0)


class GenericEntityLotProject(BaseModel):  # ld_entities_projects
    """This table contains generic entity lot project ACLs.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `lot(_id)`: FOREIGN KEY to GenericEntityLot table
    * `project(_id)`: FOREIGN KEY to Project table
    * `source(_id)`: OPTIONAL FK to Source table

    Lookup field name: `id`

    """

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLotProject':
        """Register a new project ACL for a generic entity lot. Note that LiveDesign does not support lot level project
        ACLs so any lot project ACL will be mapped back to its parent entity.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityLotProject.register(lot=GenericEntityLot.register(generic_entity=ge39, key='1'),
                                            project=Project.register(key='Global', is_restricted=0))

        :param kwargs: Keyword arguments to be used to register a new lot project or as search conditions for an
            existing lot project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentitylotproject model entity exactly matching the search conditions
        """
        acl = super().register(**kwargs)
        return acl

    # GenericEntityLot.generic_entity.id AS generic_entity_id
    lot = ForeignKeyField(GenericEntityLot, on_delete='CASCADE', backref='project_acls')
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='ge_lots')  # project.key AS project_id
    source = ForeignKeyField(Source, null=True, backref='ge_lot_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicitly set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on lot + project
            (('lot', 'project'), True),)


class GenericEntityLotProperty(PropertyModel):  # syn_observation
    """This table contains lot/batch/sample level properties (database columns) and will be mapped to syn_observation
    with 'DATA_INTEGRATED_DATABASE_COLUMN' AS `type_id`.
    """
    lot = ForeignKeyField(GenericEntityLot, on_delete='CASCADE', backref='properties')  # AS observed_item_id
    source = ForeignKeyField(Source, null=True, backref='ge_lot_properties')
    # 0 AS compound_level
    # 'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLotProperty':
        """Register a new property for a generic entity lot. The `key` field will appear in LiveDesign as a column name
        in the "Other Columns" section of the Data & Columns tree. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityLotProperty.register(lot=GenericEntityLot.register(generic_entity_id=7, key='1'),
                                              key='ALPHANUMERIC',
                                              num_value=200)
            GenericEntityLotProperty.register(lot_id=27, key='DATE', date_value='2020-02-02')

        :param kwargs: Keyword arguments to be used to register a new lot property or as search conditions for an
            existing lot property
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentitylotproperty model entity exactly matching the search conditions
        """
        prop = super().register(**kwargs)
        return prop


class GenericEntityLotObservation(ObservationModel):  # syn_observation
    """This table contains lot level observations and will be mapped to syn_observation.
    """
    hashable_fields = set(ObservationModel.hashable_fields)
    hashable_fields.add('lot')

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLotObservation':
        """Register a new generic entity lot observation.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityLotObservation.register(lot_id=1, assay_id=2, experiment_id=3, endpoint='IC50')

        :param kwargs: Keyword arguments to be used to register a new lot observation or as search conditions for an
            existing lot observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentitylotobservation model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_acl(self, project: 'Project', **kwargs) -> 'GenericEntityLotObservationProject':
        """Register a project ACL for this generic entity lot observation. See `GenericEntityLotObservationProject.register() <simpleschema.html#models.GenericEntityLotObservationProject.register>`_ for more details.

        :param project: The project acl for the given generic entity lot observation; can be a project name or Project
            instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A genericentitylotobservationproject model entity for the given lot observation
        """  # noqa: E501
        return GenericEntityLotObservationProject.register(lot_observation=self, project=project, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'ObservationMetadataValue':
        """Registers an observation metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing observation metadata value if found (True) or raises IntegrityError
            (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ObservationMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An observationmetadatavalue model entity for the given observation and key
        """
        return ObservationMetadataValue.register_or_update(lotobservation=self, key=condition, value=value, **kwargs) \
            if allow_update else \
            ObservationMetadataValue.register(lotobservation=self, key=condition, value=value, **kwargs)

    lot = ForeignKeyField(GenericEntityLot, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='ge_lot_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='ge_lot_observations')
    document = ForeignKeyField(Document, null=True, backref='ge_lot_observations')  # AS document_id
    source = ForeignKeyField(Source, null=True, backref='ge_lot_observations')


class GenericEntityLotObservationProject(BaseModel):  # ld_observations_projects
    """This table contains generic entity lot observation project ACLs.
    """
    # AS observation_id
    lot_observation = ForeignKeyField(GenericEntityLotObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='ge_lot_observation_acls')
    source = ForeignKeyField(Source, null=True, backref='ge_lot_observation_acls')

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLotObservationProject':
        """Register a new generic entity lot observation project.

        Example registration with minimum required fields:

        .. code-block:: python

            GenericEntityLotObservationProject.register(lotobservation_id=50, project_id=1)

        :param kwargs: Keyword arguments to be used to register a new lot observation project or as search conditions
            for an existing lot observation project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentitylotobservationproject model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on lot observation + project
            (('lot_observation', 'project'), True),)


class Structure(DateFieldModel):  # ld_structure and ld_structure_data and ld_data_blob
    """This table is for representing structures for 3D assays (mapped to ld_structure, ld_structure_data, and
    ld_data_blob). The records here must be referenced by an observation table for the data to show up in LD.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'key', 'type', 'format', 'blob'} fields in the row (see "Notes on Hashing" in Usage section)
    * `key`: REQUIRED (text) - the name of the structure to shows up in the 3D visualizer
    * `type`: REQUIRED (text) - the type of the 3D structure; must be one of ('LIGAND', 'PROTEIN', 'OTHER', 'ANIMATION')
    * `format`: REQUIRED (text) - extension/type of the file; must be one of ('PSE', 'MAE', 'MAEGZ', 'VIB')
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `blob`: REQUIRED (bytea) - binary blob of file contents
    * `blobdigest`: OPTIONAL (varchar255) - MD5 or SHA256 (recommended) hash of `blob` field
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`

    """  # noqa: E501
    hashable_fields = {'customer_key', 'archived', 'key', 'type', 'format', 'blob'}
    allowed_structure_types = ('LIGAND', 'PROTEIN', 'OTHER', 'ANIMATION')
    allowed_structure_formats = ('PSE', 'MAE', 'MAEGZ', 'VIB')

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the Structure `register()` and `bulk_register()` methods. Will
        ensure `blob` and `filepath` are set and that `blob` is a bytes or memoryview type.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        blob = kwargs.get('blob')
        filepath = kwargs.pop('filepath', None)
        if sum(map(bool, [blob, filepath])) != 1:
            raise ValueError("One and only one of 'blob' or 'filepath' kwargs must be set")
        if filepath:
            file_kwargs = file_full_path_to_kwargs(filepath)
            filename = file_kwargs.pop('filename')
            if not kwargs.get('key'):
                file_kwargs['key'] = filename
            file_kwargs['format'] = file_kwargs.pop('extension')
            kwargs.update(file_kwargs)
        if not isinstance(kwargs['blob'], (bytes, memoryview)):
            raise ValueError(f"blob must be bytes or memoryview type, not {type(kwargs['blob'])}")
        kwargs['type'] = kwargs.get('type', '').upper()
        kwargs['format'] = kwargs.get('format', '').replace('.', '').upper()
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, blob: Optional[Union[bytes, memoryview]] = None, filepath: Optional[str] = None,
                 **kwargs) -> 'Structure':
        """Registers a structure.

         Example registration with minimum required fields:

        .. code-block:: python

            Structure.register(key='aspirin.maegz', type='ligand', format='maegz', blob=ASPIRIN_MAEGZ)

        :param blob: Contents of structure file being registered
        :type blob: bytes or memoryview, defaults to None
        :param filepath: Path of the structure file being registered
        :type filepath: string, defaults to None
        :param kwargs: Keyword arguments to be used to register a new structure or as search conditions for
            an existing structure
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found structure model entity exactly matching the search conditions
        """
        kwargs.update({'blob': blob, 'filepath': filepath})
        structure = super().register(**kwargs)
        if cls.autohash and structure is not None:
            structure.blobdigest = generate_hash(structure.blob, use_sha256=True)
            structure.save()
        return structure

    key = TextField()  # the name of the structure to shows up in the 3D visualizer
    type = TextField(constraints=[Check(f"type IN {allowed_structure_types}",
                                        name="structure_allowed_type")])  # the type of the 3D structure
    format = TextField(constraints=[Check(f"format IN {allowed_structure_formats}",
                                          name="structure_allowed_format")])  # the type/extension of the file
    blob = BlobField()  # references the binary content of the data
    blobdigest = CharField(null=True)

    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='structures')


class Pose(DateFieldModel):  # ld_pose
    """This table is for representing poses in LiveDesign (mapped to ld_pose). Pose records must be created if you want
    to create pose-level data in an observation table. Different poses show up as different rows in row-per-pose mode.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'customer_key', 'archived', 'compound', 'generic_entity', 'key', 'person'} fields in the row (see "Notes on Hashing" in Usage section)
    * `compound_id`: OPTIONAL FOREIGN KEY to Compound table (int) - one of `compound_id` or `generic_entity_id` must be set
    * `generic_entity_id`: OPTIONAL FOREIGN KEY to GenericEntity table (int) - one of `compound_id` or `generice_entity_id` must be set
    * `key`: REQUIRED (text) - suffix of full pose ID, such as "1" of "CPD1234#1" or "02" of "GEN1234#02" 
    * `pose_id_full`: REQUIRED/UNIQUE (text) - the full ID for this pose, such as "CPD1234#1" or "GEN1234#02"
    * `person`: OPTIONAL (text: `'LiveDesign'`) - LD person to associate with the upload (should be in `ld_user` or will be created)
    * `project_id`: OPTIONAL FOREIGN KEY to Project table (int) - the project associated with the pose; no user effect right now
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `pose_id_full`
    """  # noqa: E501
    lookup_field_name = 'pose_id_full'
    hashable_fields = {'customer_key', 'archived', 'compound', 'generic_entity', 'key', 'person'}
    separator = '#'
    CHILDREFS = ['observations']

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the Pose `register()` and `bulk_register()` methods. Populate pose_id_full
        if it is not set or, if set, ensure it matches `Compound.corporate_id` + '-' + `Pose.key` (for compound poses)
        OR `GenericEntity.corporate_id` + '-' + `Pose.key` (for generic entity poses).

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        kwargs = super().prep_and_validate_values(kwargs)
        key = kwargs.get('key') or '1'
        pose_id_full = kwargs.get('pose_id_full')
        parent = kwargs.get('compound') or kwargs.get('generic_entity')
        parsed_pose_id = f"{parent.corporate_id}{cls.separator}{key}"
        if pose_id_full:
            if pose_id_full != parsed_pose_id:
                raise IntegrityError(f"pose_id_full {kwargs['pose_id_full']} does not match parsed {parsed_pose_id}")
        else:
            kwargs['pose_id_full'] = parsed_pose_id
        return kwargs

    @classmethod
    def register(cls, **kwargs) -> 'Pose':
        """Register a new pose.

        Example registration with minimum required fields:

        .. code-block:: python

            Pose.register(key="1", pose_id_full="CPD1234#1")

        :param kwargs: Keyword arguments to be used to register a new pose or as search conditions for an existing pose
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found pose model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_observation(self,
                             assay: Union['Assay', str] = None,
                             endpoint: str = None,
                             value: Optional[Union[str, int, float, 'datetime', Structure]] = None,
                             **kwargs) -> 'PoseObservation':
        """Helper method to `PoseObservation.register() <simpleschema.html#models.PoseObservation.register>`_.

        :param assay: Assay model entity or customer_key
        :type assay: assay model object or string, defaults to None
        :param endpoint: The observation endpoint, also known as the assay type
        :type endpoint: string, defaults to None
        :param value: Value to assign to the observation being recorded (if not using num_value, text_value
            or date_value); if set, will be parsed with value_to_kwargs()
        :type value: string, integer, float, datetime object or structure model object; defaults to None
        :param kwargs: Keyword arguments given to PoseObservation.register() that are used as search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A poseobservation model entity for the given pose
        """
        if value is not None:
            kwargs.update(value_to_kwargs(value, is_pose=True))
        return PoseObservation.register(pose=self, assay=assay, endpoint=endpoint, **kwargs)

    generic_entity = ForeignKeyField(GenericEntity, null=True, backref='poses')  # AS parent_entity_id
    compound = ForeignKeyField(Compound, null=True, backref='poses')  # AS parent_entity_id
    project = ForeignKeyField(Project, null=True, backref='poses')  # AS project_id; No user facing effect right now
    person = TextField(**defaults('LiveDesign'))  # AS person_id (use surrogate_key)

    # The following are not used by DI but may be useful for SimpleSchema ETL implementations
    key = TextField(index=True)
    pose_id_full = TextField(unique=True)
    source = ForeignKeyField(Source, null=True, backref='poses')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [Check("num_nonnulls(generic_entity_id, compound_id) = 1", name="only_one_parent_set")]


class PoseObservation(ObservationModel):  # syn_observation
    """This table contains pose level observations (mapped to syn_observation).

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for (compound) observation from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `rowhash`: OPTIONAL (varchar255) - MD5 or SHA256 hash of an ordered dict of {'document', 'value_operator', 'text_value', 'assay', 'std_dev', 'compound', 'unit', 'experiment', 'conc', 'conc_unit', 'num_value', 'page', 'archived', 'date_value', 'customer_key', 'endpoint'} fields in the row (see "Notes on Hashing" in Usage section)
    * `pose_id`: REQUIRED FOREIGN KEY to Pose table
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `structure_id`: OPTIONAL/UNIQUE FOREIGN KEY to Structure table (int) - structure value for the property (only one value should be set)
    * `assay_id`: REQUIRED FOREIGN KEY to Assay table (int) - provides assay/protocol name and version
    * `experiment_id`: REQUIRED FOREIGN KEY to Experiment table (int) - provides primary group_no and secondary group_date; if unset then primary_group_no will be set to `'0'` and secondary_group_no will be set to `NOW()`
    * `endpoint`: REQUIRED (text) - the assay "type"; will be used to name the column; can have multiple endpoint columns (e.g. "IC50", "Ki", "% Inhib") per assay name (e.g. "Binding at Foo)
    * `std_dev`: OPTIONAL (double) - standard deviation of the observation value
    * `value_operator`: OPTIONAL (varchar255) - if your numerical value has >, <, <=, >=, or = operator in front of it, or + or ++ operator behind it, strip it out, put the operator here and the number in `num_value`
    * `conc`: OPTIONAL (double) - concentration of the assay value; shows up as ‘concentration’ in hover-over tooltips
    * `conc_unit`: OPTIONAL (varchar255) - units of the concentration (e.g. "nM", "uM", "%")
    * `unit`: OPTIONAL (varchar255) - units of the results (e.g. "nM", "uM", "%")
    * `page_id`: OPTIONAL FOREIGN KEY to Page table (int) - if unset then document_page will be set to `'0'` 
    * `document_id`: OPTIONAL FOREIGN KEY to Document table (int)
    * `created_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was created/registered
    * `modified_at`: OPTIONAL (timestamp without timezone: `(now() at time zone 'utc')`) - timestamp of when record was last modified
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: E501
    hashable_fields = set(ObservationModel.hashable_fields)
    hashable_fields.add('pose')
    allowed_value_kwargs = list(ObservationModel.allowed_value_kwargs) + ['structure']

    @classmethod
    def register(cls, **kwargs) -> 'PoseObservation':
        """Register a new pose observation.

        Example registration with minimum required fields:

        .. code-block:: python

            PoseObservation.register(pose_id=1, assay_id=2, experiment_id=3, endpoint='IC50')

        :param kwargs: Keyword arguments to be used to register a new pose observation or as search conditions for an
            existing pose observation
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found poseobservation model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    def register_acl(self, project: 'Project', **kwargs) -> 'PoseObservationProject':
        """Register a project acl for a pose observation.

        :param project: The project acl for the given pose observation; can be a project name or
            Project instance
        :type project: string or Project model class instance, defaults to 'Project'
        :param kwargs: Keyword arguments to be used as the search conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: A poseobservationproject model entity for the given pose observation
        """
        return PoseObservationProject.register(pose_observation=self, project=project, **kwargs)

    def register_metadata(self,
                          condition: Union[str, 'Metadata'] = None,
                          value: Optional[Union[str, int, float, 'datetime']] = None,
                          allow_update: bool = False,
                          **kwargs) -> 'ObservationMetadataValue':
        """Registers an observation metadata key, value pair.

        :param condition: Category/type of metadata being registered
        :type condition: string or Metadata model object, defaults to None
        :param value: Value of metadata being registered
        :type value: string, integer, float or datetime object; defaults to None
        :param allow_update: Updates existing observation metadata value if found (True) or raises IntegrityError
            (False)
        :type allow_update: bool, defaults to False
        :param kwargs: Keyword arguments given to ObservationMetadataValue.register() that are used as the search
            conditions
        :type kwargs: comma separated keyword arguments, column name = value
        :return: An observationmetadatavalue model entity for the given observation and key
        """
        return ObservationMetadataValue.register_or_update(poseobservation=self, key=condition, value=value, **kwargs) \
            if allow_update else \
            ObservationMetadataValue.register(poseobservation=self, key=condition, value=value, **kwargs)

    pose = ForeignKeyField(Pose, on_delete='CASCADE', backref='observations')  # AS observed_item_id
    # experiment FK relationship yields: assay.key (name), assay.version, primary_groupno, and secondary_groupno_date
    structure = ForeignKeyField(Structure, null=True, unique=True, backref='pose_observations')
    assay = ForeignKeyField(Assay, on_delete='CASCADE', backref='pose_observations')
    experiment = ForeignKeyField(Experiment, null=True, backref='pose_observations')
    document = ForeignKeyField(Document, null=True, backref='pose_observations')  # AS document_id
    page = ForeignKeyField(Page, null=True, backref='pose_observations')  # page.key AS document_page
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pose_observations')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value, structure_id) = 1",
                  name="only_one_pose_observation_value"),
            Check(f"value_operator IN {ALLOWED_OPERATORS}", name="observation_allowed_operators")
        ]


class PoseObservationProject(BaseModel):  # ld_observations_projects
    """This table contains pose observation project ACLs (mapped to ld_observations_projects).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `pose_observation_id`: FOREIGN KEY to PoseObservation table (int)
    * `project_id`: FOREIGN KEY to Project table (int)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """

    @classmethod
    def register(cls, **kwargs) -> 'PoseObservationProject':
        """Register a new pose observation project.

        Example registration with minimum required fields:

        .. code-block:: python

            PoseObservationProject.register(pose_observation_id=50, project_id=1)

        :param kwargs: Keyword arguments to be used to register a new pose observation project or as search conditions
            for an existing pose observation project
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found poseobservationproject model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    # pose_observation_id AS observation_id
    pose_observation = ForeignKeyField(PoseObservation, on_delete='CASCADE', backref='project_acls')
    # project.key AS project_id
    project = ForeignKeyField(Project, on_delete='CASCADE', backref='pose_observation_acls')
    # The following is not used by DI but may be useful for SimpleSchema ETL implementations
    source = ForeignKeyField(Source, null=True, backref='pose_observation_acls')

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on observation + project
            (('pose_observation', 'project'), True),)


class EntityMetadata(BaseModel):  # ld_entity_metadata
    """This table contains names (keys), folder path, and value types for metadata for generic entities, which is
    strongly preferred over the GenericEntityProperty table. Small molecule entities (compounds) should continue to use
    the CompoundProperty table.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `key`: REQUIRED/UNIQUE (text) - the name of the metadata
    * `folder_path`: OPTIONAL (text) - name of the folder that the metadata should appear under. All entity metadata will appear under "Other Columns/Entity Metadata". An empty string will put the column into "Other Columns/Entity Metadata" tree. Use "/" as delimiter for subfolders.
    * `value_type`: REQUIRED (varchar255: `'STRING'`) - value type of the metadata column. Must be one of:  INTEGER, FLOAT, STRING, DATE, DATETIME; defaults to 'STRING'.
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `key`
    """  # noqa: E501
    lookup_field_name = 'key'

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the EntityMetadata `register()` and `bulk_register()` methods. Will ensure
        `value_type` is set correctly and check whether an existing `EntityMetadata.key` exists and, if so, whether it
        has a matching `value_type` set.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        key = kwargs.get('key')
        value_type = kwargs.get('value_type')
        if value_type and not isinstance(value_type, str):
            raise ValueError("value_type must be a string")
        value_type = value_type.upper() if value_type else 'STRING'
        if value_type not in ALLOWED_VALUE_TYPES:
            msg = f"value_type must be one of {ALLOWED_VALUE_TYPES}"
            raise MetadataValueTypeException(msg)
        existing_key = EntityMetadata.get_or_none(key=key)
        if existing_key and existing_key.value_type != value_type:
            msg = f"Entity Metadata with key {key} already registered with value type {existing_key.value_type}"
            raise MetadataValueTypeException(msg)
        kwargs['value_type'] = value_type
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'EntityMetadata':
        """Register a new metadata key for a generic entity. The `key` field will appear in LiveDesign as a column name
        in the "Other Columns" section of the Data & Columns tree with a folder/path specified in the `folder_path`
        field. Note that the metadata `value_type` field must be one of:  'INTEGER', 'FLOAT', 'STRING', 'DATE', or
        'DATETIME' and defaults to 'STRING'. There is a unique constraint on the metadata `key` field.

        Example registration with minimum required fields:

        .. code-block:: python

            EntityMetadata.register(key='My Metadata', value_type='STRING')

        :param kwargs: Keyword arguments to be used to register a generic entity metadata key or as search conditions
            for an existing metadata key
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entitymetadata model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    key = TextField(unique=True)  # AS name
    folder_path = TextField(null=True)  # AS folder_path; use / to designate subfolders
    value_type = CharField(**defaults('STRING'))  # AS value_type; must be one of INTEGER, FLOAT, STRING, DATE, DATETIME

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [Check(f"UPPER(value_type) IN {ALLOWED_VALUE_TYPES}", name="metadata_allowed_value_types")]


class EntityMetadataValue(PropertyModel):  # ld_entity_metadata_value
    """This table contains metadata values for a generic entity. Only one value can be recorded for a genericentity_id -
    key_id pair; there is a unique constraint on `(genericentity_id, key_id)`. Only one value
    can be set (but all can be set to null).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `genericentity_id`: REQUIRED/FOREIGN KEY to GenericEntity table (int)
    * `key_id`: REQUIRED/FOREIGN KEY to EntityMetadata table (int)
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: E501

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['EntityMetadataValue']:
        """Bulk register entity metadata values with a list of row values. All rows must have the same fields and will
        be passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        method. This operation is effectively an upsert and will  use the `EntityMetadataValue.key`
        and `EntityMetadataValue.genericentity` fields to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing EntityMetadataValue table model entities corresponding to the newly updated/added
            rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'genericentity']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[EntityMetadataValue.key, EntityMetadataValue.genericentity],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update}
            ))

    @classmethod
    def get_value_type(cls, kwargs) -> str:
        """Tries to type the provided value as either 'STRING', 'FLOAT', 'INTEGER', 'DATE', or 'DATETIME'.

        :param kwargs: Dictionary of keyword arguments
        :type kwargs: dictionary
        :return: Type of value
        :rtype: string
        """
        num_as_float = kwargs.get('num_as_float', True)
        show_time_component = kwargs.get('show_time_component', True)
        if kwargs.get('text_value'):
            return 'STRING'
        if kwargs.get('num_value'):
            return 'FLOAT' if num_as_float else 'INTEGER'
        if kwargs.get('date_value'):
            return 'DATETIME' if show_time_component else 'DATE'
        return ''

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the EntityMetadataValue `register()` and `bulk_register()` methods. Will
        ensure `value` is set and that `value_type` is set or will try to infer it using the `get_type()` method. Will
        also check whether an existing `EntityMetadata.key` exists and, if so, whether it has a matching `value_type`
        set.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        metadatakey = kwargs.get('key')
        if not metadatakey:
            raise ValueError("key must be set")
        if kwargs.get('value'):
            value = kwargs.pop('value')
            kwargs.update(value_to_kwargs(value, is_property=True))
        value_type = kwargs.get('value_type', cls.get_value_type(kwargs))
        if isinstance(metadatakey, str):
            if not value_type:
                metadatakey = EntityMetadata.get_or_none(key=metadatakey)
                if not metadatakey:
                    metadatakey = EntityMetadata.register(key=metadatakey, value_type='STRING')
            else:
                metadatakey = EntityMetadata.register(key=metadatakey, value_type=value_type)
            kwargs['key'] = metadatakey
        elif isinstance(metadatakey, EntityMetadata):
            if metadatakey.value_type != value_type:
                msg = f"Metadata '{metadatakey.key}' has mismatching value_type '{metadatakey.value_type}'"
                raise MetadataValueTypeException(msg)
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'EntityMetadataValue':
        """Register a new metadata value for a generic entity. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set.

        Example registration with minimum required fields:

        .. code-block:: python

            EntityMetadataValue.register(key_id=2, genericentity_id=6, num_value=32)

        :param kwargs: Keyword arguments to be used to register a new generic entity metadata value or as search
            conditions for an existing generic entity metadata value
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entitymetadatavalue model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    @classmethod
    def upsert(cls, **kwargs) -> 'EntityMetadataValue':
        """
        Insert a new entity metadata value or, if there are conflicts found, update an existing entity metadata value
        with the provided kwargs. Note if None values are explicitly set in the provided kwargs then those attributes
        will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'genericentity']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[EntityMetadataValue.key, EntityMetadataValue.genericentity],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    key = ForeignKeyField(EntityMetadata)  # key_id AS entity_metadata_id
    genericentity = ForeignKeyField(GenericEntity)  # AS observed_item_id

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value) <= 1",
                  name="only_one_or_none_entitymetadata_value"),
        ]
        indexes = (
            # create a unique on key + genericentity
            (('key_id', 'genericentity_id'), True),)


class Metadata(BaseModel):  # ld_assay_metadata_key
    """This table contains keys for assay or observation metadata. A name (key) can only be recorded once
    for a metadata level. The table enforces a unique constraint on `(key, assay_level)`.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `key`: REQUIRED/UNIQUE (text) - the name of the metadata
    * `assay_level`: OPTIONAL (bool: `true`) - boolean field to indicate metadata level for which the key is used;
        true = ASSAY, false = OBSERVATION.

    Lookup field name: `key`

    """
    lookup_field_name = 'key'

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['Metadata']:
        """Bulk register metadata keys with a list of row values. All rows must have the same fields and will be passed
        to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_.
        If there are any conflicts due to existing rows with the same `Metadata.key`, `Metadata.assay_level` they will
        be ignored/skipped.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing Metadata table model entities of corresponding to the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        return list(cls.insert_many(prepared_rows).returning(cls).on_conflict_ignore())

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the Metadata `register()` and `bulk_register()` methods. Will ensure
        `assay_level` is set, defaulting to `True` if not set. Will also check whether an existing `Metadata.key`
        exists and, if so, whether it has a matching `assay_level` set.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        key = kwargs.get('key')
        level = kwargs.get('assay_level', True)
        existing_key = Metadata.get_or_none(key=key)
        if existing_key and existing_key.assay_level != level:
            text_level = 'ASSAY' if existing_key.assay_level else 'OBSERVATION'
            raise MetadataLevelException(f"AssayMetaData key '{key}' already exists with '{text_level}' metadata level")
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'Metadata':
        """Register a new assay or observation metadata key. The `key` field will appear in LiveDesign as a tooltip
        when hovering over an observation value. Setting `assay_value` to `True` will associate the metadata at the
        Assay level (and for all observations of that assay protocol); setting `assay_value` to `False` will associate
        the metadata at the Observation level.

        Example registration with minimum required fields:

        .. code-block:: python

            Metadata.register(key='color')
            Metadata.register(key='color', assay_level=False)

        :param kwargs: Keyword arguments to be used to register an assay or observation metadata key or as search
            conditions for an existing metadata key
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found metadata model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    @classmethod
    def upsert(cls, **kwargs) -> None:
        """
        Upserts for metadata keys are not supported at this time.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: None
        """
        return None

    key = TextField()  # AS name; the name of the metadata key
    assay_level = BooleanField(**defaults(True))  # AS metadata_level; True = 'ASSAY', False = 'OBSERVATION'

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create a unique on key + assay_level
            (('key', 'assay_level'), True),)


class AssayMetadataValue(PropertyModel):  # ld_assay_metadata
    """This table contains metadata values for an assay. The `assaymetadatakey.assay_level` must be True. Only one
    value can  be recorded for an assay_id - key_id pair; there is a unique constraint on `(assay_id, key_id)`. Only
    one value can be set (but all can be set to null).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
    * `assay_id`: REQUIRED/FOREIGN KEY to Assay table (int)
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: E501

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['AssayMetadataValue']:
        """Bulk register assay metadata values with a list of row values. All rows must have the same fields and will be
        passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_.
        This operation is effectively an upsert and will use the `AssayMetadataValue.key` and
        `AssayMetadataValue.assay` fields to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing AssayMetadataValue table model entities corresponding to the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'assay']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[AssayMetadataValue.key, AssayMetadataValue.assay],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update}
            ))

    @classmethod
    def upsert(cls, **kwargs) -> 'AssayMetadataValue':
        """
        Insert a new assay metadata value or, if there are conflicts found, update an existing assay metadata value
        with the provided kwargs. Note if None values are explicitly set in the provided kwargs then those attributes
        will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'assay']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[AssayMetadataValue.key, AssayMetadataValue.assay],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the AssayMetadataValue `register()` and `bulk_register()` methods. Will
        ensure `key` is set and the `Metadata.assay_level` is set appropriately.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        metadatakey = kwargs.get('key')
        if not metadatakey:
            raise ValueError("key must be set")
        if isinstance(metadatakey, Metadata) and not metadatakey.assay_level:
            msg = f"AssayMetaData key '{metadatakey.key}' already exists with 'OBSERVATION' metadata level"
            raise MetadataLevelException(msg)
        if isinstance(metadatakey, str):
            metadatakey = Metadata.register(key=metadatakey, assay_level=True)
            kwargs['key'] = metadatakey
        if kwargs.get('value'):
            value = kwargs.pop('value')
            kwargs.update(value_to_kwargs(value, is_property=True))
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'AssayMetadataValue':
        """Register a new metadata value for an assay. Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set. If your value is a datetime object, and you want the time shown, be
        sure to set the `show_time_component` field to `True`.

        Example registration with minimum required fields:

        .. code-block:: python

            AssayMetadataValue.register(key_id=42, assay_id=23, num_value=datetime.utcnow(), show_time_component=True)

        :param kwargs: Keyword arguments to be used to register a new assay metadata value or as search
            conditions for an existing assay metadata value
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found assaymetadatavalue model entity exactly matching the search conditions
        """
        return super().register(**cls.prep_and_validate_values(kwargs))

    key = ForeignKeyField(Metadata, backref='assaymetadatavalues')  # key_id AS key_id
    assay = ForeignKeyField(Assay, backref='metadata')  # assay_id AS phenomenon_type_id
    show_time_component = BooleanField(null=True, **defaults(False))  # AS show_time_component; False = Date only

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value) <= 1",
                  name="only_one_or_none_assaymetadata_value"),
        ]
        indexes = (
            # create a unique on metadatakey + assay
            (('key_id', 'assay_id'), True),)


class ExperimentMetadataValue(PropertyModel):  # ld_assay_metadata OR ld_assay_value_metadata
    """This table contains metadata values for an experiment which will be associated at the assay level
    (ld_assay_metadata) if `assay_level` is True or the observation level (ld_assay_values_metadata) if `assay_level` is
    False. The `assaymetadatakey.assay_level` must match `experimentmetadata.assay_level`. Only one value can
    be recorded for an experiment_id - key_id pair; there is a unique constraint on `(experiment_id,
    key_id)`. Only one value can be set (but all can be set to null).

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
    * `experiment_id`: REQUIRED/FOREIGN KEY to Experiment table (int)
    * `assay_level`: OPTIONAL (bool: `false`) - boolean field to indicate metadata level for which the value is used; true = ASSAY, false = OBSERVATION.
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: E501

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['ExperimentMetadataValue']:
        """Bulk register experiment metadata values with a list of row values. All rows must have the same fields and
        will be passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_.
        This operation is effectively an upsert and will use the `ExperimentMetadataValue.key` and
        `ExperimentMetadataValue.experiment` fields to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing ExperimentMetadataValue table model entities corresponding to the newly updated/added
            rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'experiment']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[ExperimentMetadataValue.key, ExperimentMetadataValue.experiment],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update}
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the ExperimentMetadataValue `register()` and `bulk_register()` methods. Will
        ensure `key` is set and the `Metadata.assay_level` is set appropriately.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        metadatakey = kwargs.get('key')
        assay_level = kwargs.get('assay_level', False)
        if not metadatakey:
            raise ValueError("key must be set")
        if isinstance(metadatakey, Metadata) and metadatakey.assay_level != assay_level:
            text_level = 'ASSAY' if metadatakey.assay_level else 'OBSERVATION'
            msg = f"AssayMetaData key '{metadatakey.key}' already exists with '{text_level}' metadata level"
            raise MetadataLevelException(msg)
        if isinstance(metadatakey, str):
            metadatakey = Metadata.register(key=metadatakey, assay_level=assay_level)
            kwargs['key'] = metadatakey
        if kwargs.get('value'):
            value = kwargs.pop('value')
            kwargs.update(value_to_kwargs(value, is_property=True))
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'ExperimentMetadataValue':
        """Register a new metadata value for an experiment. LiveDesign only supports attaching metadata onto the Assay
        or Observation level. Setting `assay_value` to `True` will associate the metadata at the Assay level (and for
        all observations of that assay protocol); setting `assay_value` to `False` will associate the metadata at the
        Observation level (and all observations for that experiment). Note that ONLY ONE of `num_value`, `text_value`,
        or `date_value` fields should be set. If your value is a datetime object, and you want the time shown, be
        sure to set the `show_time_component` field to `True`.

        Example registration with minimum required fields:

        .. code-block:: python

            ExperimentMetadataValue.register(experiment_id=20, key_id=40, num_value=59, assay_level=False)

        :param kwargs: Keyword arguments to be used to register a new assay metadata value or as search
            conditions for an existing assay metadata value
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found assaymetadatavalue model entity exactly matching the search conditions
        """
        return super().register(**cls.prep_and_validate_values(kwargs))

    @classmethod
    def upsert(cls, **kwargs) -> 'ExperimentMetadataValue':
        """
        Insert a new experiment metadata value or, if there are conflicts found, update an existing experiment metadata
        value with the provided kwargs. Note if None values are explicitly set in the provided kwargs then those
        attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'experiment']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[ExperimentMetadataValue.key, ExperimentMetadataValue.experiment],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    key = ForeignKeyField(Metadata, backref='experimentmetadatavalues')  # AS key_id
    assay_level = BooleanField(**defaults(False))  # AS metadata_level; True = 'ASSAY', False = 'OBSERVATION'
    experiment = ForeignKeyField(Experiment, backref='metadata')  # AS phenomenon_type_id OR observation_id
    show_time_component = BooleanField(null=True, **defaults(False))  # AS show_time_component; False = Date only

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check("num_nonnulls(num_value, text_value, date_value) <= 1",
                  name="only_one_or_none_experimentmetadata_value"),
        ]
        indexes = (
            # create a unique on key + experiment
            (('key_id', 'experiment_id'), True),)


class ObservationMetadataValue(PropertyModel):  # ld_assay_value_metadata
    """This table contains metadata values for an observation. The `assaymetadatakey.assay_level` must be False. Only
    one value can be recorded for an observation_id - key_id pair; there is a unique constraint on `(key_id,
    compoundobservation_id, lotobservation_id, genericentityobservation_id, poseobservation_id)`. Only one value needs
    to be set (but all can be set to null).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `customer_key`: OPTIONAL/UNIQUE (int8) - integer PK for lot property from customer's source DB
    * `archived`: OPTIONAL (int2: `0`) - include in DI mappings (WHERE archived != 1) for "soft delete" option; 1 for archived/deleted
    * `key_id`: REQUIRED/FOREIGN KEY to Metadata table (int)
    * `compoundobservation_id`: OPTIONAL FOREIGN KEY to CompoundObservation table (int) - only one observation_id should be set
    * `lotobservation_id`: OPTIONAL FOREIGN KEY to LotObservation table (int) - only one observation_id should be set
    * `genericentityobservation_id`: OPTIONAL FOREIGN KEY to GenericEntityObservation table (int) - only one observation_id should be set
    * `poseobservation_id`: OPTIONAL FOREIGN KEY to PoseObservation table (int) - only one observation_id should be set
    * `num_value`: OPTIONAL (double) - numeric value for the property (only one value should be set)
    * `text_value`: OPTIONAL (text) - string value for the property (only one value should be set)
    * `date_value`: OPTIONAL (timestamp) - date value for the property (only one value should be set)
    * `show_time_component`: OPTIONAL (bool: `false`) - used in conjunction with data_value. Determines how date_value will appear in LD based on LD Property settings: false (default) = use `ASSAY_DATE_VALUE_DISPLAY_FORMAT`; true = use `ASSAY_DATETIME_VALUE_DISPLAY_FORMAT`. Value here has no effect when date_value is null.
    * `source_id`: OPTIONAL FOREIGN KEY to Source table (int)

    Lookup field name: `id`
    """  # noqa: E501

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['ObservationMetadataValue']:
        """Bulk register observation metadata values with a list of row values. All rows must have the same fields and
        will be passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_.
        This operation is effectively an upsert and will use the ObservationMetadataValue `key`, `compoundobservation`,
        `lotobservation`, `genericentityobservation`, and `poseobservation` fields to resolve any conflicts.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing ObservationMetadataValue table model entities corresponding to the newly
            updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'compoundobservation', 'lotobservation', 'genericentityobservation',
                'poseobservation']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[
                    ObservationMetadataValue.key, ObservationMetadataValue.compoundobservation,
                    ObservationMetadataValue.lotobservation, ObservationMetadataValue.genericentityobservation,
                    ObservationMetadataValue.poseobservation
                ],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update}
            ))

    @classmethod
    def prep_and_validate_values(cls, kwargs) -> Dict:
        """Prepare and validate values for the ObservationMetadataValue `register()` and `bulk_register()` methods. Will
        ensure `key` is set and the `Metadata.assay_level` is set appropriately.

        :param kwargs: Dictionary of keyword arguments to be prepared and validated
        :type kwargs: dictionary
        :raises ValueError: key must be set
        :raises MetadataLevelException: AssayMetaData key '___' already exists with 'ASSAY' metadata level
        :return: Prepared and validated input dictionary
        :rtype: dictionary
        """
        metadatakey = kwargs.get('key')
        if not metadatakey:
            raise ValueError("key must be set")
        if isinstance(metadatakey, Metadata) and metadatakey.assay_level:
            msg = f"AssayMetaData key '{metadatakey.key}' already exists with 'ASSAY' metadata level"
            raise MetadataLevelException(msg)
        if isinstance(metadatakey, str):
            metadatakey = Metadata.register(key=metadatakey, assay_level=False)
            kwargs['key'] = metadatakey
        if kwargs.get('value'):
            value = kwargs.pop('value')
            kwargs.update(value_to_kwargs(value, is_property=True))
        return super().prep_and_validate_values(kwargs)

    @classmethod
    def register(cls, **kwargs) -> 'AssayMetadataValue':
        """Register a new metadata value for an observation. One (and only one) of compoundobservation(_id),
        lotobservation(_id), genericentityobservation(_id), or poseobservation(_id) must be set. Note that ONLY ONE of
        `num_value`, `text_value`, or `date_value` fields should be set. If your value is a datetime object, and you
        want the time shown, be sure to set the `show_time_component` field to `True`.

        Example registration with minimum required fields:

        .. code-block:: python

            ObservationMetadataValue.register(compoundobservation_id=7, key_id=2, num_value=89)
            ObservationMetadataValue.register(lotobservation_id=8, key_id=2, num_value=89)
            ObservationMetadataValue.register(genericentityobservation_id=2, key_id=40, num_value=89)
            ObservationMetadataValue.register(poseobservation_id=10, key_id=2, num_value=89)

        :param kwargs: Keyword arguments to be used to register a new observation metadata value or as search
            conditions for an existing assay metadata value
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found observationmetadatavalue model entity exactly matching the search conditions
        """
        return super().register(**cls.prep_and_validate_values(kwargs))

    @classmethod
    def upsert(cls, **kwargs) -> 'ObservationMetadataValue':
        """
        Insert a new experiment metadata value or, if there are conflicts found, update an existing experiment metadata
        value with the provided kwargs. Note if None values are explicitly set in the provided kwargs then those
        attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id', 'customer_key', 'key', 'compoundobservation', 'lotobservation', 'genericentityobservation',
                'poseobservation']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[
                    ObservationMetadataValue.key, ObservationMetadataValue.compoundobservation,
                    ObservationMetadataValue.lotobservation, ObservationMetadataValue.genericentityobservation,
                    ObservationMetadataValue.poseobservation
                ],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    key = ForeignKeyField(Metadata, backref='observationmetadatavalues')  # AS key_id
    compoundobservation = ForeignKeyField(CompoundObservation, null=True, backref='metadata')  # AS observation_id
    lotobservation = ForeignKeyField(LotObservation, null=True, backref='metadata')  # AS observation_id
    # AS observation_id
    genericentityobservation = ForeignKeyField(GenericEntityObservation, null=True, backref='metadata')
    poseobservation = ForeignKeyField(PoseObservation, null=True, backref='metadata')  # AS observation_id
    show_time_component = BooleanField(null=True, **defaults(False))  # AS show_time_component; False = Date only

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        constraints = [
            Check('(num_nonnulls(compoundobservation_id, lotobservation_id, genericentityobservation_id, '
                  'poseobservation_id) = 1)',
                  name="metadata_has_only_one_relation")
        ]
        indexes = (
            # create a unique on key + observation
            (('key_id', 'compoundobservation_id', 'lotobservation_id', 'genericentityobservation_id',
              'poseobservation_id'), True),)


class GenericEntityLink(BaseModel):
    """A table holding linking type and linking text of a generic entity.

    This table is only supported in LD ≥ 2023.3.0. Currently, only expected to work with biologics entities. The
    current biologics work flow works like this. After mapping this table, LD will:

    1. Send the GE's file to bbchem for processing
    2. The returned processed structure should include a canonical hash for the GE structure.
    3. The canonical hash is then matched against canonical hashes of virtuals in the system
    4. Matching virtuals are automatically linked to the real GE

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `generic_entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
    * `linking_type`: REQUIRED (text: 'REAL') - must be 'REAL'

    Lookup field name: `id`

    """

    lookup_field_name = 'id'

    @classmethod
    def register(cls, **kwargs) -> 'GenericEntityLink':
        """Register a new generic entity link. Note that at this time linking_type must be
        "REAL".

        Example registration with minimum required fields:

        .. code-block:: python

             GenericEntityLink.register(generic_entity_id=35, linking_type="REAL")

        :param kwargs: Keyword arguments to be used to register a new genericentitylink or as search conditions for an
            existing genericentitylink
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found genericentitylink model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    generic_entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='links')  # AS generic_entity_id
    linking_type = TextField(unique=False, null=False, default='REAL')  # AS linking_type


class EntityRelationshipParent(BaseModel):
    """This table contains the parents in a multi-component entity.

    This table is only supported in LD ≥ 2023.3.0.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
    * `relationship_type`: REQUIRED (text: 'FORMULATION') - type of relationship

    """

    lookup_field_name = 'id'
    CHILDREFS = ['relationship_children']

    @classmethod
    def register(cls, **kwargs) -> 'EntityRelationshipParent':
        """Register a new parent in a multi-component entity. Note that at this time relationship_type must be
        "FORMULATION".

        Example registration with minimum required fields:

        .. code-block:: python

             EntityRelationshipParent.register(entity_id=34, relationship_type="FORMULATION")

        :param kwargs: Keyword arguments to be used to register a new parent or as search conditions for an existing
            relationship parent
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entityrelationshipparent model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='relationship_parents')  # AS entity_id
    relationship_type = TextField(unique=False, null=False, default='FORMULATION')  # AS relationship_type


class EntityRelationshipChild(BaseModel):
    """This table contains the children in a multi-component entity.

    This table is only supported in LD ≥ 2023.3.0. There are two unique constraints on this table -
    (entity_id, parent_id) and (parent_id, child_order).

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `entity(_id)`: REQUIRED FK to GenericEntity (int) - GenericEntity.id
    * `parent(_id)`: REQUIRED FK to EntityRelationshipParent (int) - EntityRelationshipParent.id
    * `child_order`: REQUIRED (int) - integer denoting order among various children of a parent

    """

    lookup_field_name = 'id'
    CHILDREFS = ['relationship_metadata']

    @classmethod
    def register(cls, **kwargs) -> 'EntityRelationshipChild':
        """Register a new child in a multi-component entity.

        Example registration with minimum required fields:

        .. code-block:: python

             EntityRelationshipChild.register(entity_id=34, parent_id=38, child_order=1)

        :param kwargs: Keyword arguments to be used to register a new child or as search conditions for an existing
            child
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entityrelationshipchild model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    @classmethod
    def bulk_register(cls, rows: Optional[List[Dict]]) -> List['EntityRelationshipChild']:
        """Bulk register relationship children with a list of row values. All rows must have the same fields and will
        be passed to the
        `BaseModel.bulk_prep_and_validate_values() <simpleschema.html#models.BaseModel.bulk_prep_and_validate_values>`_
        method. This operation is effectively an upsert and will use the `EntityRelationshipChild.entity`,
        `EntityRelationshipChild.parent`, and `EntityRelationshipChild.child_order` fields' unique constraints to
        resolve any conflicts. Note that as there are two composite unique constraints on this table -
        (entity_id, parent_id) and (parent_id, child_order) - on_conflict updates using the `bulk_register()` method
        may not work as expected. This method should only be used for bulk inserting new entities.

        :param rows: A list of dictionaries where each dictionary represents a table row. The dictionary keys and
            values correspond to column titles and values, respectively
        :type rows: list of dictionaries
        :return: A list containing the table model entities of the newly updated/added rows
        """
        if not rows:
            return []
        prepared_rows = cls.bulk_prep_and_validate_values(rows)
        fields = cls.get_fields_and_columns()
        keep = ['id']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return list(
            cls.insert_many(prepared_rows).returning(cls).on_conflict(  # see BaseModel.bulk_register() for details
                conflict_target=[EntityRelationshipChild.entity, EntityRelationshipChild.parent,
                                 EntityRelationshipChild.child_order],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    @classmethod
    def upsert(cls, **kwargs) -> 'EntityRelationshipChild':
        """
        Insert a new entity relationship child or, if there are conflicts found, update an existing entity relationship
        child with the provided kwargs. Note if None values are explicitly set in the provided kwargs then those
        attributes will be set to None.

        :param kwargs: field/column names=values keyword arguments to be used to update the current model entity
        :return: updated model entity
        """
        validated_kwargs = kwargs if kwargs.get('validated') else cls.prep_and_validate_values(kwargs)
        validated_kwargs.pop('validated')
        fields = cls.get_fields_and_columns()
        keep = ['id']
        to_update = [k for k in fields if k not in keep]  # only update fields not in the 'keep' list
        return (
            cls.insert(**validated_kwargs).returning(cls).on_conflict(
                conflict_target=[EntityRelationshipChild.entity, EntityRelationshipChild.parent,
                                 EntityRelationshipChild.child_order],
                update={fields[k]: getattr(EXCLUDED, k) for k in to_update},
                conflict_where=cls.lookup_unique_condition
            ))

    entity = ForeignKeyField(GenericEntity, on_delete='CASCADE', backref='relationship_children')  # AS entity_id
    # AS parent_id
    parent = ForeignKeyField(EntityRelationshipParent, on_delete='CASCADE', backref='relationship_children')
    child_order = SmallIntegerField(null=False, unique=False)  # AS child_order

    class Meta:
        # can't implement as subclass of the parent/super.Meta so explicit set those attributes
        database = PostgresqlExtDatabase(None)
        schema = 'public'
        table_function = make_legacy_table_name
        only_save_dirty = True  # NOTE: only persists modified fields
        # specific overrides for this class
        indexes = (
            # create unique constraints on (entity_id + parent_id) and (parent_id + child_order)
            (('entity_id', 'parent_id'), True),
            (('parent_id', 'child_order'), True))


class EntityRelationshipMetadata(BaseModel):
    """This table contains metadata for multi-component entities that are registered in the
    EntityRelationship(Parent/Child) tables.

    This table is only supported in LD ≥ 2023.3.0.

    Fields in this model:

    * `id`: PK/AUTO (bigserial)
    * `relationship_child(_id)`: REQUIRED FK to EntityRelationshipChild (int) - ID of relationship across which the metadata is recorded (EntityRelationshipChild.id)
    * `key`: REQUIRED (text) - Metadata key
    * `value`: REQUIRED (text) - Metadata value

    """  # noqa: E501

    lookup_field_name = 'id'

    @classmethod
    def register(cls, **kwargs) -> 'EntityRelationshipMetadata':
        """Register a metadata key: value pair for a multi-component entity relationship.

        Example registration with minimum required fields:

        .. code-block:: python

             EntityRelationshipMetadata.register(relationship_child_id=36, key="Type", value="Unbound protein")

        :param kwargs: Keyword arguments to be used to register new metadata or as search conditions for existing
            metadata
        :type kwargs: comma separated keyword arguments, field/column name = value
        :return: New or found entityrelationshipmetadata model entity exactly matching the search conditions
        """
        return super().register(**kwargs)

    # AS relationship_id
    relationship_child = ForeignKeyField(EntityRelationshipChild, on_delete='CASCADE', backref='relationship_metadata')
    key = TextField(unique=False, null=False)  # AS key
    value = TextField(unique=False, null=False)  # AS value

