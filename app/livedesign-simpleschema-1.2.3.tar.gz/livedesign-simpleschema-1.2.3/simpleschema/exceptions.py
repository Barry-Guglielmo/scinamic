from peewee import IntegrityError


# Custom exceptions
class ProjectIntegrityError(IntegrityError):
    """Raised when a project is in use or already registered with a different restriction"""


class PrimaryProjectIntegrityError(ProjectIntegrityError):
    """Raised when a primary project is already set for the entity in its join table"""


class EntityIntegrityError(IntegrityError):
    """Raised when a compound or generic entity is in use or corporate_id is already in use by another entity"""


class AliasIntegrityError(IntegrityError):
    """Raised when a compound or entity alias is already in use"""


class LotIntegrityError(IntegrityError):
    """Raised when a batch is in use, batch_name is already in use by another batch for the same compound or there is a
    corp_name_full mismatch"""

class MetadataLevelException(ValueError):
    """Raised when a metadata value is attempted to be registered using a metadata key that has already been registered
    at the other level"""

class MetadataValueTypeException(ValueError):
    """Raised when a metadata key is attempted to be registered using a different value type than has already been
    registered or an unsupported value"""