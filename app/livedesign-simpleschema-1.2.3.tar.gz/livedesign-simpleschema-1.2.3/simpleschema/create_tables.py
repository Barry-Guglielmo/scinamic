#!/usr/bin/env python3
from argparse import ArgumentParser
from simpleschema.models import Project
from simpleschema.schemas import SimpleSchema
from peewee import OperationalError


def main():
    parser = ArgumentParser(
        description='Create tables in simple source schema (database must already exist)'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host",
                        default="localhost",
                        help="Postgres hostname (default: localhost)")
    parser.add_argument("--port",
                        default=3247,
                        help="Postgres port number (default: 3247)")
    parser.add_argument("--user",
                        default="simpleschema_owner",
                        help="User to login to db with (default: simpleschema_owner)")
    parser.add_argument("--password",
                        default="simpleschema",
                        help="Password to login to db with (default: simpleschema")
    parser.add_argument("--default_restricted_project",
                        default="Default Restricted Project",
                        help="Restricted project to create and default to")
    parser.add_argument("--include_global",
                        action='store_true',
                        help="Include Global in Project table")

    args = parser.parse_args()
    print(f"Creating tables in {args.database}...")
    target_schema = None
    try:
        # TODO: does peewee log create statements?
        target_schema = SimpleSchema(args.database,
                                     user=args.user,
                                     password=args.password,
                                     host=args.host,
                                     port=args.port,
                                     create_missing_tables=True,
                                     default_restricted_project=args.default_restricted_project,
                                     include_global_project=args.include_global)
    except OperationalError as oe:
        print(oe)
        exit(1)
    print("Making sure all table models exist...")
    all_tables_exist = False
    for model in target_schema.all_tables:
        if model.table_exists():
            print(f" Table '{model.get_table_name()}' exists.")
            all_tables_exist = True
        else:
            print(f" ERROR: Table '{model.get_table_name()}' does not exist!")
            all_tables_exist = False
    if all_tables_exist:
        print("Making sure 'Global' and/or 'Default Restricted Project' projects exist...")
        for project_name in ['Global', 'Default Restricted Project']:
            if Project.get_or_none(key=project_name):
                print(f" Project '{project_name}' exists.")
            else:
                print(f" Project '{project_name}' does not exist!")
        print("Done.")
    else:
        print("There were errors creating all the tables")


if __name__ == "__main__":
    main()
