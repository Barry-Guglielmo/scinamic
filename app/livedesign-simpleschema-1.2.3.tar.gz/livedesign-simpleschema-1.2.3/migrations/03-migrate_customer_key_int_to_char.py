#!/usr/bin/env python3
"""
Written By: Mike Braden
Date Added: 11/22/2022
Reason:
    Some customers want to be able to use string values for customer_key, particularly for assays, experiments, and/or
    observations.
"""
from argparse import ArgumentParser

from peewee import CharField, OperationalError
from playhouse.migrate import PostgresqlMigrator, migrate
from simpleschema.schemas import SimpleSchema
from simpleschema.models import ArchivableModel, HashableModel


def main():
    parser = ArgumentParser(
        description='Changes the customer_key datatype from (big)int to varchar(255). Will regenerate rowhash if '
                    'customer_key is set and used in the hashable_fields.'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost", help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3247, help="Postgres port number (default: 3247)")
    parser.add_argument("--user", default="simpleschema", help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password", default="simpleschema",
                        help="Password to login to db with (default: simpleschema")

    args = parser.parse_args()
    target = None
    try:
        target = SimpleSchema(args.database,
                              user=args.user,
                              password=args.password,
                              host=args.host,
                              port=args.port)
    except OperationalError as oe:
        print(oe)
        exit(1)
    migrator = PostgresqlMigrator(target.db)

    with target.db.atomic():
        for table_model in target.all_tables:
            if issubclass(table_model, ArchivableModel):
                table_name = table_model.get_table_name()
                print(f"Ensuring {table_name}.customer_key is varchar(255) data type")
                migrate(
                    migrator.alter_column_type(table_name, 'customer_key', CharField(), 'customer_key::varchar(255)')
                )
                if issubclass(table_model, HashableModel):
                    if 'customer_key' in table_model.hashable_fields:
                        print(f"  Regenerating all rowhash for table {table_name} (if customer_key is set)...")
                        rows = table_model.select().where(table_model.customer_key.is_null(False))
                        for row in rows.iterator():
                            row.update_rowhash()
    print("\nMigration complete.")


if __name__ == "__main__":
    main()
