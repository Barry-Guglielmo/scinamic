#!/usr/bin/env python3
"""
Written By: Mike Braden
Date Added: 04/11/2023
Reason:
    Update varchar255 fields to text for those that LD/DI support being so.
"""
from argparse import ArgumentParser

from peewee import TextField, OperationalError
from playhouse.migrate import PostgresqlMigrator, migrate
from simpleschema.schemas import SimpleSchema

def migrate_varchar_to_text(migrator, table_model, column_name):
    table_name = table_model.get_table_name()
    model_field = getattr(table_model, column_name)
    print(f"Ensuring {table_name}.{column_name} is 'text' data type")
    migrate(
        migrator.alter_column_type(table_name, column_name, TextField())
    )

def main():
    parser = ArgumentParser(
        description='Changes the customer_key datatype from (big)int to varchar(255). Will regenerate rowhash if '
                    'customer_key is set and used in the hashable_fields.'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost", help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3247, help="Postgres port number (default: 3247)")
    parser.add_argument("--user", default="simpleschema", help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password", default="simpleschema",
                        help="Password to login to db with (default: simpleschema")

    args = parser.parse_args()
    try:
        target = SimpleSchema(args.database,
                              user=args.user,
                              password=args.password,
                              host=args.host,
                              port=args.port)
    except OperationalError as oe:
        print(oe)
        exit(1)

    migrator = PostgresqlMigrator(target.db)
    fields_to_change_everywhere = ['customer_key', 'endpoint', 'person', 'description', 'corporate_id', 'salt',
                                   'lot_id_full', 'version', 'extension', 'alias', 'type', 'format', 'pose_id_full']
    with target.db.atomic():
        for table_model in target.all_tables:
            table_name = table_model.get_table_name()
            for field_name in fields_to_change_everywhere:
                if field_name in table_model.get_fields_and_columns():
                    migrate_varchar_to_text(migrator, table_model, field_name)
            if 'key' in table_model.get_fields_and_columns() and table_name != 'document':
                migrate_varchar_to_text(migrator, table_model, 'key')


    print("\nMigration complete.")


if __name__ == "__main__":
    main()
