#!/usr/bin/env python3
"""
Written By: Mike Braden
Date Added: 11/22/2022
Reason:
    Some customers want to load deleted entities into SimpleSchema. This migration only enforces the unique constraint
    on certain fields when that entity is not archived (archived = 0). It also removes the not-null constraint and
    unique index on Lot.lot_id_full and instead defines the partial unique index on Lot.compound and Lot.key.
"""

from argparse import ArgumentParser

from peewee import OperationalError
from playhouse.migrate import PostgresqlMigrator, migrate
from simpleschema.schemas import SimpleSchema
from simpleschema.models import Project, Compound, Lot, Assay, GenericEntity


def main():
    parser = ArgumentParser(
        description='Drops unique indexes in Project, Compound, Lot, Assay, and GenericEntity table models and '
                    'recreates them as partial unique indexes conditional on archived=0. Also removes unique index and'
                    'not-null constraint on Lot.lot_id_full and instead uses Lot.compound and Lot.key for partial '
                    'unique index.'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost", help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3247, help="Postgres port number (default: 3247)")
    parser.add_argument("--user", default="simpleschema", help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password", default="simpleschema",
                        help="Password to login to db with (default: simpleschema")

    args = parser.parse_args()
    target = None
    try:
        target = SimpleSchema(args.database,
                              user=args.user,
                              password=args.password,
                              host=args.host,
                              port=args.port)
    except OperationalError as oe:
        print(oe)
        exit(1)
    migrator = PostgresqlMigrator(target.db)

    with target.db.atomic():
        single_field_idxs = [(Project, Project.key),
                             (Compound, Compound.corporate_id),
                             (GenericEntity, GenericEntity.corporate_id)]
        for table_model, field in single_field_idxs:
            table_name = table_model.get_table_name()
            idx_name = f"{table_name}_{field.name}"
            print(f"Dropping and recreating partial index for {idx_name}")
            migrate(migrator.drop_index(table_name, idx_name))
            idx = table_model.index(field, unique=True, where=(table_model.archived == 0))
            target.db.execute(table_model._schema._create_index(idx))

        print("Dropping and recreating partial index for assay_key_version")
        migrate(migrator.drop_index('assay', 'assay_key_version'))
        assay_idx = Assay.index(Assay.key, Assay.version, unique=True, where=(Assay.archived == 0))
        target.db.execute(Assay._schema._create_index(assay_idx))

        print("Dropping unique index and not-nullable constraint on Lot.lot_id_full")
        migrate(
            migrator.drop_index('lot', 'lot_lot_id_full'),
            migrator.drop_not_null('lot', 'lot_id_full')
        )
        print("Adding partial unique index on lot.compound_id and lot.key")
        lot_idx = Lot.index(Lot.compound, Lot.key, unique=True, where=(Lot.archived == 0))
        Lot.add_index(lot_idx)
        Lot._schema.create_indexes(lot_idx)

    print("\nMigration complete.")


if __name__ == "__main__":
    main()
