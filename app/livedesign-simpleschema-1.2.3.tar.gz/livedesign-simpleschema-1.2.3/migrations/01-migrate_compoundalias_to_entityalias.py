#!/usr/bin/env python3
from argparse import ArgumentParser

from peewee import CharField, ForeignKeyField, OperationalError
from simpleschema.models import BaseModel, Compound, Source, EntityAlias
from simpleschema.exceptions import EntityIntegrityError
from simpleschema.schemas import SimpleSchema


class CompoundAlias(BaseModel):  # old alias model
    """
    This table contains compound aliases and is mapped to ld_entity_alias.
    """
    lookup_field_name = 'alias'

    @classmethod
    def prep_and_validate_values(cls, kwargs):
        if 'alias' in kwargs and Compound.get_or_none(corporate_id=kwargs['alias']):
            raise EntityIntegrityError(f"Compound {kwargs['alias']} has already been registered")
        return super().prep_and_validate_values(kwargs)

    alias = CharField(primary_key=True)  # AS alias
    compound = ForeignKeyField(Compound, backref='aliases')  # AS entity_id
    source = ForeignKeyField(Source, null=True, backref='compound_aliases')


def main():
    parser = ArgumentParser(
        description='Creates a new "entityalias" table and migrates data from old "compoundalias" table to the new one'
    )
    parser.add_argument("database", help="Postgres database name (will go into 'public' schema)")
    parser.add_argument("--host", default="localhost", help="Postgres hostname (default: localhost)")
    parser.add_argument("--port", default=3247, help="Postgres port number (default: 3247)")
    parser.add_argument("--user", default="simpleschema", help="User to login to db with (default: simpleschema)")
    parser.add_argument("--password",
                        default="simpleschema",
                        help="Password to login to db with (default: simpleschema")

    args = parser.parse_args()
    target_schema = None
    try:
        target_schema = SimpleSchema(args.database,
                                     user=args.user,
                                     password=args.password,
                                     host=args.host,
                                     port=args.port)
    except OperationalError as oe:
        print(oe)
        exit(1)
    if not EntityAlias.table_exists():
        target_schema.create_tables([EntityAlias])
    print("Ensuring 'CompoundAlias' and 'EntityAlias' tables exist")
    assert(EntityAlias.table_exists() and CompoundAlias.table_exists())
    print("Migrating 'CompoundAlias' rows to 'EntityAlias'")
    with target_schema.db.atomic():
        for row in CompoundAlias.select():
            EntityAlias.register(generic_entity=None, compound=row.compound, alias=row.alias, source=row.source)


if __name__ == "__main__":
    main()

