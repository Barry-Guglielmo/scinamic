# DI Mapping Files for Simple Schema

## Configuring Data Integrator Service for SimpleSchema

Copy the DI config in DI_mapping_files to the LiveDesign/DataIntegrator directory. If you are using LD < 2022-4 or do 
not have the metadata or generic entity lot tables in your SimpleSchema source database, then remove all "metadata", 
"genericentitylot", "metadatavalue" mappings and settings from your copy of the di_settings.json file. If you are using 
LD < 2023.3.0 or do not have the entity relationship tables in your SimpleSchema source database, then remove all 
entityrelationship mappings and settings from your copy of the di_settings.json file. It's recommended to copy/rename 
the file to something like `datasource_di_settings.json`. Replace `{{  DATABASE  }}`, `{{  DATASOURCE  }}`, 
`{{  HOSTNAME  }}`, `{{  LD_DB_USER  }}`, `{{  LD_DB_PASS  }}`, `{{  USERNAME  }}`, and `{{  PASSWORD  }}` with 
appropriate values. 

After the database and all tables have been created, set up DataIntegrator with the commands below:

```bash
di_admin settings -s datasource_di_settings.json
di_admin staging -s datasource_di_settings_di_formatted.json
di_admin audit -s datasource_di_settings_di_formatted.json
di_main -s datasource_di_settings_di_formatted.json --initial-load
```

A Chef run will be required to install the DI supervisor job

## DI Mappings

The current [DI Mappings](https://confluence.schrodinger.com/pages/viewpage.action?pageId=17925323) for Simple
Schema are as follows:

### syn_compound

```
compound.corporate_id AS corporate_id - Corporate/Entity ID; e.g. CPD-1234
compound.mol_file AS cd_structure - MOL or single SDF
COALESCE(c.person,'LiveDesign') AS person_id - (virtual lot) Lot Scientist
COALESCE(project.key, 'Default Restricted Project') AS project_name (LEFT JOIN compoundproject cp ON cp.compound_id = c.id AND cp.primary LEFT JOIN project p ON cp.project_id = p.id) - compound primary project name; if unset will fallback to 'Default Restricted Project'
# conditional: WHERE compound.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_entity_alias

```
entityalias.alias AS alias - the alias of the entity; Aliases show up in the ‘All IDs’ column in a LR; They may be searched against, and may show up in the ‘ID’ column depending on LD’s ID preference configurations.
entityalias.compound_id AS entity_id - compound PK
# or
entityalias.generic_entity_id AS entity_id - generic entity PK
```

### ld_entities_projects

```
# Compounds
compoundproject.project_id AS project_id - project PK
compoundproject.compound_id AS entity_id - compound PK
# Faking batch ACLs:
batchproject.project_id AS project_id - project PK (will be added as compound ACL)
compound.id AS entity_id (JOIN batch ON batchproject.batch_id = batch.id JOIN compound ON batch.compound_id = compound.id)
# Generic Entities
genericentityproject.project_id AS project_id - project PK
genericentityproject.generic_entity_id AS entity_id - compound PK
# conditional: WHERE batch.archived = 0 - toggle archived = 1 for "soft" deletes
```

### syn_project

```
project.key AS project_name - Project name (e.g. "Default Restricted Project")
project.key AS alternate_id - must be set; so lets just set it to name
COALESCE(project.description, project.key) AS project_desc - can be mapped to Project Description; set to name if description is null
project.is_restricted AS is_restricted - 0 = unrestricted; 1 = restricted
CASE WHEN project.archived = 0 THEN 'Y' ELSE 'N' END AS active - toggle archived = 1 for "soft" deletes
```

### syn_sample

```
lot.key AS lot_id - Lot ID; e.g. "01" of CPD-1234-01
lot.compound_id AS compound_id* - PK to refer to the Compound entity
lot.salt AS salt_id* - Salt ID; e.g. "S01" of CPD-1234-01-S01
COALESCE(lot.modified_at, lot.created_at) AS reg_date - Lot Date Registered
COALESCE(lot.person,'LiveDesign') AS person_id* - Lot Scientist
COALESCE(page.key, page.customer_key, page.id::TEXT) AS document_page (LEFT JOIN page p ON l.page_id = p.id) - Notebook Page
# conditional: WHERE lot.archived = 0 - toggle archived = 1 for "soft" deletes
```

The following are not currently implemented in SimpleSchema and can be replaced by Compound- or Lot-level properties 
(DATA_INTEGRATED_DATABASE_COLUMNs) but may be better as a pseudo-assay ("Lot Properties"). Note that DATE format is only 
supported for DATA_INTEGRATED_DATABASE_COLUMNs in LD ≥ 8.8.x:

```
lot.? AS alias_id - Lot Alias
lot.? AS data1 - Lot Comment
lot.? AS amt_prepared - Lot Amount
lot.? AS appearance - Lot Appearance
lot.? AS date_prepared - Lot Date Prepared
lot.? AS purity - Lot Purity
lot.? AS solubility - Lot Solubility
lot.? AS total_formula - Lot Total Formula
lot.? AS total_weight - Lot Total Weight
```

### syn_observation_protocol
SELECT version AS version_num, key AS phenomenon_type_id FROM assay
```
assay.version AS version_num - Displays as "Protocol" in hover-over tooltips; used when column aggregation mode contains PROTOCOL
assay.key AS phenomenon_type_id (surrogate key to syn_phenomenon_type) - The phenomenon (assay) name behind the protocol is always present in column names
```

### syn_observation

``` 
lotobservation.lot_id AS observed_item_id - PK to refer to the Lot entity
experiment.timestamp AS secondary_groupno_date (LEFT JOIN experiment ON lotobservation.experiment_id = experiment.id) - Experiment Date. It can show up as a tooltip as users hover over an assay value. This is also what’s used in adv search limited to experimental dates.
lotobservation.text_value AS cat_obs_phenomenon - String value of an assay result
lotobservation.num_value AS quantity - Numeric value of an assay result
lotobservation.date_value AS date_value - Date value of an assay result (8.8+)
lotobservation.assay_id AS protocol_id - FK to Assay for Assay Name / Assay Version
lotobservation.std_dev AS quantity_std_dev - Standard deviation of the assay value
lotobservation.assay_endpoint AS type_id (surrogate key to syn_observation_type) - The observation type (endpoint name) of the assay value. This value is always present in column names.
lotobservation.value_operator AS obs_operator - The operator for the assay value (e.g. ‘>’, ‘<’, ‘=’). Operators shows up along with the numeric assay value in a cell
lotobservation.conc AS quantity_conc - The concentration of the assay value. This gets used in certain column aggregation modes (e.g. ASSAY_NAME_TYPE_CONCENTRATION). Shows up as ‘concentration’ in hover-over tooltips
lotobservation.conc_unit AS quantity_conc_unit - The concentration unit of the assay value. This gets used in certain column aggregation modes (e.g. ASSAY_NAME_TYPE_CONCENTRATION). The unit label shows up as ‘concentration_units’ in hover-over tooltips.
COALESCE(experiment.key, experiment.customer_key, experiment.id::TEXT, '0') AS primary_groupno - The experiment batch number of the assay value. Shows up as ‘batch’ in hover-over tooltips. This gets used for pivoting in RPE (Row-per-Experiment) mode, as well as the key used for intra-cell alignment
lotobservation.assay_unit AS unit_id - The unit of the assay value. The unit label is visible to users alongside assay values, and the unit label also shows up in ‘unit’ in hover-over tooltips
page.key AS document_page (LEFT JOIN page ON lotobservation.page_id = page.id) - Notebook page of the assay value. Shows up as a hover-over tooltip
lotobservation.document_id AS document_id - FK to Document (syn_document) entity; will provide notebook of the assay value. The name (document.key) of the notebook appears as "Notebook" in the hover-over tooltip.
# conditional: WHERE lot.archived = 0 - toggle archived = 1 for "soft" deletes
```

All the above are repeated for the `compoundobservation`, `genericentityobservation`, `genericentitylotobservation`, and `poseobservation` tables with the following differences:
- `compoundobservation`: `compoundobservation.compound_id AS observed_item_id` and `1 AS compound_level`
- `genericentityobservation`: `genericentityobservation.generic_entity_id AS observed_item_id`
- `genericentitylotobservation`: `genericentitylotobservation.lot_id AS observed_item_id`
- `poseobservation`: `poseobservation.pose_id AS observed_item_id` and `poseobservation.structure_id AS structure` 

### syn_observation - properties

```
lotproperty.lot_id AS observed_item_id - PK to refer to the Lot entity
lotproperty.text_value AS cat_obs_phenomenon - String value of property
'DATA_INTEGRATED_DATABASE_COLUMN' AS type_id - tells DI that its an "Other Column"
lotproperty.num_value AS quantity - Numeric value of property
lotproperty.date_value AS date_value - Date value of property (8.8+)
lotproperty.key AS protocol_id - column name that will appear under Other Columns
# conditional: WHERE lot.archived = 0 - toggle archived = 1 for "soft" deletes
```

All the above are repeated for `compoundproperty`, `genericentityproperty`, and `genericentitylotproperty` tables with the following differences:
- `compoundproperty`: `compoundproperty.compound_id AS observed_item_id` and `1 AS compound_level`
- `genericentityproperty`: `genericentityproperty.generic_entity_id AS observed_item_id`
- `genericentitylotproperty`: `genericentitylotproperty.lot_id AS observed_item_id`

### ld_observations_projects

```
lotobservationproject.lot_observation_id AS observation_id - PK of LotObservation entity
lotobservationproject.project_id AS project_id - PK of Project entity
```

and

```
compoundobservationproject.compound_observation_id AS observation_id - PK of CompoundObservation entity
compoundobservationproject.project_id AS project_id - PK of Project entity
```

and

```
genericentityobservationproject.generic_entity_observation_id AS observation_id - PK of GenericEntityObservation entity
genericentityobservationproject.project_id AS project_id - PK of Project entity
```

and

```
genericentitylotobservationproject.lot_observation_id AS observation_id - PK of GenericEntityLotObservation entity
genericentitylotobservationproject.project_id AS project_id - PK of Project entity
```

and

```
poseobservationproject.pose_observation_id AS observation_id - PK of PoseObservation entity
poseobservationproject.project_id AS project_id - PK of Project entity
```

### syn_document

```
document.key AS name - Document, notebook, or report name/identifier
```

### ld_generic_entity

```
genericentity.corporate_id AS corporate_id
genericentity.person AS registration_scientist_id
genericentity.file_id AS manageable_file_id
# conditional: WHERE genericentity.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_generic_entity_lot

```
genericentitylot.lot_id_full AS lot_id
genericentitylot.person AS registration_scientist_id
genericentitylot.generic_entity_id AS parent_entity_id
genericentitylot.created_at AS registration_date
# conditional: WHERE genericentitylot.archived = 0 - toggle archived = 1 for "soft" deletes

```

### ld_data_blob

```
file.blob AS data
# conditional: WHERE file.archived = 0 - toggle archived = 1 for "soft" deletes
```

and

```
structure.blob AS data
# conditional: WHERE structure.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_manageable_file

```
file.key AS file_name
file.extension AS file_type
file.person AS registration_scientist_id
file.project_id AS registration_project_id
file.id AS data_blob_id
# conditional: WHERE file.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_structure

```
structure.type AS structure_type
structure.format AS file_format
structure.key AS name
# conditional: WHERE structure.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_structure_data

```
structure.id AS structure_id
structure.id AS data_blob_id
# conditional: WHERE structure.archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_pose

```
pose.compound_id AS parent_entity_id
pose.project_id AS project_id
pose.person AS person_id 
# conditional: WHERE pose.compound_id IS NOT NULL AND archived = 0 - toggle archived = 1 for "soft" deletes
```

and

```
pose.generic_entity_id AS parent_entity_id
pose.project_id AS project_id
pose.person AS person_id 
# conditional: WHERE pose.generic_entity_id IS NOT NULL AND archived = 0 - toggle archived = 1 for "soft" deletes
```

### ld_entity_metadata

```
entitymetadata.key AS name
entitymetadata.folder_path AS folder_path
UPPER(entitymetadata.value_type) AS value_type
```

### ld_entity_metadata_value

```
entitymetadatavalue.genericentity_id AS observed_item_id
entitymetadatavalue.metadatakey_id AS entity_metadata_id
entitymetadatavalue.text_value AS text_value
entitymetadatavalue.num_value AS numeric_value
entitymetadatavalue.date_value AS date_value
```

### ld_assay_metadata_key 

ASSAY level:
```
metadata.key AS name
'ASSAY' AS metadata_level
WHERE assay_level IS TRUE"
```

and

OBSERVATION level:
```
metadata.key AS name
'OBSERVATION' AS metadata_level
WHERE assay_level IS FALSE
```

### ld_assay_metadata

```
metadata.assay_id AS phenomenon_type_id
metadata.key_id AS key_id
metadata.num_value AS numeric_value
metadata.text_value AS text_value
metadata.date_value AS date_value
metadata.show_time_component AS show_time_component
WHERE metadata.archived = 0
```

and

```
experiment.assay_id AS phenomenon_type_id
metadata.key_id AS key_id
metadata.num_value AS numeric_value
metadata.text_value AS text_value
metadata.date_value AS date_value
metadata.show_time_component AS show_time_component
WHERE metadata.assay_level IS TRUE AND metadata.archived = 0
```

### ld_assay_value_metadata

```
observationmetadatavalue.lotobservation_id AS observation_id
observationmetadatavalue.key_id AS key_id
observationmetadatavalue.num_value AS numeric_value
observationmetadatavalue.text_value AS text_value
observationmetadatavalue.date_value AS date_value
observationmetadatavalue.show_time_component AS show_time_component
WHERE lotobservation_id IS NOT NULL AND archived = 0
```

and


```
observationmetadatavalue.compoundobservation_id AS observation_id
observationmetadatavalue.key_id AS key_id
observationmetadatavalue.num_value AS numeric_value
observationmetadatavalue.text_value AS text_value
observationmetadatavalue.date_value AS date_value
observationmetadatavalue.show_time_component AS show_time_component
WHERE observationmetadatavalue.compoundobservation_id IS NOT NULL 
 AND observationmetadatavalue.archived = 0
```

and


```
observationmetadatavalue.genericentityobservation_id AS observation_id
observationmetadatavalue.key_id AS key_id
observationmetadatavalue.num_value AS numeric_value
observationmetadatavalue.text_value AS text_value
observationmetadatavalue.date_value AS date_value
observationmetadatavalue.show_time_component AS show_time_component
WHERE observationmetadatavalue.genericentityobservation_id IS NOT NULL 
 AND observationmetadatavalue.archived = 0
```

and


```
observationmetadatavalue.poseobservation_id AS observation_id
observationmetadatavalue.key_id AS key_id
observationmetadatavalue.num_value AS numeric_value
observationmetadatavalue.text_value AS text_value
observationmetadatavalue.date_value AS date_value
observationmetadatavalue.show_time_component AS show_time_component
WHERE observationmetadatavalue.poseobservation_id IS NOT NULL 
 AND observationmetadatavalue.archived = 0
```

and


```
lotobservation.id AS observation_id
experimentmetadatavalue.key_id AS key_id
experimentmetadatavalue.num_value AS numeric_value
experimentmetadatavalue.text_value AS text_value
experimentmetadatavalue.date_value AS date_value
experimentmetadatavalue.show_time_component AS show_time_component
WHERE experimentmetadatavalue.assay_level IS FALSE 
 AND experimentmetadatavalue.archived = 0 
 AND lotobservation.archived = 0
```

and


```
compoundobservation.id AS observation_id
experimentmetadatavalue.key_id AS key_id
experimentmetadatavalue.num_value AS numeric_value
experimentmetadatavalue.text_value AS text_value
experimentmetadatavalue.date_value AS date_value
experimentmetadatavalue.show_time_component AS show_time_component
WHERE experimentmetadatavalue.assay_level IS FALSE 
 AND experimentmetadatavalue.archived = 0 
 AND compoundobservation.archived = 0
```

and


```
genericentityobservation.id AS observation_id
experimentmetadatavalue.key_id AS key_id
experimentmetadatavalue.num_value AS numeric_value
experimentmetadatavalue.text_value AS text_value
experimentmetadatavalue.date_value AS date_value
experimentmetadatavalue.show_time_component AS show_time_component
WHERE experimentmetadatavalue.assay_level IS FALSE 
 AND experimentmetadatavalue.archived = 0 
 AND genericentityobservation.archived = 0
```

and


```
poseobservation.id AS observation_id
experimentmetadatavalue.key_id AS key_id
experimentmetadatavalue.num_value AS numeric_value
experimentmetadatavalue.text_value AS text_value
experimentmetadatavalue.date_value AS date_value
experimentmetadatavalue.show_time_component AS show_time_component
WHERE experimentmetadatavalue.assay_level IS FALSE 
 AND experimentmetadatavalue.archived = 0 
 AND poseobservation.archived = 0
```

### ld_generic_entity_real_virtual_linking

```
genericentitylink.generic_entity_id AS generic_entity_id
genericentitylink.linking_type AS linking_type
```

### entity_relationship_parent

```
entityrelationshipparent.entity_id AS entity_id
entityrelationshipparent.relationship_type AS relationship_type
```

### entity_relationship_child

```
entityrelationshipchild.entity_id AS entity_id
entityrelationshipchild.parent_id AS parent_id
entityrelationshipchild.child_order AS child_order
```

### entity_relationship_metadata

```
entityrelationshipmetadata.relationship_child_id AS relationship_id
entityrelationshipmetadata.key AS key
entityrelationshipmetadata.value AS value
```

## Notes on assay column name formatting
Note that the following columns can be used to determine the column names in LiveDesign and how data are aggregated.
See LD’s Column Aggregation modes for more details:
- `protocol_id` (and by extension, the `version_num` + `phenomenon_type_id` in `syn_observation_protocol`)
- `type_id`
- `quantity_conc`
- `quantity_conc_unit`
- `primary_groupno`

## Issues with 3D data DI in LD < 2022-3.0

There is a known issue with DI'ing 3D data (ld_structure, ld_pose, ld_structure_data) that should be fixed in LD 
2022-3.0. See [SS-38086](https://jira.schrodinger.com/browse/SS-38086) for details. The workaround is to run the 
following SQL queries against the DI DB after all full reDIs:

```
INSERT INTO processed_nk_mapping_max_id (table_name, max_id)
SELECT 'ld_data_blob', max_id
FROM processed_nk_mapping_max_id
WHERE table_name = 'ld_data_blobs'
ON CONFLICT DO NOTHING;

DELETE FROM processed_nk_mapping_max_id
WHERE table_name = 'ld_data_blobs';

INSERT INTO processed_nk_mapping_max_id (table_name, max_id)
VALUES ('ld_generic_entity_lot', 0) 
ON CONFLICT DO NOTHING;
 
INSERT INTO processed_nk_mapping_max_id (table_name, max_id)
VALUES ('ld_pose', 0) 
ON CONFLICT DO NOTHING;
 
INSERT INTO processed_nk_mapping_max_id (table_name, max_id)
VALUES ('ld_structure_data', 0) 
ON CONFLICT DO NOTHING;
```

## Notes on Metadata (LD ≥22-4)

Note that metadata support is only available in LD ≥22-4. If you are using an older version of LD and/or have not 
created the SimpleSchema metadata tables then be sure to remove any mappings and settings referring to these tables in 
your copy of the di_settings.json file.

For entity metadata, LiveDesign and DataIntegrator only support adding metadata onto generic entities; this may be 
extended to all entities in the future. Entity metadata is similar to Entity Properties and appears in a similar way in 
LiveDesign, under the "Other Columns" of the Data & Columns tree. For Generic Entities, it is highly recommended that 
EntityMetadata / EntityMetadataValue is used over GenericEntityProperty for metadata, since these tables are going to 
be used for future features implemented for metadata.

For assay metadata, LiveDesign and DataIntegrator only support adding metadata onto the assay or observation level; 
experiment-level metadata is not (currently) supported. To add experiment-level metadata in the ExperimentMetadataValue 
table a choice must be made whether to associate the metadata to the assay or all observations for that experiment. 
This is controlled by the ExperimentMetadataValue.assay_level boolean, where `true` will associate it with the assay (in 
`experiment.assay_id` and `false` will associate it with all observations that have that `experiment_id` set.

## Notes on Entity Relationship tables

Note that entity relationships are currently only supported for formulations and in LD ≥ 2023.3.0.  If you are using 
an older version of LD and/or have not created the SimpleSchema metadata tables then be sure to remove any mappings and 
settings referring to these tables in your copy of the di_settings.json file.

## Notes on Entity Linking

This is new in >=2023.3.0. Currently, only expected to work with biologics entities. The current biologics work flow 
works like this. After mapping this table, LD will:
1. Send the GE's file to bbchem for processing
2. The returned processed structure should include a canonical hash for the GE structure.
3. The canonical hash is then matched against canonical hashes of virtuals in the system
4. Matching virtuals are automatically linked to the real GE
